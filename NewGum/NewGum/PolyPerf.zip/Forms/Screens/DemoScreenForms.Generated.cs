    namespace NewGum.FormsControls.Screens
    {
        public partial class DemoScreenForms
        {
            private Gum.Wireframe.GraphicalUiElement Visual;
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.ListBox ResolutionBox { get; set; }
            public FlatRedBall.Forms.Controls.CheckBox FullScreenCheckbox { get; set; }
            public FlatRedBall.Forms.Controls.Slider MusicSlider { get; set; }
            public FlatRedBall.Forms.Controls.Slider SoundSlider { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance2 { get; set; }
            public FlatRedBall.Forms.Controls.ComboBox ComboBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonConfirmInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonDenyInstance { get; set; }
            public FlatRedBall.Forms.Controls.TextBox TextBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonConfirmInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance2 { get; set; }
            public DemoScreenForms () 
            {
                CustomInitialize();
            }
            public DemoScreenForms (Gum.Wireframe.GraphicalUiElement visual) 
            {
                Visual = visual;
                ReactToVisualChanged();
                CustomInitialize();
            }
            private void ReactToVisualChanged () 
            {
                ButtonCloseInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance").FormsControlAsObject;
                ButtonCloseInstance1 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance1").FormsControlAsObject;
                ResolutionBox = (FlatRedBall.Forms.Controls.ListBox)Visual.GetGraphicalUiElementByName("ResolutionBox").FormsControlAsObject;
                FullScreenCheckbox = (FlatRedBall.Forms.Controls.CheckBox)Visual.GetGraphicalUiElementByName("FullScreenCheckbox").FormsControlAsObject;
                MusicSlider = (FlatRedBall.Forms.Controls.Slider)Visual.GetGraphicalUiElementByName("MusicSlider").FormsControlAsObject;
                SoundSlider = (FlatRedBall.Forms.Controls.Slider)Visual.GetGraphicalUiElementByName("SoundSlider").FormsControlAsObject;
                RadioButtonInstance = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance").FormsControlAsObject;
                RadioButtonInstance1 = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance1").FormsControlAsObject;
                RadioButtonInstance2 = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance2").FormsControlAsObject;
                ComboBoxInstance = (FlatRedBall.Forms.Controls.ComboBox)Visual.GetGraphicalUiElementByName("ComboBoxInstance").FormsControlAsObject;
                ButtonConfirmInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonConfirmInstance").FormsControlAsObject;
                ButtonDenyInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonDenyInstance").FormsControlAsObject;
                TextBoxInstance = (FlatRedBall.Forms.Controls.TextBox)Visual.GetGraphicalUiElementByName("TextBoxInstance").FormsControlAsObject;
                ButtonConfirmInstance1 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonConfirmInstance1").FormsControlAsObject;
                ButtonCloseInstance2 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance2").FormsControlAsObject;
            }
            partial void CustomInitialize();
        }
    }
