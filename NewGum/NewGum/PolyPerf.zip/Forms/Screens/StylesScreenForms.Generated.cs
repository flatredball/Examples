    namespace NewGum.FormsControls.Screens
    {
        public partial class StylesScreenForms
        {
            private Gum.Wireframe.GraphicalUiElement Visual;
            public FlatRedBall.Forms.Controls.Button ButtonStandardInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonStandardIconInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonTabInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonIconInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonConfirmInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonDenyInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance { get; set; }
            public FlatRedBall.Forms.Controls.CheckBox CheckBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance { get; set; }
            public FlatRedBall.Forms.Controls.ComboBox ComboBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.ListBox ListBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.Slider SliderInstance { get; set; }
            public FlatRedBall.Forms.Controls.TextBox TextBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.PasswordBox PasswordBoxInstance { get; set; }
            public StylesScreenForms () 
            {
                CustomInitialize();
            }
            public StylesScreenForms (Gum.Wireframe.GraphicalUiElement visual) 
            {
                Visual = visual;
                ReactToVisualChanged();
                CustomInitialize();
            }
            private void ReactToVisualChanged () 
            {
                ButtonStandardInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonStandardInstance").FormsControlAsObject;
                ButtonStandardIconInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonStandardIconInstance").FormsControlAsObject;
                ButtonTabInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonTabInstance").FormsControlAsObject;
                ButtonIconInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonIconInstance").FormsControlAsObject;
                ButtonConfirmInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonConfirmInstance").FormsControlAsObject;
                ButtonDenyInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonDenyInstance").FormsControlAsObject;
                ButtonCloseInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance").FormsControlAsObject;
                CheckBoxInstance = (FlatRedBall.Forms.Controls.CheckBox)Visual.GetGraphicalUiElementByName("CheckBoxInstance").FormsControlAsObject;
                RadioButtonInstance = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance").FormsControlAsObject;
                ComboBoxInstance = (FlatRedBall.Forms.Controls.ComboBox)Visual.GetGraphicalUiElementByName("ComboBoxInstance").FormsControlAsObject;
                ListBoxInstance = (FlatRedBall.Forms.Controls.ListBox)Visual.GetGraphicalUiElementByName("ListBoxInstance").FormsControlAsObject;
                SliderInstance = (FlatRedBall.Forms.Controls.Slider)Visual.GetGraphicalUiElementByName("SliderInstance").FormsControlAsObject;
                TextBoxInstance = (FlatRedBall.Forms.Controls.TextBox)Visual.GetGraphicalUiElementByName("TextBoxInstance").FormsControlAsObject;
                PasswordBoxInstance = (FlatRedBall.Forms.Controls.PasswordBox)Visual.GetGraphicalUiElementByName("PasswordBoxInstance").FormsControlAsObject;
            }
            partial void CustomInitialize();
        }
    }
