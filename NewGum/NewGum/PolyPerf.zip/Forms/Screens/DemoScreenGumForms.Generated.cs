    namespace NewGum.FormsControls.Screens
    {
        public partial class DemoScreenGumForms
        {
            private Gum.Wireframe.GraphicalUiElement Visual;
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.ListBox ResolutionBox { get; set; }
            public FlatRedBall.Forms.Controls.Button DetectResolutionsButton { get; set; }
            public FlatRedBall.Forms.Controls.CheckBox FullScreenCheckbox { get; set; }
            public FlatRedBall.Forms.Controls.Slider MusicSlider { get; set; }
            public FlatRedBall.Forms.Controls.Slider SoundSlider { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.RadioButton RadioButtonInstance2 { get; set; }
            public FlatRedBall.Forms.Controls.ComboBox ComboBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonConfirmInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonDenyInstance { get; set; }
            public FlatRedBall.Forms.Controls.TextBox TextBoxInstance { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonConfirmInstance1 { get; set; }
            public FlatRedBall.Forms.Controls.Button ButtonCloseInstance2 { get; set; }
            public FlatRedBall.Forms.Controls.Button TabMenuClose { get; set; }
            public FlatRedBall.Forms.Controls.Button PlayButton { get; set; }
            public FlatRedBall.Forms.Controls.Button VideoSettingsButton { get; set; }
            public FlatRedBall.Forms.Controls.Button AudioSettingsButton { get; set; }
            public FlatRedBall.Forms.Controls.Button CreditsButton { get; set; }
            public FlatRedBall.Forms.Controls.Button ExitButton { get; set; }
            public FlatRedBall.Forms.Controls.Button Tab3 { get; set; }
            public FlatRedBall.Forms.Controls.Button Tab2 { get; set; }
            public FlatRedBall.Forms.Controls.Button Tab1 { get; set; }
            public DemoScreenGumForms () 
            {
                CustomInitialize();
            }
            public DemoScreenGumForms (Gum.Wireframe.GraphicalUiElement visual) 
            {
                Visual = visual;
                ReactToVisualChanged();
                CustomInitialize();
            }
            private void ReactToVisualChanged () 
            {
                ButtonCloseInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance").FormsControlAsObject;
                ButtonCloseInstance1 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance1").FormsControlAsObject;
                ResolutionBox = (FlatRedBall.Forms.Controls.ListBox)Visual.GetGraphicalUiElementByName("ResolutionBox").FormsControlAsObject;
                DetectResolutionsButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("DetectResolutionsButton").FormsControlAsObject;
                FullScreenCheckbox = (FlatRedBall.Forms.Controls.CheckBox)Visual.GetGraphicalUiElementByName("FullScreenCheckbox").FormsControlAsObject;
                MusicSlider = (FlatRedBall.Forms.Controls.Slider)Visual.GetGraphicalUiElementByName("MusicSlider").FormsControlAsObject;
                SoundSlider = (FlatRedBall.Forms.Controls.Slider)Visual.GetGraphicalUiElementByName("SoundSlider").FormsControlAsObject;
                RadioButtonInstance = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance").FormsControlAsObject;
                RadioButtonInstance1 = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance1").FormsControlAsObject;
                RadioButtonInstance2 = (FlatRedBall.Forms.Controls.RadioButton)Visual.GetGraphicalUiElementByName("RadioButtonInstance2").FormsControlAsObject;
                ComboBoxInstance = (FlatRedBall.Forms.Controls.ComboBox)Visual.GetGraphicalUiElementByName("ComboBoxInstance").FormsControlAsObject;
                ButtonConfirmInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonConfirmInstance").FormsControlAsObject;
                ButtonDenyInstance = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonDenyInstance").FormsControlAsObject;
                TextBoxInstance = (FlatRedBall.Forms.Controls.TextBox)Visual.GetGraphicalUiElementByName("TextBoxInstance").FormsControlAsObject;
                ButtonConfirmInstance1 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonConfirmInstance1").FormsControlAsObject;
                ButtonCloseInstance2 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ButtonCloseInstance2").FormsControlAsObject;
                TabMenuClose = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("TabMenuClose").FormsControlAsObject;
                PlayButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("PlayButton").FormsControlAsObject;
                VideoSettingsButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("VideoSettingsButton").FormsControlAsObject;
                AudioSettingsButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("AudioSettingsButton").FormsControlAsObject;
                CreditsButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("CreditsButton").FormsControlAsObject;
                ExitButton = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("ExitButton").FormsControlAsObject;
                Tab3 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("Tab3").FormsControlAsObject;
                Tab2 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("Tab2").FormsControlAsObject;
                Tab1 = (FlatRedBall.Forms.Controls.Button)Visual.GetGraphicalUiElementByName("Tab1").FormsControlAsObject;
            }
            partial void CustomInitialize();
        }
    }
