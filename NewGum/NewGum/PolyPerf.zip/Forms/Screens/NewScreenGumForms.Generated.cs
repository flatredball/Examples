    namespace NewGum.FormsControls.Screens
    {
        public partial class NewScreenGumForms
        {
            private Gum.Wireframe.GraphicalUiElement Visual;
            public NewScreenGumForms () 
            {
                CustomInitialize();
            }
            public NewScreenGumForms (Gum.Wireframe.GraphicalUiElement visual) 
            {
                Visual = visual;
                ReactToVisualChanged();
                CustomInitialize();
            }
            private void ReactToVisualChanged () 
            {
            }
            partial void CustomInitialize();
        }
    }
