    namespace NewGum.FormsControls.Screens
    {
        public partial class PolygonScreenGumForms
        {
            private Gum.Wireframe.GraphicalUiElement Visual;
            public PolygonScreenGumForms () 
            {
                CustomInitialize();
            }
            public PolygonScreenGumForms (Gum.Wireframe.GraphicalUiElement visual) 
            {
                Visual = visual;
                ReactToVisualChanged();
                CustomInitialize();
            }
            private void ReactToVisualChanged () 
            {
            }
            partial void CustomInitialize();
        }
    }
