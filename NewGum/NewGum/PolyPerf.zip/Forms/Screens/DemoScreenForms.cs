using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.FormsControls.Screens
{
    public partial class DemoScreenForms
    {
        partial void CustomInitialize () 
        {
        }
    }
}
