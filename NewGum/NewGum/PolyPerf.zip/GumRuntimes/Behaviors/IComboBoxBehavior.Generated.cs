    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum ComboBoxBehaviorComboBoxCategory
        {
            Enabled,
            Disabled,
            Highlighted,
            Pushed,
            HighlightedFocused,
            Focused,
            DisabledFocused
        }
        #endregion
        public interface IComboBoxBehavior
        {
            ComboBoxBehaviorComboBoxCategory CurrentComboBoxBehaviorComboBoxCategoryState {set;}
        }
    }
