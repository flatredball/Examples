    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum SliderBehaviorSliderCategory
        {
            Enabled,
            Focused
        }
        #endregion
        public interface ISliderBehavior
        {
            SliderBehaviorSliderCategory CurrentSliderBehaviorSliderCategoryState {set;}
        }
    }
