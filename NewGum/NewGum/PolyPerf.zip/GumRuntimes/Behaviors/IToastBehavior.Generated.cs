    namespace NewGum.GumRuntimes
    {
        #region State Enums
        #endregion
        public interface IToastBehavior
        {
        }
    }
