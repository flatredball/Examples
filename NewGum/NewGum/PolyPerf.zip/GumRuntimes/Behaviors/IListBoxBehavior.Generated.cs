    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum ListBoxBehaviorListBoxCategory
        {
            Enabled,
            Disabled,
            Focused,
            DisabledFocused
        }
        #endregion
        public interface IListBoxBehavior
        {
            ListBoxBehaviorListBoxCategory CurrentListBoxBehaviorListBoxCategoryState {set;}
        }
    }
