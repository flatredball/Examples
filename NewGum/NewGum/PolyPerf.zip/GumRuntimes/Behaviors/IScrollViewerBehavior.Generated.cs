    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum ScrollViewerBehaviorScrollBarVisibility
        {
            NoScrollBar,
            VerticalScrollVisible
        }
        #endregion
        public interface IScrollViewerBehavior
        {
            ScrollViewerBehaviorScrollBarVisibility CurrentScrollViewerBehaviorScrollBarVisibilityState {set;}
        }
    }
