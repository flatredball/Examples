    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum ListBoxItemBehaviorListBoxItemCategory
        {
            Enabled,
            Highlighted,
            Selected,
            Focused
        }
        #endregion
        public interface IListBoxItemBehavior
        {
            ListBoxItemBehaviorListBoxItemCategory CurrentListBoxItemBehaviorListBoxItemCategoryState {set;}
        }
    }
