    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum RadioButtonBehaviorRadioButtonCategory
        {
            EnabledOn,
            EnabledOff,
            DisabledOn,
            DisabledOff,
            HighlightedOn,
            HighlightedOff,
            PushedOn,
            PushedOff,
            FocusedOn,
            FocusedOff,
            HighlightedFocusedOn,
            HighlightedFocusedOff,
            DisabledFocusedOn,
            DisabledFocusedOff
        }
        #endregion
        public interface IRadioButtonBehavior
        {
            RadioButtonBehaviorRadioButtonCategory CurrentRadioButtonBehaviorRadioButtonCategoryState {set;}
        }
    }
