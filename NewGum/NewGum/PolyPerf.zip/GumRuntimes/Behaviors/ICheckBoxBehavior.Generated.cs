    namespace NewGum.GumRuntimes
    {
        #region State Enums
        public enum CheckBoxBehaviorCheckBoxCategory
        {
            EnabledOn,
            EnabledOff,
            DisabledOn,
            DisabledOff,
            HighlightedOn,
            HighlightedOff,
            PushedOn,
            PushedOff,
            FocusedOn,
            FocusedOff,
            HighlightedFocusedOn,
            HighlightedFocusedOff,
            DisabledFocusedOn,
            DisabledFocusedOff
        }
        #endregion
        public interface ICheckBoxBehavior
        {
            CheckBoxBehaviorCheckBoxCategory CurrentCheckBoxBehaviorCheckBoxCategoryState {set;}
        }
    }
