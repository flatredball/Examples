using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes.DefaultForms
{
    public partial class ComboBoxRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
