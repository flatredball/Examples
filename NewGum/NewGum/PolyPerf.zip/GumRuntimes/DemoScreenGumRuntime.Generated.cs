    using System.Linq;
    namespace NewGum.GumRuntimes
    {
        public partial class DemoScreenGumRuntime : Gum.Wireframe.GraphicalUiElement
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                            MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                            TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DetectResolutionsButton.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                            ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                            ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                            MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                            LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            HitpointsBar1.Parent = this.GetGraphicalUiElementByName("DemoHud");
                            HitpointsBar2.Parent = this.GetGraphicalUiElementByName("DemoHud");
                            HitpointsBar3.Parent = this.GetGraphicalUiElementByName("DemoHud");
                            PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            ContainerInstance.Parent = this.GetGraphicalUiElementByName("DemoHud");
                            TabMenuBackground.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                            TabMarginContainer.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                            TabMenuClose.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            TabHeaderDivider.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            ListContainer.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            PlayButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                            VideoSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                            AudioSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                            CreditsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                            ExitButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                            Tab3.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            Tab2.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            Tab1.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                            Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Background.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            TitleText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            TitleText1.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText1.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            RadioButtonInstance.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                            RadioButtonInstance1.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                            RadioButtonInstance2.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                            Background1.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Background1.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            DemoHud.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            DemoHud.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            TitleText2.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText2.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            HitpointsBar1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                            HitpointsBar1.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                            HitpointsBar2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            HitpointsBar2.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                            HitpointsBar3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                            HitpointsBar3.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                            PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                            PercentBarInstance1.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                            PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            PercentBarInstance2.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                            PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                            PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                            PercentBarInstance4.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                            PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                            TabMenuBackground.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            TabMenuBackground.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            PlayButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Play;
                            VideoSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Monitor;
                            AudioSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Music;
                            CreditsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Info;
                            ExitButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Power;
                            DemoSettingsMenu.Height = 16f;
                            DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            DemoSettingsMenu.Width = 400f;
                            DemoSettingsMenu.X = 40f;
                            DemoSettingsMenu.Y = 35f;
                            MenuTitle.Height = 8f;
                            MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle.Width = 0f;
                            MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuTitle1.Height = 8f;
                            MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle1.Width = 0f;
                            MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            MenuItems.Height = 0f;
                            MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuItems.Width = -16f;
                            MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuItems.X = 0f;
                            MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            MenuItems.Y = 0f;
                            MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TitleText.Text = "Settings";
                            TitleText1.Text = "New Profile";
                            ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DividerInstance.Width = 0f;
                            DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DividerInstance4.Width = 0f;
                            DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ResolutionLabel.LabelText = "Resolution";
                            ResolutionBox.Height = 128f;
                            ResolutionBox.Width = 0f;
                            ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DetectResolutionsButton.ButtonDisplayText = "Detect Resolutions";
                            DetectResolutionsButton.Height = 24f;
                            DetectResolutionsButton.X = 0f;
                            DetectResolutionsButton.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            DetectResolutionsButton.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DetectResolutionsButton.Y = 9f;
                            FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                            FullScreenCheckbox.X = 0f;
                            FullScreenCheckbox.Y = -26f;
                            DividerInstance1.Width = 0f;
                            DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance1.Y = 8f;
                            MusicLabel.LabelText = "Music Volume";
                            MusicLabel.Y = 8f;
                            MusicSlider.Width = 0f;
                            MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            SoundLabel.LabelText = "Sound Volume";
                            SoundSlider.Width = 0f;
                            SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance2.Width = 0f;
                            DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance2.Y = 8f;
                            ControlLabel.LabelText = "Control Scheme";
                            ControlLabel.Y = 8f;
                            RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                            RadioButtonInstance.Width = 0f;
                            RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance1.RadioDisplayText = "Gamepad";
                            RadioButtonInstance1.Width = 0f;
                            RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance1.Y = 4f;
                            RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                            RadioButtonInstance2.Width = 0f;
                            RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance2.Y = 4f;
                            DividerInstance3.Width = 0f;
                            DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance3.Y = 8f;
                            DifficultyLabel.LabelText = "Difficulty";
                            DifficultyLabel.Y = 8f;
                            Background1.Height = 0f;
                            Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background1.Width = 0f;
                            Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background1.X = 0f;
                            Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            Background1.Y = 0f;
                            Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            ComboBoxInstance.Width = 0f;
                            ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonContainer.Height = 32f;
                            ButtonContainer.Width = 0f;
                            ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonContainer.Y = 16f;
                            ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DemoDialog.Height = 163f;
                            DemoDialog.Width = 349f;
                            DemoDialog.X = 488f;
                            DemoDialog.Y = 42f;
                            MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            MarginContainer.Height = -16f;
                            MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MarginContainer.Width = -16f;
                            MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MarginContainer.X = 0f;
                            MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            MarginContainer.Y = 0f;
                            MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            LabelInstance.LabelText = "New Profile Name";
                            LabelInstance.Y = 8f;
                            TextBoxInstance.Width = 0f;
                            TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonConfirmInstance1.Y = 16f;
                            DemoHud.Height = 207f;
                            DemoHud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            DemoHud.Width = 279f;
                            DemoHud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            DemoHud.X = 486f;
                            DemoHud.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            DemoHud.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            DemoHud.Y = 218f;
                            DemoHud.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            DemoHud.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            TitleText2.Text = "HUD Demo";
                            MenuTitle2.Height = 8f;
                            MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle2.Width = 0f;
                            MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance.Width = 0f;
                            PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance.Y = 8f;
                            HitpointsBar1.BarPercent = 75f;
                            HitpointsBar1.Height = 8f;
                            HitpointsBar1.Width = 24f;
                            HitpointsBar1.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            HitpointsBar1.X = 184f;
                            HitpointsBar1.Y = 10f;
                            HitpointsBar2.BarPercent = 50f;
                            HitpointsBar2.Height = 8f;
                            HitpointsBar2.Width = 24f;
                            HitpointsBar2.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            HitpointsBar2.X = 184f;
                            HitpointsBar2.Y = 20f;
                            HitpointsBar3.BarPercent = 25f;
                            HitpointsBar3.Height = 8f;
                            HitpointsBar3.Width = 24f;
                            HitpointsBar3.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            HitpointsBar3.X = 184f;
                            HitpointsBar3.Y = 31f;
                            PercentBarInstance1.Width = 0f;
                            PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance1.Y = 8f;
                            PercentBarInstance2.Width = 0f;
                            PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance2.Y = 8f;
                            DividerInstance5.Width = 0f;
                            DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            PercentBarInstance3.Width = 0f;
                            PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance3.Y = 8f;
                            PercentBarInstance4.Width = 0f;
                            PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance4.Y = 8f;
                            PercentBarInstance5.Width = 0f;
                            PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance5.Y = 8f;
                            ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ContainerInstance.Height = -16f;
                            ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ContainerInstance.Width = -16f;
                            ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ContainerInstance.X = 0f;
                            ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            ContainerInstance.Y = 0f;
                            ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DemoTabbedMenu.Height = 256f;
                            DemoTabbedMenu.Width = 458f;
                            DemoTabbedMenu.X = 498f;
                            DemoTabbedMenu.Y = 456f;
                            TabMarginContainer.Height = -16f;
                            TabMarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TabMarginContainer.Width = -16f;
                            TabMarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TabMarginContainer.X = 0f;
                            TabMarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            TabMarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TabMarginContainer.Y = 0f;
                            TabMarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TabMarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TabMenuClose.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            TabMenuClose.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            TabHeaderDivider.Width = 0f;
                            TabHeaderDivider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TabHeaderDivider.X = 0f;
                            TabHeaderDivider.Y = 35f;
                            ListContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ListContainer.Height = -45f;
                            ListContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ListContainer.Width = 0f;
                            ListContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ListContainer.X = 0f;
                            ListContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            ListContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            ListContainer.Y = 0f;
                            ListContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            ListContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            PlayButton.ButtonDisplayText = "Start Game";
                            PlayButton.Width = 0f;
                            PlayButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            VideoSettingsButton.ButtonDisplayText = "Video Settings";
                            VideoSettingsButton.Width = 0f;
                            VideoSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            VideoSettingsButton.Y = 8f;
                            AudioSettingsButton.ButtonDisplayText = "Audio Settings";
                            AudioSettingsButton.Width = 0f;
                            AudioSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            AudioSettingsButton.Y = 8f;
                            CreditsButton.ButtonDisplayText = "Credits";
                            CreditsButton.Width = 0f;
                            CreditsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            CreditsButton.Y = 8f;
                            ExitButton.ButtonDisplayText = "Exit";
                            ExitButton.Width = 0f;
                            ExitButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ExitButton.Y = 8f;
                            Tab3.TabDisplayText = "Tab3";
                            Tab3.X = -72f;
                            Tab3.Y = 36f;
                            Tab2.TabDisplayText = "Tab 2";
                            Tab2.X = -124f;
                            Tab2.Y = 36f;
                            Tab1.TabDisplayText = "Settings";
                            Tab1.X = -184f;
                            Tab1.Y = 36f;
                            break;
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setAudioSettingsButtonWidthFirstValue = false;
                bool setAudioSettingsButtonWidthSecondValue = false;
                float AudioSettingsButtonWidthFirstValue= 0;
                float AudioSettingsButtonWidthSecondValue= 0;
                bool setAudioSettingsButtonYFirstValue = false;
                bool setAudioSettingsButtonYSecondValue = false;
                float AudioSettingsButtonYFirstValue= 0;
                float AudioSettingsButtonYSecondValue= 0;
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackground1CurrentColorCategoryStateFirstValue = false;
                bool setBackground1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory Background1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory Background1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackground1HeightFirstValue = false;
                bool setBackground1HeightSecondValue = false;
                float Background1HeightFirstValue= 0;
                float Background1HeightSecondValue= 0;
                bool setBackground1CurrentStyleCategoryStateFirstValue = false;
                bool setBackground1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory Background1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory Background1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackground1WidthFirstValue = false;
                bool setBackground1WidthSecondValue = false;
                float Background1WidthFirstValue= 0;
                float Background1WidthSecondValue= 0;
                bool setBackground1XFirstValue = false;
                bool setBackground1XSecondValue = false;
                float Background1XFirstValue= 0;
                float Background1XSecondValue= 0;
                bool setBackground1YFirstValue = false;
                bool setBackground1YSecondValue = false;
                float Background1YFirstValue= 0;
                float Background1YSecondValue= 0;
                bool setButtonConfirmInstance1YFirstValue = false;
                bool setButtonConfirmInstance1YSecondValue = false;
                float ButtonConfirmInstance1YFirstValue= 0;
                float ButtonConfirmInstance1YSecondValue= 0;
                bool setButtonContainerHeightFirstValue = false;
                bool setButtonContainerHeightSecondValue = false;
                float ButtonContainerHeightFirstValue= 0;
                float ButtonContainerHeightSecondValue= 0;
                bool setButtonContainerWidthFirstValue = false;
                bool setButtonContainerWidthSecondValue = false;
                float ButtonContainerWidthFirstValue= 0;
                float ButtonContainerWidthSecondValue= 0;
                bool setButtonContainerYFirstValue = false;
                bool setButtonContainerYSecondValue = false;
                float ButtonContainerYFirstValue= 0;
                float ButtonContainerYSecondValue= 0;
                bool setComboBoxInstanceWidthFirstValue = false;
                bool setComboBoxInstanceWidthSecondValue = false;
                float ComboBoxInstanceWidthFirstValue= 0;
                float ComboBoxInstanceWidthSecondValue= 0;
                bool setContainerInstanceHeightFirstValue = false;
                bool setContainerInstanceHeightSecondValue = false;
                float ContainerInstanceHeightFirstValue= 0;
                float ContainerInstanceHeightSecondValue= 0;
                bool setContainerInstanceWidthFirstValue = false;
                bool setContainerInstanceWidthSecondValue = false;
                float ContainerInstanceWidthFirstValue= 0;
                float ContainerInstanceWidthSecondValue= 0;
                bool setContainerInstanceXFirstValue = false;
                bool setContainerInstanceXSecondValue = false;
                float ContainerInstanceXFirstValue= 0;
                float ContainerInstanceXSecondValue= 0;
                bool setContainerInstanceYFirstValue = false;
                bool setContainerInstanceYSecondValue = false;
                float ContainerInstanceYFirstValue= 0;
                float ContainerInstanceYSecondValue= 0;
                bool setControlLabelYFirstValue = false;
                bool setControlLabelYSecondValue = false;
                float ControlLabelYFirstValue= 0;
                float ControlLabelYSecondValue= 0;
                bool setCreditsButtonWidthFirstValue = false;
                bool setCreditsButtonWidthSecondValue = false;
                float CreditsButtonWidthFirstValue= 0;
                float CreditsButtonWidthSecondValue= 0;
                bool setCreditsButtonYFirstValue = false;
                bool setCreditsButtonYSecondValue = false;
                float CreditsButtonYFirstValue= 0;
                float CreditsButtonYSecondValue= 0;
                bool setDemoDialogHeightFirstValue = false;
                bool setDemoDialogHeightSecondValue = false;
                float DemoDialogHeightFirstValue= 0;
                float DemoDialogHeightSecondValue= 0;
                bool setDemoDialogWidthFirstValue = false;
                bool setDemoDialogWidthSecondValue = false;
                float DemoDialogWidthFirstValue= 0;
                float DemoDialogWidthSecondValue= 0;
                bool setDemoDialogXFirstValue = false;
                bool setDemoDialogXSecondValue = false;
                float DemoDialogXFirstValue= 0;
                float DemoDialogXSecondValue= 0;
                bool setDemoDialogYFirstValue = false;
                bool setDemoDialogYSecondValue = false;
                float DemoDialogYFirstValue= 0;
                float DemoDialogYSecondValue= 0;
                bool setDemoHudCurrentColorCategoryStateFirstValue = false;
                bool setDemoHudCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory DemoHudCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory DemoHudCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setDemoHudHeightFirstValue = false;
                bool setDemoHudHeightSecondValue = false;
                float DemoHudHeightFirstValue= 0;
                float DemoHudHeightSecondValue= 0;
                bool setDemoHudCurrentStyleCategoryStateFirstValue = false;
                bool setDemoHudCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory DemoHudCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory DemoHudCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setDemoHudWidthFirstValue = false;
                bool setDemoHudWidthSecondValue = false;
                float DemoHudWidthFirstValue= 0;
                float DemoHudWidthSecondValue= 0;
                bool setDemoHudXFirstValue = false;
                bool setDemoHudXSecondValue = false;
                float DemoHudXFirstValue= 0;
                float DemoHudXSecondValue= 0;
                bool setDemoHudYFirstValue = false;
                bool setDemoHudYSecondValue = false;
                float DemoHudYFirstValue= 0;
                float DemoHudYSecondValue= 0;
                bool setDemoSettingsMenuHeightFirstValue = false;
                bool setDemoSettingsMenuHeightSecondValue = false;
                float DemoSettingsMenuHeightFirstValue= 0;
                float DemoSettingsMenuHeightSecondValue= 0;
                bool setDemoSettingsMenuWidthFirstValue = false;
                bool setDemoSettingsMenuWidthSecondValue = false;
                float DemoSettingsMenuWidthFirstValue= 0;
                float DemoSettingsMenuWidthSecondValue= 0;
                bool setDemoSettingsMenuXFirstValue = false;
                bool setDemoSettingsMenuXSecondValue = false;
                float DemoSettingsMenuXFirstValue= 0;
                float DemoSettingsMenuXSecondValue= 0;
                bool setDemoSettingsMenuYFirstValue = false;
                bool setDemoSettingsMenuYSecondValue = false;
                float DemoSettingsMenuYFirstValue= 0;
                float DemoSettingsMenuYSecondValue= 0;
                bool setDemoTabbedMenuHeightFirstValue = false;
                bool setDemoTabbedMenuHeightSecondValue = false;
                float DemoTabbedMenuHeightFirstValue= 0;
                float DemoTabbedMenuHeightSecondValue= 0;
                bool setDemoTabbedMenuWidthFirstValue = false;
                bool setDemoTabbedMenuWidthSecondValue = false;
                float DemoTabbedMenuWidthFirstValue= 0;
                float DemoTabbedMenuWidthSecondValue= 0;
                bool setDemoTabbedMenuXFirstValue = false;
                bool setDemoTabbedMenuXSecondValue = false;
                float DemoTabbedMenuXFirstValue= 0;
                float DemoTabbedMenuXSecondValue= 0;
                bool setDemoTabbedMenuYFirstValue = false;
                bool setDemoTabbedMenuYSecondValue = false;
                float DemoTabbedMenuYFirstValue= 0;
                float DemoTabbedMenuYSecondValue= 0;
                bool setDetectResolutionsButtonHeightFirstValue = false;
                bool setDetectResolutionsButtonHeightSecondValue = false;
                float DetectResolutionsButtonHeightFirstValue= 0;
                float DetectResolutionsButtonHeightSecondValue= 0;
                bool setDetectResolutionsButtonXFirstValue = false;
                bool setDetectResolutionsButtonXSecondValue = false;
                float DetectResolutionsButtonXFirstValue= 0;
                float DetectResolutionsButtonXSecondValue= 0;
                bool setDetectResolutionsButtonYFirstValue = false;
                bool setDetectResolutionsButtonYSecondValue = false;
                float DetectResolutionsButtonYFirstValue= 0;
                float DetectResolutionsButtonYSecondValue= 0;
                bool setDifficultyLabelYFirstValue = false;
                bool setDifficultyLabelYSecondValue = false;
                float DifficultyLabelYFirstValue= 0;
                float DifficultyLabelYSecondValue= 0;
                bool setDividerInstanceWidthFirstValue = false;
                bool setDividerInstanceWidthSecondValue = false;
                float DividerInstanceWidthFirstValue= 0;
                float DividerInstanceWidthSecondValue= 0;
                bool setDividerInstance1WidthFirstValue = false;
                bool setDividerInstance1WidthSecondValue = false;
                float DividerInstance1WidthFirstValue= 0;
                float DividerInstance1WidthSecondValue= 0;
                bool setDividerInstance1YFirstValue = false;
                bool setDividerInstance1YSecondValue = false;
                float DividerInstance1YFirstValue= 0;
                float DividerInstance1YSecondValue= 0;
                bool setDividerInstance2WidthFirstValue = false;
                bool setDividerInstance2WidthSecondValue = false;
                float DividerInstance2WidthFirstValue= 0;
                float DividerInstance2WidthSecondValue= 0;
                bool setDividerInstance2YFirstValue = false;
                bool setDividerInstance2YSecondValue = false;
                float DividerInstance2YFirstValue= 0;
                float DividerInstance2YSecondValue= 0;
                bool setDividerInstance3WidthFirstValue = false;
                bool setDividerInstance3WidthSecondValue = false;
                float DividerInstance3WidthFirstValue= 0;
                float DividerInstance3WidthSecondValue= 0;
                bool setDividerInstance3YFirstValue = false;
                bool setDividerInstance3YSecondValue = false;
                float DividerInstance3YFirstValue= 0;
                float DividerInstance3YSecondValue= 0;
                bool setDividerInstance4WidthFirstValue = false;
                bool setDividerInstance4WidthSecondValue = false;
                float DividerInstance4WidthFirstValue= 0;
                float DividerInstance4WidthSecondValue= 0;
                bool setDividerInstance5WidthFirstValue = false;
                bool setDividerInstance5WidthSecondValue = false;
                float DividerInstance5WidthFirstValue= 0;
                float DividerInstance5WidthSecondValue= 0;
                bool setExitButtonWidthFirstValue = false;
                bool setExitButtonWidthSecondValue = false;
                float ExitButtonWidthFirstValue= 0;
                float ExitButtonWidthSecondValue= 0;
                bool setExitButtonYFirstValue = false;
                bool setExitButtonYSecondValue = false;
                float ExitButtonYFirstValue= 0;
                float ExitButtonYSecondValue= 0;
                bool setFullScreenCheckboxXFirstValue = false;
                bool setFullScreenCheckboxXSecondValue = false;
                float FullScreenCheckboxXFirstValue= 0;
                float FullScreenCheckboxXSecondValue= 0;
                bool setFullScreenCheckboxYFirstValue = false;
                bool setFullScreenCheckboxYSecondValue = false;
                float FullScreenCheckboxYFirstValue= 0;
                float FullScreenCheckboxYSecondValue= 0;
                bool setHitpointsBar1CurrentBarDecorCategoryStateFirstValue = false;
                bool setHitpointsBar1CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar1CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar1CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setHitpointsBar1BarPercentFirstValue = false;
                bool setHitpointsBar1BarPercentSecondValue = false;
                float HitpointsBar1BarPercentFirstValue= 0;
                float HitpointsBar1BarPercentSecondValue= 0;
                bool setHitpointsBar1HeightFirstValue = false;
                bool setHitpointsBar1HeightSecondValue = false;
                float HitpointsBar1HeightFirstValue= 0;
                float HitpointsBar1HeightSecondValue= 0;
                bool setHitpointsBar1WidthFirstValue = false;
                bool setHitpointsBar1WidthSecondValue = false;
                float HitpointsBar1WidthFirstValue= 0;
                float HitpointsBar1WidthSecondValue= 0;
                bool setHitpointsBar1XFirstValue = false;
                bool setHitpointsBar1XSecondValue = false;
                float HitpointsBar1XFirstValue= 0;
                float HitpointsBar1XSecondValue= 0;
                bool setHitpointsBar1YFirstValue = false;
                bool setHitpointsBar1YSecondValue = false;
                float HitpointsBar1YFirstValue= 0;
                float HitpointsBar1YSecondValue= 0;
                bool setHitpointsBar2CurrentBarDecorCategoryStateFirstValue = false;
                bool setHitpointsBar2CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar2CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar2CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setHitpointsBar2BarPercentFirstValue = false;
                bool setHitpointsBar2BarPercentSecondValue = false;
                float HitpointsBar2BarPercentFirstValue= 0;
                float HitpointsBar2BarPercentSecondValue= 0;
                bool setHitpointsBar2HeightFirstValue = false;
                bool setHitpointsBar2HeightSecondValue = false;
                float HitpointsBar2HeightFirstValue= 0;
                float HitpointsBar2HeightSecondValue= 0;
                bool setHitpointsBar2WidthFirstValue = false;
                bool setHitpointsBar2WidthSecondValue = false;
                float HitpointsBar2WidthFirstValue= 0;
                float HitpointsBar2WidthSecondValue= 0;
                bool setHitpointsBar2XFirstValue = false;
                bool setHitpointsBar2XSecondValue = false;
                float HitpointsBar2XFirstValue= 0;
                float HitpointsBar2XSecondValue= 0;
                bool setHitpointsBar2YFirstValue = false;
                bool setHitpointsBar2YSecondValue = false;
                float HitpointsBar2YFirstValue= 0;
                float HitpointsBar2YSecondValue= 0;
                bool setHitpointsBar3CurrentBarDecorCategoryStateFirstValue = false;
                bool setHitpointsBar3CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar3CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory HitpointsBar3CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setHitpointsBar3BarPercentFirstValue = false;
                bool setHitpointsBar3BarPercentSecondValue = false;
                float HitpointsBar3BarPercentFirstValue= 0;
                float HitpointsBar3BarPercentSecondValue= 0;
                bool setHitpointsBar3HeightFirstValue = false;
                bool setHitpointsBar3HeightSecondValue = false;
                float HitpointsBar3HeightFirstValue= 0;
                float HitpointsBar3HeightSecondValue= 0;
                bool setHitpointsBar3WidthFirstValue = false;
                bool setHitpointsBar3WidthSecondValue = false;
                float HitpointsBar3WidthFirstValue= 0;
                float HitpointsBar3WidthSecondValue= 0;
                bool setHitpointsBar3XFirstValue = false;
                bool setHitpointsBar3XSecondValue = false;
                float HitpointsBar3XFirstValue= 0;
                float HitpointsBar3XSecondValue= 0;
                bool setHitpointsBar3YFirstValue = false;
                bool setHitpointsBar3YSecondValue = false;
                float HitpointsBar3YFirstValue= 0;
                float HitpointsBar3YSecondValue= 0;
                bool setLabelInstanceYFirstValue = false;
                bool setLabelInstanceYSecondValue = false;
                float LabelInstanceYFirstValue= 0;
                float LabelInstanceYSecondValue= 0;
                bool setListContainerHeightFirstValue = false;
                bool setListContainerHeightSecondValue = false;
                float ListContainerHeightFirstValue= 0;
                float ListContainerHeightSecondValue= 0;
                bool setListContainerWidthFirstValue = false;
                bool setListContainerWidthSecondValue = false;
                float ListContainerWidthFirstValue= 0;
                float ListContainerWidthSecondValue= 0;
                bool setListContainerXFirstValue = false;
                bool setListContainerXSecondValue = false;
                float ListContainerXFirstValue= 0;
                float ListContainerXSecondValue= 0;
                bool setListContainerYFirstValue = false;
                bool setListContainerYSecondValue = false;
                float ListContainerYFirstValue= 0;
                float ListContainerYSecondValue= 0;
                bool setMarginContainerHeightFirstValue = false;
                bool setMarginContainerHeightSecondValue = false;
                float MarginContainerHeightFirstValue= 0;
                float MarginContainerHeightSecondValue= 0;
                bool setMarginContainerWidthFirstValue = false;
                bool setMarginContainerWidthSecondValue = false;
                float MarginContainerWidthFirstValue= 0;
                float MarginContainerWidthSecondValue= 0;
                bool setMarginContainerXFirstValue = false;
                bool setMarginContainerXSecondValue = false;
                float MarginContainerXFirstValue= 0;
                float MarginContainerXSecondValue= 0;
                bool setMarginContainerYFirstValue = false;
                bool setMarginContainerYSecondValue = false;
                float MarginContainerYFirstValue= 0;
                float MarginContainerYSecondValue= 0;
                bool setMenuItemsHeightFirstValue = false;
                bool setMenuItemsHeightSecondValue = false;
                float MenuItemsHeightFirstValue= 0;
                float MenuItemsHeightSecondValue= 0;
                bool setMenuItemsWidthFirstValue = false;
                bool setMenuItemsWidthSecondValue = false;
                float MenuItemsWidthFirstValue= 0;
                float MenuItemsWidthSecondValue= 0;
                bool setMenuItemsXFirstValue = false;
                bool setMenuItemsXSecondValue = false;
                float MenuItemsXFirstValue= 0;
                float MenuItemsXSecondValue= 0;
                bool setMenuItemsYFirstValue = false;
                bool setMenuItemsYSecondValue = false;
                float MenuItemsYFirstValue= 0;
                float MenuItemsYSecondValue= 0;
                bool setMenuTitleHeightFirstValue = false;
                bool setMenuTitleHeightSecondValue = false;
                float MenuTitleHeightFirstValue= 0;
                float MenuTitleHeightSecondValue= 0;
                bool setMenuTitleWidthFirstValue = false;
                bool setMenuTitleWidthSecondValue = false;
                float MenuTitleWidthFirstValue= 0;
                float MenuTitleWidthSecondValue= 0;
                bool setMenuTitle1HeightFirstValue = false;
                bool setMenuTitle1HeightSecondValue = false;
                float MenuTitle1HeightFirstValue= 0;
                float MenuTitle1HeightSecondValue= 0;
                bool setMenuTitle1WidthFirstValue = false;
                bool setMenuTitle1WidthSecondValue = false;
                float MenuTitle1WidthFirstValue= 0;
                float MenuTitle1WidthSecondValue= 0;
                bool setMenuTitle2HeightFirstValue = false;
                bool setMenuTitle2HeightSecondValue = false;
                float MenuTitle2HeightFirstValue= 0;
                float MenuTitle2HeightSecondValue= 0;
                bool setMenuTitle2WidthFirstValue = false;
                bool setMenuTitle2WidthSecondValue = false;
                float MenuTitle2WidthFirstValue= 0;
                float MenuTitle2WidthSecondValue= 0;
                bool setMusicLabelYFirstValue = false;
                bool setMusicLabelYSecondValue = false;
                float MusicLabelYFirstValue= 0;
                float MusicLabelYSecondValue= 0;
                bool setMusicSliderWidthFirstValue = false;
                bool setMusicSliderWidthSecondValue = false;
                float MusicSliderWidthFirstValue= 0;
                float MusicSliderWidthSecondValue= 0;
                bool setPercentBarInstanceWidthFirstValue = false;
                bool setPercentBarInstanceWidthSecondValue = false;
                float PercentBarInstanceWidthFirstValue= 0;
                float PercentBarInstanceWidthSecondValue= 0;
                bool setPercentBarInstanceYFirstValue = false;
                bool setPercentBarInstanceYSecondValue = false;
                float PercentBarInstanceYFirstValue= 0;
                float PercentBarInstanceYSecondValue= 0;
                bool setPercentBarInstance1CurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarInstance1CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance1CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance1CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setPercentBarInstance1WidthFirstValue = false;
                bool setPercentBarInstance1WidthSecondValue = false;
                float PercentBarInstance1WidthFirstValue= 0;
                float PercentBarInstance1WidthSecondValue= 0;
                bool setPercentBarInstance1YFirstValue = false;
                bool setPercentBarInstance1YSecondValue = false;
                float PercentBarInstance1YFirstValue= 0;
                float PercentBarInstance1YSecondValue= 0;
                bool setPercentBarInstance2CurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarInstance2CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance2CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance2CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setPercentBarInstance2WidthFirstValue = false;
                bool setPercentBarInstance2WidthSecondValue = false;
                float PercentBarInstance2WidthFirstValue= 0;
                float PercentBarInstance2WidthSecondValue= 0;
                bool setPercentBarInstance2YFirstValue = false;
                bool setPercentBarInstance2YSecondValue = false;
                float PercentBarInstance2YFirstValue= 0;
                float PercentBarInstance2YSecondValue= 0;
                bool setPercentBarInstance3WidthFirstValue = false;
                bool setPercentBarInstance3WidthSecondValue = false;
                float PercentBarInstance3WidthFirstValue= 0;
                float PercentBarInstance3WidthSecondValue= 0;
                bool setPercentBarInstance3YFirstValue = false;
                bool setPercentBarInstance3YSecondValue = false;
                float PercentBarInstance3YFirstValue= 0;
                float PercentBarInstance3YSecondValue= 0;
                bool setPercentBarInstance4CurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarInstance4CurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance4CurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarInstance4CurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setPercentBarInstance4WidthFirstValue = false;
                bool setPercentBarInstance4WidthSecondValue = false;
                float PercentBarInstance4WidthFirstValue= 0;
                float PercentBarInstance4WidthSecondValue= 0;
                bool setPercentBarInstance4YFirstValue = false;
                bool setPercentBarInstance4YSecondValue = false;
                float PercentBarInstance4YFirstValue= 0;
                float PercentBarInstance4YSecondValue= 0;
                bool setPercentBarInstance5WidthFirstValue = false;
                bool setPercentBarInstance5WidthSecondValue = false;
                float PercentBarInstance5WidthFirstValue= 0;
                float PercentBarInstance5WidthSecondValue= 0;
                bool setPercentBarInstance5YFirstValue = false;
                bool setPercentBarInstance5YSecondValue = false;
                float PercentBarInstance5YFirstValue= 0;
                float PercentBarInstance5YSecondValue= 0;
                bool setPlayButtonWidthFirstValue = false;
                bool setPlayButtonWidthSecondValue = false;
                float PlayButtonWidthFirstValue= 0;
                float PlayButtonWidthSecondValue= 0;
                bool setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstanceWidthFirstValue = false;
                bool setRadioButtonInstanceWidthSecondValue = false;
                float RadioButtonInstanceWidthFirstValue= 0;
                float RadioButtonInstanceWidthSecondValue= 0;
                bool setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstance1WidthFirstValue = false;
                bool setRadioButtonInstance1WidthSecondValue = false;
                float RadioButtonInstance1WidthFirstValue= 0;
                float RadioButtonInstance1WidthSecondValue= 0;
                bool setRadioButtonInstance1YFirstValue = false;
                bool setRadioButtonInstance1YSecondValue = false;
                float RadioButtonInstance1YFirstValue= 0;
                float RadioButtonInstance1YSecondValue= 0;
                bool setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstance2WidthFirstValue = false;
                bool setRadioButtonInstance2WidthSecondValue = false;
                float RadioButtonInstance2WidthFirstValue= 0;
                float RadioButtonInstance2WidthSecondValue= 0;
                bool setRadioButtonInstance2YFirstValue = false;
                bool setRadioButtonInstance2YSecondValue = false;
                float RadioButtonInstance2YFirstValue= 0;
                float RadioButtonInstance2YSecondValue= 0;
                bool setResolutionBoxHeightFirstValue = false;
                bool setResolutionBoxHeightSecondValue = false;
                float ResolutionBoxHeightFirstValue= 0;
                float ResolutionBoxHeightSecondValue= 0;
                bool setResolutionBoxWidthFirstValue = false;
                bool setResolutionBoxWidthSecondValue = false;
                float ResolutionBoxWidthFirstValue= 0;
                float ResolutionBoxWidthSecondValue= 0;
                bool setSoundSliderWidthFirstValue = false;
                bool setSoundSliderWidthSecondValue = false;
                float SoundSliderWidthFirstValue= 0;
                float SoundSliderWidthSecondValue= 0;
                bool setTab1XFirstValue = false;
                bool setTab1XSecondValue = false;
                float Tab1XFirstValue= 0;
                float Tab1XSecondValue= 0;
                bool setTab1YFirstValue = false;
                bool setTab1YSecondValue = false;
                float Tab1YFirstValue= 0;
                float Tab1YSecondValue= 0;
                bool setTab2XFirstValue = false;
                bool setTab2XSecondValue = false;
                float Tab2XFirstValue= 0;
                float Tab2XSecondValue= 0;
                bool setTab2YFirstValue = false;
                bool setTab2YSecondValue = false;
                float Tab2YFirstValue= 0;
                float Tab2YSecondValue= 0;
                bool setTab3XFirstValue = false;
                bool setTab3XSecondValue = false;
                float Tab3XFirstValue= 0;
                float Tab3XSecondValue= 0;
                bool setTab3YFirstValue = false;
                bool setTab3YSecondValue = false;
                float Tab3YFirstValue= 0;
                float Tab3YSecondValue= 0;
                bool setTabHeaderDividerWidthFirstValue = false;
                bool setTabHeaderDividerWidthSecondValue = false;
                float TabHeaderDividerWidthFirstValue= 0;
                float TabHeaderDividerWidthSecondValue= 0;
                bool setTabHeaderDividerXFirstValue = false;
                bool setTabHeaderDividerXSecondValue = false;
                float TabHeaderDividerXFirstValue= 0;
                float TabHeaderDividerXSecondValue= 0;
                bool setTabHeaderDividerYFirstValue = false;
                bool setTabHeaderDividerYSecondValue = false;
                float TabHeaderDividerYFirstValue= 0;
                float TabHeaderDividerYSecondValue= 0;
                bool setTabMarginContainerHeightFirstValue = false;
                bool setTabMarginContainerHeightSecondValue = false;
                float TabMarginContainerHeightFirstValue= 0;
                float TabMarginContainerHeightSecondValue= 0;
                bool setTabMarginContainerWidthFirstValue = false;
                bool setTabMarginContainerWidthSecondValue = false;
                float TabMarginContainerWidthFirstValue= 0;
                float TabMarginContainerWidthSecondValue= 0;
                bool setTabMarginContainerXFirstValue = false;
                bool setTabMarginContainerXSecondValue = false;
                float TabMarginContainerXFirstValue= 0;
                float TabMarginContainerXSecondValue= 0;
                bool setTabMarginContainerYFirstValue = false;
                bool setTabMarginContainerYSecondValue = false;
                float TabMarginContainerYFirstValue= 0;
                float TabMarginContainerYSecondValue= 0;
                bool setTabMenuBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setTabMenuBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabMenuBackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabMenuBackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setTabMenuBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setTabMenuBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabMenuBackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabMenuBackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setTextBoxInstanceWidthFirstValue = false;
                bool setTextBoxInstanceWidthSecondValue = false;
                float TextBoxInstanceWidthFirstValue= 0;
                float TextBoxInstanceWidthSecondValue= 0;
                bool setTitleTextCurrentColorCategoryStateFirstValue = false;
                bool setTitleTextCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleTextCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleTextCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleTextCurrentStyleCategoryStateFirstValue = false;
                bool setTitleTextCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleTextCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleTextCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTitleText1CurrentColorCategoryStateFirstValue = false;
                bool setTitleText1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleText1CurrentStyleCategoryStateFirstValue = false;
                bool setTitleText1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTitleText2CurrentColorCategoryStateFirstValue = false;
                bool setTitleText2CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText2CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText2CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleText2CurrentStyleCategoryStateFirstValue = false;
                bool setTitleText2CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText2CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText2CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setVideoSettingsButtonWidthFirstValue = false;
                bool setVideoSettingsButtonWidthSecondValue = false;
                float VideoSettingsButtonWidthFirstValue= 0;
                float VideoSettingsButtonWidthSecondValue= 0;
                bool setVideoSettingsButtonYFirstValue = false;
                bool setVideoSettingsButtonYSecondValue = false;
                float VideoSettingsButtonYFirstValue= 0;
                float VideoSettingsButtonYSecondValue= 0;
                switch(firstState)
                {
                    case  VariableState.Default:
                        if (interpolationValue < 1)
                        {
                            this.AudioSettingsButton.ButtonDisplayText = "Audio Settings";
                        }
                        if (interpolationValue < 1)
                        {
                            this.AudioSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Music;
                        }
                        if (interpolationValue < 1)
                        {
                            this.AudioSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setAudioSettingsButtonWidthFirstValue = true;
                        AudioSettingsButtonWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.AudioSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setAudioSettingsButtonYFirstValue = true;
                        AudioSettingsButtonYFirstValue = 8f;
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setBackgroundCurrentStyleCategoryStateFirstValue = true;
                        BackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1CurrentColorCategoryStateFirstValue = true;
                        Background1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackground1HeightFirstValue = true;
                        Background1HeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setBackground1CurrentStyleCategoryStateFirstValue = true;
                        Background1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1WidthFirstValue = true;
                        Background1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackground1XFirstValue = true;
                        Background1XFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackground1YFirstValue = true;
                        Background1YFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setButtonConfirmInstance1YFirstValue = true;
                        ButtonConfirmInstance1YFirstValue = 16f;
                        setButtonContainerHeightFirstValue = true;
                        ButtonContainerHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setButtonContainerWidthFirstValue = true;
                        ButtonContainerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setButtonContainerYFirstValue = true;
                        ButtonContainerYFirstValue = 16f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setComboBoxInstanceWidthFirstValue = true;
                        ComboBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setContainerInstanceHeightFirstValue = true;
                        ContainerInstanceHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setContainerInstanceWidthFirstValue = true;
                        ContainerInstanceWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setContainerInstanceXFirstValue = true;
                        ContainerInstanceXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setContainerInstanceYFirstValue = true;
                        ContainerInstanceYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ControlLabel.LabelText = "Control Scheme";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setControlLabelYFirstValue = true;
                        ControlLabelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.CreditsButton.ButtonDisplayText = "Credits";
                        }
                        if (interpolationValue < 1)
                        {
                            this.CreditsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Info;
                        }
                        if (interpolationValue < 1)
                        {
                            this.CreditsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setCreditsButtonWidthFirstValue = true;
                        CreditsButtonWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.CreditsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setCreditsButtonYFirstValue = true;
                        CreditsButtonYFirstValue = 8f;
                        setDemoDialogHeightFirstValue = true;
                        DemoDialogHeightFirstValue = 163f;
                        setDemoDialogWidthFirstValue = true;
                        DemoDialogWidthFirstValue = 349f;
                        setDemoDialogXFirstValue = true;
                        DemoDialogXFirstValue = 488f;
                        setDemoDialogYFirstValue = true;
                        DemoDialogYFirstValue = 42f;
                        setDemoHudCurrentColorCategoryStateFirstValue = true;
                        DemoHudCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setDemoHudHeightFirstValue = true;
                        DemoHudHeightFirstValue = 207f;
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoHudCurrentStyleCategoryStateFirstValue = true;
                        DemoHudCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setDemoHudWidthFirstValue = true;
                        DemoHudWidthFirstValue = 279f;
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoHudXFirstValue = true;
                        DemoHudXFirstValue = 486f;
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setDemoHudYFirstValue = true;
                        DemoHudYFirstValue = 218f;
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DemoHud.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setDemoSettingsMenuHeightFirstValue = true;
                        DemoSettingsMenuHeightFirstValue = 16f;
                        if (interpolationValue < 1)
                        {
                            this.DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setDemoSettingsMenuWidthFirstValue = true;
                        DemoSettingsMenuWidthFirstValue = 400f;
                        setDemoSettingsMenuXFirstValue = true;
                        DemoSettingsMenuXFirstValue = 40f;
                        setDemoSettingsMenuYFirstValue = true;
                        DemoSettingsMenuYFirstValue = 35f;
                        setDemoTabbedMenuHeightFirstValue = true;
                        DemoTabbedMenuHeightFirstValue = 256f;
                        setDemoTabbedMenuWidthFirstValue = true;
                        DemoTabbedMenuWidthFirstValue = 458f;
                        setDemoTabbedMenuXFirstValue = true;
                        DemoTabbedMenuXFirstValue = 498f;
                        setDemoTabbedMenuYFirstValue = true;
                        DemoTabbedMenuYFirstValue = 456f;
                        if (interpolationValue < 1)
                        {
                            this.DetectResolutionsButton.ButtonDisplayText = "Detect Resolutions";
                        }
                        setDetectResolutionsButtonHeightFirstValue = true;
                        DetectResolutionsButtonHeightFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.DetectResolutionsButton.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDetectResolutionsButtonXFirstValue = true;
                        DetectResolutionsButtonXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DetectResolutionsButton.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DetectResolutionsButton.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setDetectResolutionsButtonYFirstValue = true;
                        DetectResolutionsButtonYFirstValue = 9f;
                        if (interpolationValue < 1)
                        {
                            this.DifficultyLabel.LabelText = "Difficulty";
                        }
                        if (interpolationValue < 1)
                        {
                            this.DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDifficultyLabelYFirstValue = true;
                        DifficultyLabelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setDividerInstanceWidthFirstValue = true;
                        DividerInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance1WidthFirstValue = true;
                        DividerInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance1YFirstValue = true;
                        DividerInstance1YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance2WidthFirstValue = true;
                        DividerInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance2YFirstValue = true;
                        DividerInstance2YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance3WidthFirstValue = true;
                        DividerInstance3WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance3YFirstValue = true;
                        DividerInstance3YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setDividerInstance4WidthFirstValue = true;
                        DividerInstance4WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setDividerInstance5WidthFirstValue = true;
                        DividerInstance5WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ExitButton.ButtonDisplayText = "Exit";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ExitButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Power;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ExitButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setExitButtonWidthFirstValue = true;
                        ExitButtonWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ExitButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setExitButtonYFirstValue = true;
                        ExitButtonYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                        }
                        if (interpolationValue < 1)
                        {
                            this.FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setFullScreenCheckboxXFirstValue = true;
                        FullScreenCheckboxXFirstValue = 0f;
                        setFullScreenCheckboxYFirstValue = true;
                        FullScreenCheckboxYFirstValue = -26f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        setHitpointsBar1CurrentBarDecorCategoryStateFirstValue = true;
                        HitpointsBar1CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar1BarPercentFirstValue = true;
                        HitpointsBar1BarPercentFirstValue = 75f;
                        setHitpointsBar1HeightFirstValue = true;
                        HitpointsBar1HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar1.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar1WidthFirstValue = true;
                        HitpointsBar1WidthFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar1.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar1XFirstValue = true;
                        HitpointsBar1XFirstValue = 184f;
                        setHitpointsBar1YFirstValue = true;
                        HitpointsBar1YFirstValue = 10f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        setHitpointsBar2CurrentBarDecorCategoryStateFirstValue = true;
                        HitpointsBar2CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar2BarPercentFirstValue = true;
                        HitpointsBar2BarPercentFirstValue = 50f;
                        setHitpointsBar2HeightFirstValue = true;
                        HitpointsBar2HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar2.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar2WidthFirstValue = true;
                        HitpointsBar2WidthFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar2.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar2XFirstValue = true;
                        HitpointsBar2XFirstValue = 184f;
                        setHitpointsBar2YFirstValue = true;
                        HitpointsBar2YFirstValue = 20f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        setHitpointsBar3CurrentBarDecorCategoryStateFirstValue = true;
                        HitpointsBar3CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar3BarPercentFirstValue = true;
                        HitpointsBar3BarPercentFirstValue = 25f;
                        setHitpointsBar3HeightFirstValue = true;
                        HitpointsBar3HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar3.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar3WidthFirstValue = true;
                        HitpointsBar3WidthFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.HitpointsBar3.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar3XFirstValue = true;
                        HitpointsBar3XFirstValue = 184f;
                        setHitpointsBar3YFirstValue = true;
                        HitpointsBar3YFirstValue = 31f;
                        if (interpolationValue < 1)
                        {
                            this.LabelInstance.LabelText = "New Profile Name";
                        }
                        if (interpolationValue < 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setLabelInstanceYFirstValue = true;
                        LabelInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setListContainerHeightFirstValue = true;
                        ListContainerHeightFirstValue = -45f;
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        setListContainerWidthFirstValue = true;
                        ListContainerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setListContainerXFirstValue = true;
                        ListContainerXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setListContainerYFirstValue = true;
                        ListContainerYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ListContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMarginContainerHeightFirstValue = true;
                        MarginContainerHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setMarginContainerWidthFirstValue = true;
                        MarginContainerWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMarginContainerXFirstValue = true;
                        MarginContainerXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMarginContainerYFirstValue = true;
                        MarginContainerYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMenuItemsHeightFirstValue = true;
                        MenuItemsHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setMenuItemsWidthFirstValue = true;
                        MenuItemsWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuItemsXFirstValue = true;
                        MenuItemsXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuItemsYFirstValue = true;
                        MenuItemsYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuTitleHeightFirstValue = true;
                        MenuTitleHeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMenuTitleWidthFirstValue = true;
                        MenuTitleWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle1HeightFirstValue = true;
                        MenuTitle1HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setMenuTitle1WidthFirstValue = true;
                        MenuTitle1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle2HeightFirstValue = true;
                        MenuTitle2HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setMenuTitle2WidthFirstValue = true;
                        MenuTitle2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MusicLabel.LabelText = "Music Volume";
                        }
                        if (interpolationValue < 1)
                        {
                            this.MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicLabelYFirstValue = true;
                        MusicLabelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicSliderWidthFirstValue = true;
                        MusicSliderWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstanceWidthFirstValue = true;
                        PercentBarInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstanceYFirstValue = true;
                        PercentBarInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        setPercentBarInstance1CurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarInstance1CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance1WidthFirstValue = true;
                        PercentBarInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance1YFirstValue = true;
                        PercentBarInstance1YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        setPercentBarInstance2CurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarInstance2CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance2WidthFirstValue = true;
                        PercentBarInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance2YFirstValue = true;
                        PercentBarInstance2YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance3WidthFirstValue = true;
                        PercentBarInstance3WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance3YFirstValue = true;
                        PercentBarInstance3YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        }
                        setPercentBarInstance4CurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarInstance4CurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance4WidthFirstValue = true;
                        PercentBarInstance4WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance4YFirstValue = true;
                        PercentBarInstance4YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance5WidthFirstValue = true;
                        PercentBarInstance5WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance5YFirstValue = true;
                        PercentBarInstance5YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PlayButton.ButtonDisplayText = "Start Game";
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlayButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Play;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlayButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setPlayButtonWidthFirstValue = true;
                        PlayButtonWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PlayButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                        }
                        setRadioButtonInstanceWidthFirstValue = true;
                        RadioButtonInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.RadioDisplayText = "Gamepad";
                        }
                        setRadioButtonInstance1WidthFirstValue = true;
                        RadioButtonInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance1YFirstValue = true;
                        RadioButtonInstance1YFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                        }
                        setRadioButtonInstance2WidthFirstValue = true;
                        RadioButtonInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance2YFirstValue = true;
                        RadioButtonInstance2YFirstValue = 4f;
                        setResolutionBoxHeightFirstValue = true;
                        ResolutionBoxHeightFirstValue = 128f;
                        if (interpolationValue < 1)
                        {
                            this.ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setResolutionBoxWidthFirstValue = true;
                        ResolutionBoxWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ResolutionLabel.LabelText = "Resolution";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundLabel.LabelText = "Sound Volume";
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setSoundSliderWidthFirstValue = true;
                        SoundSliderWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab1.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab1.TabDisplayText = "Settings";
                        }
                        setTab1XFirstValue = true;
                        Tab1XFirstValue = -184f;
                        setTab1YFirstValue = true;
                        Tab1YFirstValue = 36f;
                        if (interpolationValue < 1)
                        {
                            this.Tab2.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab2.TabDisplayText = "Tab 2";
                        }
                        setTab2XFirstValue = true;
                        Tab2XFirstValue = -124f;
                        setTab2YFirstValue = true;
                        Tab2YFirstValue = 36f;
                        if (interpolationValue < 1)
                        {
                            this.Tab3.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab3.TabDisplayText = "Tab3";
                        }
                        setTab3XFirstValue = true;
                        Tab3XFirstValue = -72f;
                        setTab3YFirstValue = true;
                        Tab3YFirstValue = 36f;
                        if (interpolationValue < 1)
                        {
                            this.TabHeaderDivider.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        setTabHeaderDividerWidthFirstValue = true;
                        TabHeaderDividerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TabHeaderDivider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTabHeaderDividerXFirstValue = true;
                        TabHeaderDividerXFirstValue = 0f;
                        setTabHeaderDividerYFirstValue = true;
                        TabHeaderDividerYFirstValue = 35f;
                        setTabMarginContainerHeightFirstValue = true;
                        TabMarginContainerHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                        }
                        setTabMarginContainerWidthFirstValue = true;
                        TabMarginContainerWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTabMarginContainerXFirstValue = true;
                        TabMarginContainerXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setTabMarginContainerYFirstValue = true;
                        TabMarginContainerYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabMarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setTabMenuBackgroundCurrentColorCategoryStateFirstValue = true;
                        TabMenuBackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TabMenuBackground.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                        }
                        setTabMenuBackgroundCurrentStyleCategoryStateFirstValue = true;
                        TabMenuBackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        if (interpolationValue < 1)
                        {
                            this.TabMenuClose.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabMenuClose.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabMenuClose.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setTextBoxInstanceWidthFirstValue = true;
                        TextBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTitleTextCurrentColorCategoryStateFirstValue = true;
                        TitleTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setTitleTextCurrentStyleCategoryStateFirstValue = true;
                        TitleTextCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText.Text = "Settings";
                        }
                        setTitleText1CurrentColorCategoryStateFirstValue = true;
                        TitleText1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setTitleText1CurrentStyleCategoryStateFirstValue = true;
                        TitleText1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText1.Text = "New Profile";
                        }
                        setTitleText2CurrentColorCategoryStateFirstValue = true;
                        TitleText2CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setTitleText2CurrentStyleCategoryStateFirstValue = true;
                        TitleText2CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText2.Text = "HUD Demo";
                        }
                        if (interpolationValue < 1)
                        {
                            this.VideoSettingsButton.ButtonDisplayText = "Video Settings";
                        }
                        if (interpolationValue < 1)
                        {
                            this.VideoSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Monitor;
                        }
                        if (interpolationValue < 1)
                        {
                            this.VideoSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setVideoSettingsButtonWidthFirstValue = true;
                        VideoSettingsButtonWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.VideoSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setVideoSettingsButtonYFirstValue = true;
                        VideoSettingsButtonYFirstValue = 8f;
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        if (interpolationValue >= 1)
                        {
                            this.AudioSettingsButton.ButtonDisplayText = "Audio Settings";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.AudioSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Music;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.AudioSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setAudioSettingsButtonWidthSecondValue = true;
                        AudioSettingsButtonWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.AudioSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setAudioSettingsButtonYSecondValue = true;
                        AudioSettingsButtonYSecondValue = 8f;
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setBackgroundCurrentStyleCategoryStateSecondValue = true;
                        BackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1CurrentColorCategoryStateSecondValue = true;
                        Background1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackground1HeightSecondValue = true;
                        Background1HeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setBackground1CurrentStyleCategoryStateSecondValue = true;
                        Background1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1WidthSecondValue = true;
                        Background1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackground1XSecondValue = true;
                        Background1XSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackground1YSecondValue = true;
                        Background1YSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setButtonConfirmInstance1YSecondValue = true;
                        ButtonConfirmInstance1YSecondValue = 16f;
                        setButtonContainerHeightSecondValue = true;
                        ButtonContainerHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setButtonContainerWidthSecondValue = true;
                        ButtonContainerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setButtonContainerYSecondValue = true;
                        ButtonContainerYSecondValue = 16f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setComboBoxInstanceWidthSecondValue = true;
                        ComboBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setContainerInstanceHeightSecondValue = true;
                        ContainerInstanceHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setContainerInstanceWidthSecondValue = true;
                        ContainerInstanceWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setContainerInstanceXSecondValue = true;
                        ContainerInstanceXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setContainerInstanceYSecondValue = true;
                        ContainerInstanceYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ControlLabel.LabelText = "Control Scheme";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setControlLabelYSecondValue = true;
                        ControlLabelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.CreditsButton.ButtonDisplayText = "Credits";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CreditsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Info;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CreditsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setCreditsButtonWidthSecondValue = true;
                        CreditsButtonWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.CreditsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setCreditsButtonYSecondValue = true;
                        CreditsButtonYSecondValue = 8f;
                        setDemoDialogHeightSecondValue = true;
                        DemoDialogHeightSecondValue = 163f;
                        setDemoDialogWidthSecondValue = true;
                        DemoDialogWidthSecondValue = 349f;
                        setDemoDialogXSecondValue = true;
                        DemoDialogXSecondValue = 488f;
                        setDemoDialogYSecondValue = true;
                        DemoDialogYSecondValue = 42f;
                        setDemoHudCurrentColorCategoryStateSecondValue = true;
                        DemoHudCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setDemoHudHeightSecondValue = true;
                        DemoHudHeightSecondValue = 207f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoHudCurrentStyleCategoryStateSecondValue = true;
                        DemoHudCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setDemoHudWidthSecondValue = true;
                        DemoHudWidthSecondValue = 279f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoHudXSecondValue = true;
                        DemoHudXSecondValue = 486f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setDemoHudYSecondValue = true;
                        DemoHudYSecondValue = 218f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DemoHud.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setDemoSettingsMenuHeightSecondValue = true;
                        DemoSettingsMenuHeightSecondValue = 16f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setDemoSettingsMenuWidthSecondValue = true;
                        DemoSettingsMenuWidthSecondValue = 400f;
                        setDemoSettingsMenuXSecondValue = true;
                        DemoSettingsMenuXSecondValue = 40f;
                        setDemoSettingsMenuYSecondValue = true;
                        DemoSettingsMenuYSecondValue = 35f;
                        setDemoTabbedMenuHeightSecondValue = true;
                        DemoTabbedMenuHeightSecondValue = 256f;
                        setDemoTabbedMenuWidthSecondValue = true;
                        DemoTabbedMenuWidthSecondValue = 458f;
                        setDemoTabbedMenuXSecondValue = true;
                        DemoTabbedMenuXSecondValue = 498f;
                        setDemoTabbedMenuYSecondValue = true;
                        DemoTabbedMenuYSecondValue = 456f;
                        if (interpolationValue >= 1)
                        {
                            this.DetectResolutionsButton.ButtonDisplayText = "Detect Resolutions";
                        }
                        setDetectResolutionsButtonHeightSecondValue = true;
                        DetectResolutionsButtonHeightSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.DetectResolutionsButton.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDetectResolutionsButtonXSecondValue = true;
                        DetectResolutionsButtonXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DetectResolutionsButton.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DetectResolutionsButton.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setDetectResolutionsButtonYSecondValue = true;
                        DetectResolutionsButtonYSecondValue = 9f;
                        if (interpolationValue >= 1)
                        {
                            this.DifficultyLabel.LabelText = "Difficulty";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDifficultyLabelYSecondValue = true;
                        DifficultyLabelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setDividerInstanceWidthSecondValue = true;
                        DividerInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance1WidthSecondValue = true;
                        DividerInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance1YSecondValue = true;
                        DividerInstance1YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance2WidthSecondValue = true;
                        DividerInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance2YSecondValue = true;
                        DividerInstance2YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance3WidthSecondValue = true;
                        DividerInstance3WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance3YSecondValue = true;
                        DividerInstance3YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setDividerInstance4WidthSecondValue = true;
                        DividerInstance4WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setDividerInstance5WidthSecondValue = true;
                        DividerInstance5WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ExitButton.ButtonDisplayText = "Exit";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ExitButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Power;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ExitButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setExitButtonWidthSecondValue = true;
                        ExitButtonWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ExitButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setExitButtonYSecondValue = true;
                        ExitButtonYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setFullScreenCheckboxXSecondValue = true;
                        FullScreenCheckboxXSecondValue = 0f;
                        setFullScreenCheckboxYSecondValue = true;
                        FullScreenCheckboxYSecondValue = -26f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        setHitpointsBar1CurrentBarDecorCategoryStateSecondValue = true;
                        HitpointsBar1CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar1BarPercentSecondValue = true;
                        HitpointsBar1BarPercentSecondValue = 75f;
                        setHitpointsBar1HeightSecondValue = true;
                        HitpointsBar1HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar1.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar1WidthSecondValue = true;
                        HitpointsBar1WidthSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar1.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar1XSecondValue = true;
                        HitpointsBar1XSecondValue = 184f;
                        setHitpointsBar1YSecondValue = true;
                        HitpointsBar1YSecondValue = 10f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        setHitpointsBar2CurrentBarDecorCategoryStateSecondValue = true;
                        HitpointsBar2CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar2BarPercentSecondValue = true;
                        HitpointsBar2BarPercentSecondValue = 50f;
                        setHitpointsBar2HeightSecondValue = true;
                        HitpointsBar2HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar2.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar2WidthSecondValue = true;
                        HitpointsBar2WidthSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar2.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar2XSecondValue = true;
                        HitpointsBar2XSecondValue = 184f;
                        setHitpointsBar2YSecondValue = true;
                        HitpointsBar2YSecondValue = 20f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        setHitpointsBar3CurrentBarDecorCategoryStateSecondValue = true;
                        HitpointsBar3CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        setHitpointsBar3BarPercentSecondValue = true;
                        HitpointsBar3BarPercentSecondValue = 25f;
                        setHitpointsBar3HeightSecondValue = true;
                        HitpointsBar3HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar3.Parent = this.GetGraphicalUiElementByName("DemoHud");
                        }
                        setHitpointsBar3WidthSecondValue = true;
                        HitpointsBar3WidthSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.HitpointsBar3.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHitpointsBar3XSecondValue = true;
                        HitpointsBar3XSecondValue = 184f;
                        setHitpointsBar3YSecondValue = true;
                        HitpointsBar3YSecondValue = 31f;
                        if (interpolationValue >= 1)
                        {
                            this.LabelInstance.LabelText = "New Profile Name";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setLabelInstanceYSecondValue = true;
                        LabelInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setListContainerHeightSecondValue = true;
                        ListContainerHeightSecondValue = -45f;
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        setListContainerWidthSecondValue = true;
                        ListContainerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setListContainerXSecondValue = true;
                        ListContainerXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setListContainerYSecondValue = true;
                        ListContainerYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ListContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMarginContainerHeightSecondValue = true;
                        MarginContainerHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setMarginContainerWidthSecondValue = true;
                        MarginContainerWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMarginContainerXSecondValue = true;
                        MarginContainerXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMarginContainerYSecondValue = true;
                        MarginContainerYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMenuItemsHeightSecondValue = true;
                        MenuItemsHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setMenuItemsWidthSecondValue = true;
                        MenuItemsWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuItemsXSecondValue = true;
                        MenuItemsXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuItemsYSecondValue = true;
                        MenuItemsYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuTitleHeightSecondValue = true;
                        MenuTitleHeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMenuTitleWidthSecondValue = true;
                        MenuTitleWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle1HeightSecondValue = true;
                        MenuTitle1HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setMenuTitle1WidthSecondValue = true;
                        MenuTitle1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle2HeightSecondValue = true;
                        MenuTitle2HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setMenuTitle2WidthSecondValue = true;
                        MenuTitle2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MusicLabel.LabelText = "Music Volume";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicLabelYSecondValue = true;
                        MusicLabelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicSliderWidthSecondValue = true;
                        MusicSliderWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstanceWidthSecondValue = true;
                        PercentBarInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstanceYSecondValue = true;
                        PercentBarInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        setPercentBarInstance1CurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarInstance1CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance1WidthSecondValue = true;
                        PercentBarInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance1YSecondValue = true;
                        PercentBarInstance1YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        setPercentBarInstance2CurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarInstance2CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance2WidthSecondValue = true;
                        PercentBarInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance2YSecondValue = true;
                        PercentBarInstance2YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance3WidthSecondValue = true;
                        PercentBarInstance3WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance3YSecondValue = true;
                        PercentBarInstance3YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        }
                        setPercentBarInstance4CurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarInstance4CurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance4WidthSecondValue = true;
                        PercentBarInstance4WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance4YSecondValue = true;
                        PercentBarInstance4YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance5WidthSecondValue = true;
                        PercentBarInstance5WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance5YSecondValue = true;
                        PercentBarInstance5YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PlayButton.ButtonDisplayText = "Start Game";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlayButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Play;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlayButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setPlayButtonWidthSecondValue = true;
                        PlayButtonWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PlayButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                        }
                        setRadioButtonInstanceWidthSecondValue = true;
                        RadioButtonInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.RadioDisplayText = "Gamepad";
                        }
                        setRadioButtonInstance1WidthSecondValue = true;
                        RadioButtonInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance1YSecondValue = true;
                        RadioButtonInstance1YSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                        }
                        setRadioButtonInstance2WidthSecondValue = true;
                        RadioButtonInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance2YSecondValue = true;
                        RadioButtonInstance2YSecondValue = 4f;
                        setResolutionBoxHeightSecondValue = true;
                        ResolutionBoxHeightSecondValue = 128f;
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setResolutionBoxWidthSecondValue = true;
                        ResolutionBoxWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionLabel.LabelText = "Resolution";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundLabel.LabelText = "Sound Volume";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setSoundSliderWidthSecondValue = true;
                        SoundSliderWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab1.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab1.TabDisplayText = "Settings";
                        }
                        setTab1XSecondValue = true;
                        Tab1XSecondValue = -184f;
                        setTab1YSecondValue = true;
                        Tab1YSecondValue = 36f;
                        if (interpolationValue >= 1)
                        {
                            this.Tab2.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab2.TabDisplayText = "Tab 2";
                        }
                        setTab2XSecondValue = true;
                        Tab2XSecondValue = -124f;
                        setTab2YSecondValue = true;
                        Tab2YSecondValue = 36f;
                        if (interpolationValue >= 1)
                        {
                            this.Tab3.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab3.TabDisplayText = "Tab3";
                        }
                        setTab3XSecondValue = true;
                        Tab3XSecondValue = -72f;
                        setTab3YSecondValue = true;
                        Tab3YSecondValue = 36f;
                        if (interpolationValue >= 1)
                        {
                            this.TabHeaderDivider.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        setTabHeaderDividerWidthSecondValue = true;
                        TabHeaderDividerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TabHeaderDivider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTabHeaderDividerXSecondValue = true;
                        TabHeaderDividerXSecondValue = 0f;
                        setTabHeaderDividerYSecondValue = true;
                        TabHeaderDividerYSecondValue = 35f;
                        setTabMarginContainerHeightSecondValue = true;
                        TabMarginContainerHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                        }
                        setTabMarginContainerWidthSecondValue = true;
                        TabMarginContainerWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTabMarginContainerXSecondValue = true;
                        TabMarginContainerXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setTabMarginContainerYSecondValue = true;
                        TabMarginContainerYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabMarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setTabMenuBackgroundCurrentColorCategoryStateSecondValue = true;
                        TabMenuBackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TabMenuBackground.Parent = this.GetGraphicalUiElementByName("DemoTabbedMenu");
                        }
                        setTabMenuBackgroundCurrentStyleCategoryStateSecondValue = true;
                        TabMenuBackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        if (interpolationValue >= 1)
                        {
                            this.TabMenuClose.Parent = this.GetGraphicalUiElementByName("TabMarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabMenuClose.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabMenuClose.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setTextBoxInstanceWidthSecondValue = true;
                        TextBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTitleTextCurrentColorCategoryStateSecondValue = true;
                        TitleTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setTitleTextCurrentStyleCategoryStateSecondValue = true;
                        TitleTextCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText.Text = "Settings";
                        }
                        setTitleText1CurrentColorCategoryStateSecondValue = true;
                        TitleText1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setTitleText1CurrentStyleCategoryStateSecondValue = true;
                        TitleText1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText1.Text = "New Profile";
                        }
                        setTitleText2CurrentColorCategoryStateSecondValue = true;
                        TitleText2CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setTitleText2CurrentStyleCategoryStateSecondValue = true;
                        TitleText2CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText2.Text = "HUD Demo";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.VideoSettingsButton.ButtonDisplayText = "Video Settings";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.VideoSettingsButton.ButtonIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Monitor;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.VideoSettingsButton.Parent = this.GetGraphicalUiElementByName("ListContainer");
                        }
                        setVideoSettingsButtonWidthSecondValue = true;
                        VideoSettingsButtonWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.VideoSettingsButton.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setVideoSettingsButtonYSecondValue = true;
                        VideoSettingsButtonYSecondValue = 8f;
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setAudioSettingsButtonWidthFirstValue && setAudioSettingsButtonWidthSecondValue)
                {
                    AudioSettingsButton.Width = AudioSettingsButtonWidthFirstValue * (1 - interpolationValue) + AudioSettingsButtonWidthSecondValue * interpolationValue;
                }
                if (setAudioSettingsButtonYFirstValue && setAudioSettingsButtonYSecondValue)
                {
                    AudioSettingsButton.Y = AudioSettingsButtonYFirstValue * (1 - interpolationValue) + AudioSettingsButtonYSecondValue * interpolationValue;
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundCurrentStyleCategoryStateFirstValue && setBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentStyleCategoryStateFirstValue, BackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1CurrentColorCategoryStateFirstValue && setBackground1CurrentColorCategoryStateSecondValue)
                {
                    Background1.InterpolateBetween(Background1CurrentColorCategoryStateFirstValue, Background1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1HeightFirstValue && setBackground1HeightSecondValue)
                {
                    Background1.Height = Background1HeightFirstValue * (1 - interpolationValue) + Background1HeightSecondValue * interpolationValue;
                }
                if (setBackground1CurrentStyleCategoryStateFirstValue && setBackground1CurrentStyleCategoryStateSecondValue)
                {
                    Background1.InterpolateBetween(Background1CurrentStyleCategoryStateFirstValue, Background1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1WidthFirstValue && setBackground1WidthSecondValue)
                {
                    Background1.Width = Background1WidthFirstValue * (1 - interpolationValue) + Background1WidthSecondValue * interpolationValue;
                }
                if (setBackground1XFirstValue && setBackground1XSecondValue)
                {
                    Background1.X = Background1XFirstValue * (1 - interpolationValue) + Background1XSecondValue * interpolationValue;
                }
                if (setBackground1YFirstValue && setBackground1YSecondValue)
                {
                    Background1.Y = Background1YFirstValue * (1 - interpolationValue) + Background1YSecondValue * interpolationValue;
                }
                if (setButtonConfirmInstance1YFirstValue && setButtonConfirmInstance1YSecondValue)
                {
                    ButtonConfirmInstance1.Y = ButtonConfirmInstance1YFirstValue * (1 - interpolationValue) + ButtonConfirmInstance1YSecondValue * interpolationValue;
                }
                if (setButtonContainerHeightFirstValue && setButtonContainerHeightSecondValue)
                {
                    ButtonContainer.Height = ButtonContainerHeightFirstValue * (1 - interpolationValue) + ButtonContainerHeightSecondValue * interpolationValue;
                }
                if (setButtonContainerWidthFirstValue && setButtonContainerWidthSecondValue)
                {
                    ButtonContainer.Width = ButtonContainerWidthFirstValue * (1 - interpolationValue) + ButtonContainerWidthSecondValue * interpolationValue;
                }
                if (setButtonContainerYFirstValue && setButtonContainerYSecondValue)
                {
                    ButtonContainer.Y = ButtonContainerYFirstValue * (1 - interpolationValue) + ButtonContainerYSecondValue * interpolationValue;
                }
                if (setComboBoxInstanceWidthFirstValue && setComboBoxInstanceWidthSecondValue)
                {
                    ComboBoxInstance.Width = ComboBoxInstanceWidthFirstValue * (1 - interpolationValue) + ComboBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setContainerInstanceHeightFirstValue && setContainerInstanceHeightSecondValue)
                {
                    ContainerInstance.Height = ContainerInstanceHeightFirstValue * (1 - interpolationValue) + ContainerInstanceHeightSecondValue * interpolationValue;
                }
                if (setContainerInstanceWidthFirstValue && setContainerInstanceWidthSecondValue)
                {
                    ContainerInstance.Width = ContainerInstanceWidthFirstValue * (1 - interpolationValue) + ContainerInstanceWidthSecondValue * interpolationValue;
                }
                if (setContainerInstanceXFirstValue && setContainerInstanceXSecondValue)
                {
                    ContainerInstance.X = ContainerInstanceXFirstValue * (1 - interpolationValue) + ContainerInstanceXSecondValue * interpolationValue;
                }
                if (setContainerInstanceYFirstValue && setContainerInstanceYSecondValue)
                {
                    ContainerInstance.Y = ContainerInstanceYFirstValue * (1 - interpolationValue) + ContainerInstanceYSecondValue * interpolationValue;
                }
                if (setControlLabelYFirstValue && setControlLabelYSecondValue)
                {
                    ControlLabel.Y = ControlLabelYFirstValue * (1 - interpolationValue) + ControlLabelYSecondValue * interpolationValue;
                }
                if (setCreditsButtonWidthFirstValue && setCreditsButtonWidthSecondValue)
                {
                    CreditsButton.Width = CreditsButtonWidthFirstValue * (1 - interpolationValue) + CreditsButtonWidthSecondValue * interpolationValue;
                }
                if (setCreditsButtonYFirstValue && setCreditsButtonYSecondValue)
                {
                    CreditsButton.Y = CreditsButtonYFirstValue * (1 - interpolationValue) + CreditsButtonYSecondValue * interpolationValue;
                }
                if (setDemoDialogHeightFirstValue && setDemoDialogHeightSecondValue)
                {
                    DemoDialog.Height = DemoDialogHeightFirstValue * (1 - interpolationValue) + DemoDialogHeightSecondValue * interpolationValue;
                }
                if (setDemoDialogWidthFirstValue && setDemoDialogWidthSecondValue)
                {
                    DemoDialog.Width = DemoDialogWidthFirstValue * (1 - interpolationValue) + DemoDialogWidthSecondValue * interpolationValue;
                }
                if (setDemoDialogXFirstValue && setDemoDialogXSecondValue)
                {
                    DemoDialog.X = DemoDialogXFirstValue * (1 - interpolationValue) + DemoDialogXSecondValue * interpolationValue;
                }
                if (setDemoDialogYFirstValue && setDemoDialogYSecondValue)
                {
                    DemoDialog.Y = DemoDialogYFirstValue * (1 - interpolationValue) + DemoDialogYSecondValue * interpolationValue;
                }
                if (setDemoHudCurrentColorCategoryStateFirstValue && setDemoHudCurrentColorCategoryStateSecondValue)
                {
                    DemoHud.InterpolateBetween(DemoHudCurrentColorCategoryStateFirstValue, DemoHudCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setDemoHudHeightFirstValue && setDemoHudHeightSecondValue)
                {
                    DemoHud.Height = DemoHudHeightFirstValue * (1 - interpolationValue) + DemoHudHeightSecondValue * interpolationValue;
                }
                if (setDemoHudCurrentStyleCategoryStateFirstValue && setDemoHudCurrentStyleCategoryStateSecondValue)
                {
                    DemoHud.InterpolateBetween(DemoHudCurrentStyleCategoryStateFirstValue, DemoHudCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setDemoHudWidthFirstValue && setDemoHudWidthSecondValue)
                {
                    DemoHud.Width = DemoHudWidthFirstValue * (1 - interpolationValue) + DemoHudWidthSecondValue * interpolationValue;
                }
                if (setDemoHudXFirstValue && setDemoHudXSecondValue)
                {
                    DemoHud.X = DemoHudXFirstValue * (1 - interpolationValue) + DemoHudXSecondValue * interpolationValue;
                }
                if (setDemoHudYFirstValue && setDemoHudYSecondValue)
                {
                    DemoHud.Y = DemoHudYFirstValue * (1 - interpolationValue) + DemoHudYSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuHeightFirstValue && setDemoSettingsMenuHeightSecondValue)
                {
                    DemoSettingsMenu.Height = DemoSettingsMenuHeightFirstValue * (1 - interpolationValue) + DemoSettingsMenuHeightSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuWidthFirstValue && setDemoSettingsMenuWidthSecondValue)
                {
                    DemoSettingsMenu.Width = DemoSettingsMenuWidthFirstValue * (1 - interpolationValue) + DemoSettingsMenuWidthSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuXFirstValue && setDemoSettingsMenuXSecondValue)
                {
                    DemoSettingsMenu.X = DemoSettingsMenuXFirstValue * (1 - interpolationValue) + DemoSettingsMenuXSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuYFirstValue && setDemoSettingsMenuYSecondValue)
                {
                    DemoSettingsMenu.Y = DemoSettingsMenuYFirstValue * (1 - interpolationValue) + DemoSettingsMenuYSecondValue * interpolationValue;
                }
                if (setDemoTabbedMenuHeightFirstValue && setDemoTabbedMenuHeightSecondValue)
                {
                    DemoTabbedMenu.Height = DemoTabbedMenuHeightFirstValue * (1 - interpolationValue) + DemoTabbedMenuHeightSecondValue * interpolationValue;
                }
                if (setDemoTabbedMenuWidthFirstValue && setDemoTabbedMenuWidthSecondValue)
                {
                    DemoTabbedMenu.Width = DemoTabbedMenuWidthFirstValue * (1 - interpolationValue) + DemoTabbedMenuWidthSecondValue * interpolationValue;
                }
                if (setDemoTabbedMenuXFirstValue && setDemoTabbedMenuXSecondValue)
                {
                    DemoTabbedMenu.X = DemoTabbedMenuXFirstValue * (1 - interpolationValue) + DemoTabbedMenuXSecondValue * interpolationValue;
                }
                if (setDemoTabbedMenuYFirstValue && setDemoTabbedMenuYSecondValue)
                {
                    DemoTabbedMenu.Y = DemoTabbedMenuYFirstValue * (1 - interpolationValue) + DemoTabbedMenuYSecondValue * interpolationValue;
                }
                if (setDetectResolutionsButtonHeightFirstValue && setDetectResolutionsButtonHeightSecondValue)
                {
                    DetectResolutionsButton.Height = DetectResolutionsButtonHeightFirstValue * (1 - interpolationValue) + DetectResolutionsButtonHeightSecondValue * interpolationValue;
                }
                if (setDetectResolutionsButtonXFirstValue && setDetectResolutionsButtonXSecondValue)
                {
                    DetectResolutionsButton.X = DetectResolutionsButtonXFirstValue * (1 - interpolationValue) + DetectResolutionsButtonXSecondValue * interpolationValue;
                }
                if (setDetectResolutionsButtonYFirstValue && setDetectResolutionsButtonYSecondValue)
                {
                    DetectResolutionsButton.Y = DetectResolutionsButtonYFirstValue * (1 - interpolationValue) + DetectResolutionsButtonYSecondValue * interpolationValue;
                }
                if (setDifficultyLabelYFirstValue && setDifficultyLabelYSecondValue)
                {
                    DifficultyLabel.Y = DifficultyLabelYFirstValue * (1 - interpolationValue) + DifficultyLabelYSecondValue * interpolationValue;
                }
                if (setDividerInstanceWidthFirstValue && setDividerInstanceWidthSecondValue)
                {
                    DividerInstance.Width = DividerInstanceWidthFirstValue * (1 - interpolationValue) + DividerInstanceWidthSecondValue * interpolationValue;
                }
                if (setDividerInstance1WidthFirstValue && setDividerInstance1WidthSecondValue)
                {
                    DividerInstance1.Width = DividerInstance1WidthFirstValue * (1 - interpolationValue) + DividerInstance1WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance1YFirstValue && setDividerInstance1YSecondValue)
                {
                    DividerInstance1.Y = DividerInstance1YFirstValue * (1 - interpolationValue) + DividerInstance1YSecondValue * interpolationValue;
                }
                if (setDividerInstance2WidthFirstValue && setDividerInstance2WidthSecondValue)
                {
                    DividerInstance2.Width = DividerInstance2WidthFirstValue * (1 - interpolationValue) + DividerInstance2WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance2YFirstValue && setDividerInstance2YSecondValue)
                {
                    DividerInstance2.Y = DividerInstance2YFirstValue * (1 - interpolationValue) + DividerInstance2YSecondValue * interpolationValue;
                }
                if (setDividerInstance3WidthFirstValue && setDividerInstance3WidthSecondValue)
                {
                    DividerInstance3.Width = DividerInstance3WidthFirstValue * (1 - interpolationValue) + DividerInstance3WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance3YFirstValue && setDividerInstance3YSecondValue)
                {
                    DividerInstance3.Y = DividerInstance3YFirstValue * (1 - interpolationValue) + DividerInstance3YSecondValue * interpolationValue;
                }
                if (setDividerInstance4WidthFirstValue && setDividerInstance4WidthSecondValue)
                {
                    DividerInstance4.Width = DividerInstance4WidthFirstValue * (1 - interpolationValue) + DividerInstance4WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance5WidthFirstValue && setDividerInstance5WidthSecondValue)
                {
                    DividerInstance5.Width = DividerInstance5WidthFirstValue * (1 - interpolationValue) + DividerInstance5WidthSecondValue * interpolationValue;
                }
                if (setExitButtonWidthFirstValue && setExitButtonWidthSecondValue)
                {
                    ExitButton.Width = ExitButtonWidthFirstValue * (1 - interpolationValue) + ExitButtonWidthSecondValue * interpolationValue;
                }
                if (setExitButtonYFirstValue && setExitButtonYSecondValue)
                {
                    ExitButton.Y = ExitButtonYFirstValue * (1 - interpolationValue) + ExitButtonYSecondValue * interpolationValue;
                }
                if (setFullScreenCheckboxXFirstValue && setFullScreenCheckboxXSecondValue)
                {
                    FullScreenCheckbox.X = FullScreenCheckboxXFirstValue * (1 - interpolationValue) + FullScreenCheckboxXSecondValue * interpolationValue;
                }
                if (setFullScreenCheckboxYFirstValue && setFullScreenCheckboxYSecondValue)
                {
                    FullScreenCheckbox.Y = FullScreenCheckboxYFirstValue * (1 - interpolationValue) + FullScreenCheckboxYSecondValue * interpolationValue;
                }
                if (setHitpointsBar1CurrentBarDecorCategoryStateFirstValue && setHitpointsBar1CurrentBarDecorCategoryStateSecondValue)
                {
                    HitpointsBar1.InterpolateBetween(HitpointsBar1CurrentBarDecorCategoryStateFirstValue, HitpointsBar1CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setHitpointsBar1BarPercentFirstValue && setHitpointsBar1BarPercentSecondValue)
                {
                    HitpointsBar1.BarPercent = HitpointsBar1BarPercentFirstValue * (1 - interpolationValue) + HitpointsBar1BarPercentSecondValue * interpolationValue;
                }
                if (setHitpointsBar1HeightFirstValue && setHitpointsBar1HeightSecondValue)
                {
                    HitpointsBar1.Height = HitpointsBar1HeightFirstValue * (1 - interpolationValue) + HitpointsBar1HeightSecondValue * interpolationValue;
                }
                if (setHitpointsBar1WidthFirstValue && setHitpointsBar1WidthSecondValue)
                {
                    HitpointsBar1.Width = HitpointsBar1WidthFirstValue * (1 - interpolationValue) + HitpointsBar1WidthSecondValue * interpolationValue;
                }
                if (setHitpointsBar1XFirstValue && setHitpointsBar1XSecondValue)
                {
                    HitpointsBar1.X = HitpointsBar1XFirstValue * (1 - interpolationValue) + HitpointsBar1XSecondValue * interpolationValue;
                }
                if (setHitpointsBar1YFirstValue && setHitpointsBar1YSecondValue)
                {
                    HitpointsBar1.Y = HitpointsBar1YFirstValue * (1 - interpolationValue) + HitpointsBar1YSecondValue * interpolationValue;
                }
                if (setHitpointsBar2CurrentBarDecorCategoryStateFirstValue && setHitpointsBar2CurrentBarDecorCategoryStateSecondValue)
                {
                    HitpointsBar2.InterpolateBetween(HitpointsBar2CurrentBarDecorCategoryStateFirstValue, HitpointsBar2CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setHitpointsBar2BarPercentFirstValue && setHitpointsBar2BarPercentSecondValue)
                {
                    HitpointsBar2.BarPercent = HitpointsBar2BarPercentFirstValue * (1 - interpolationValue) + HitpointsBar2BarPercentSecondValue * interpolationValue;
                }
                if (setHitpointsBar2HeightFirstValue && setHitpointsBar2HeightSecondValue)
                {
                    HitpointsBar2.Height = HitpointsBar2HeightFirstValue * (1 - interpolationValue) + HitpointsBar2HeightSecondValue * interpolationValue;
                }
                if (setHitpointsBar2WidthFirstValue && setHitpointsBar2WidthSecondValue)
                {
                    HitpointsBar2.Width = HitpointsBar2WidthFirstValue * (1 - interpolationValue) + HitpointsBar2WidthSecondValue * interpolationValue;
                }
                if (setHitpointsBar2XFirstValue && setHitpointsBar2XSecondValue)
                {
                    HitpointsBar2.X = HitpointsBar2XFirstValue * (1 - interpolationValue) + HitpointsBar2XSecondValue * interpolationValue;
                }
                if (setHitpointsBar2YFirstValue && setHitpointsBar2YSecondValue)
                {
                    HitpointsBar2.Y = HitpointsBar2YFirstValue * (1 - interpolationValue) + HitpointsBar2YSecondValue * interpolationValue;
                }
                if (setHitpointsBar3CurrentBarDecorCategoryStateFirstValue && setHitpointsBar3CurrentBarDecorCategoryStateSecondValue)
                {
                    HitpointsBar3.InterpolateBetween(HitpointsBar3CurrentBarDecorCategoryStateFirstValue, HitpointsBar3CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setHitpointsBar3BarPercentFirstValue && setHitpointsBar3BarPercentSecondValue)
                {
                    HitpointsBar3.BarPercent = HitpointsBar3BarPercentFirstValue * (1 - interpolationValue) + HitpointsBar3BarPercentSecondValue * interpolationValue;
                }
                if (setHitpointsBar3HeightFirstValue && setHitpointsBar3HeightSecondValue)
                {
                    HitpointsBar3.Height = HitpointsBar3HeightFirstValue * (1 - interpolationValue) + HitpointsBar3HeightSecondValue * interpolationValue;
                }
                if (setHitpointsBar3WidthFirstValue && setHitpointsBar3WidthSecondValue)
                {
                    HitpointsBar3.Width = HitpointsBar3WidthFirstValue * (1 - interpolationValue) + HitpointsBar3WidthSecondValue * interpolationValue;
                }
                if (setHitpointsBar3XFirstValue && setHitpointsBar3XSecondValue)
                {
                    HitpointsBar3.X = HitpointsBar3XFirstValue * (1 - interpolationValue) + HitpointsBar3XSecondValue * interpolationValue;
                }
                if (setHitpointsBar3YFirstValue && setHitpointsBar3YSecondValue)
                {
                    HitpointsBar3.Y = HitpointsBar3YFirstValue * (1 - interpolationValue) + HitpointsBar3YSecondValue * interpolationValue;
                }
                if (setLabelInstanceYFirstValue && setLabelInstanceYSecondValue)
                {
                    LabelInstance.Y = LabelInstanceYFirstValue * (1 - interpolationValue) + LabelInstanceYSecondValue * interpolationValue;
                }
                if (setListContainerHeightFirstValue && setListContainerHeightSecondValue)
                {
                    ListContainer.Height = ListContainerHeightFirstValue * (1 - interpolationValue) + ListContainerHeightSecondValue * interpolationValue;
                }
                if (setListContainerWidthFirstValue && setListContainerWidthSecondValue)
                {
                    ListContainer.Width = ListContainerWidthFirstValue * (1 - interpolationValue) + ListContainerWidthSecondValue * interpolationValue;
                }
                if (setListContainerXFirstValue && setListContainerXSecondValue)
                {
                    ListContainer.X = ListContainerXFirstValue * (1 - interpolationValue) + ListContainerXSecondValue * interpolationValue;
                }
                if (setListContainerYFirstValue && setListContainerYSecondValue)
                {
                    ListContainer.Y = ListContainerYFirstValue * (1 - interpolationValue) + ListContainerYSecondValue * interpolationValue;
                }
                if (setMarginContainerHeightFirstValue && setMarginContainerHeightSecondValue)
                {
                    MarginContainer.Height = MarginContainerHeightFirstValue * (1 - interpolationValue) + MarginContainerHeightSecondValue * interpolationValue;
                }
                if (setMarginContainerWidthFirstValue && setMarginContainerWidthSecondValue)
                {
                    MarginContainer.Width = MarginContainerWidthFirstValue * (1 - interpolationValue) + MarginContainerWidthSecondValue * interpolationValue;
                }
                if (setMarginContainerXFirstValue && setMarginContainerXSecondValue)
                {
                    MarginContainer.X = MarginContainerXFirstValue * (1 - interpolationValue) + MarginContainerXSecondValue * interpolationValue;
                }
                if (setMarginContainerYFirstValue && setMarginContainerYSecondValue)
                {
                    MarginContainer.Y = MarginContainerYFirstValue * (1 - interpolationValue) + MarginContainerYSecondValue * interpolationValue;
                }
                if (setMenuItemsHeightFirstValue && setMenuItemsHeightSecondValue)
                {
                    MenuItems.Height = MenuItemsHeightFirstValue * (1 - interpolationValue) + MenuItemsHeightSecondValue * interpolationValue;
                }
                if (setMenuItemsWidthFirstValue && setMenuItemsWidthSecondValue)
                {
                    MenuItems.Width = MenuItemsWidthFirstValue * (1 - interpolationValue) + MenuItemsWidthSecondValue * interpolationValue;
                }
                if (setMenuItemsXFirstValue && setMenuItemsXSecondValue)
                {
                    MenuItems.X = MenuItemsXFirstValue * (1 - interpolationValue) + MenuItemsXSecondValue * interpolationValue;
                }
                if (setMenuItemsYFirstValue && setMenuItemsYSecondValue)
                {
                    MenuItems.Y = MenuItemsYFirstValue * (1 - interpolationValue) + MenuItemsYSecondValue * interpolationValue;
                }
                if (setMenuTitleHeightFirstValue && setMenuTitleHeightSecondValue)
                {
                    MenuTitle.Height = MenuTitleHeightFirstValue * (1 - interpolationValue) + MenuTitleHeightSecondValue * interpolationValue;
                }
                if (setMenuTitleWidthFirstValue && setMenuTitleWidthSecondValue)
                {
                    MenuTitle.Width = MenuTitleWidthFirstValue * (1 - interpolationValue) + MenuTitleWidthSecondValue * interpolationValue;
                }
                if (setMenuTitle1HeightFirstValue && setMenuTitle1HeightSecondValue)
                {
                    MenuTitle1.Height = MenuTitle1HeightFirstValue * (1 - interpolationValue) + MenuTitle1HeightSecondValue * interpolationValue;
                }
                if (setMenuTitle1WidthFirstValue && setMenuTitle1WidthSecondValue)
                {
                    MenuTitle1.Width = MenuTitle1WidthFirstValue * (1 - interpolationValue) + MenuTitle1WidthSecondValue * interpolationValue;
                }
                if (setMenuTitle2HeightFirstValue && setMenuTitle2HeightSecondValue)
                {
                    MenuTitle2.Height = MenuTitle2HeightFirstValue * (1 - interpolationValue) + MenuTitle2HeightSecondValue * interpolationValue;
                }
                if (setMenuTitle2WidthFirstValue && setMenuTitle2WidthSecondValue)
                {
                    MenuTitle2.Width = MenuTitle2WidthFirstValue * (1 - interpolationValue) + MenuTitle2WidthSecondValue * interpolationValue;
                }
                if (setMusicLabelYFirstValue && setMusicLabelYSecondValue)
                {
                    MusicLabel.Y = MusicLabelYFirstValue * (1 - interpolationValue) + MusicLabelYSecondValue * interpolationValue;
                }
                if (setMusicSliderWidthFirstValue && setMusicSliderWidthSecondValue)
                {
                    MusicSlider.Width = MusicSliderWidthFirstValue * (1 - interpolationValue) + MusicSliderWidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstanceWidthFirstValue && setPercentBarInstanceWidthSecondValue)
                {
                    PercentBarInstance.Width = PercentBarInstanceWidthFirstValue * (1 - interpolationValue) + PercentBarInstanceWidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstanceYFirstValue && setPercentBarInstanceYSecondValue)
                {
                    PercentBarInstance.Y = PercentBarInstanceYFirstValue * (1 - interpolationValue) + PercentBarInstanceYSecondValue * interpolationValue;
                }
                if (setPercentBarInstance1CurrentBarDecorCategoryStateFirstValue && setPercentBarInstance1CurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarInstance1.InterpolateBetween(PercentBarInstance1CurrentBarDecorCategoryStateFirstValue, PercentBarInstance1CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarInstance1WidthFirstValue && setPercentBarInstance1WidthSecondValue)
                {
                    PercentBarInstance1.Width = PercentBarInstance1WidthFirstValue * (1 - interpolationValue) + PercentBarInstance1WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance1YFirstValue && setPercentBarInstance1YSecondValue)
                {
                    PercentBarInstance1.Y = PercentBarInstance1YFirstValue * (1 - interpolationValue) + PercentBarInstance1YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance2CurrentBarDecorCategoryStateFirstValue && setPercentBarInstance2CurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarInstance2.InterpolateBetween(PercentBarInstance2CurrentBarDecorCategoryStateFirstValue, PercentBarInstance2CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarInstance2WidthFirstValue && setPercentBarInstance2WidthSecondValue)
                {
                    PercentBarInstance2.Width = PercentBarInstance2WidthFirstValue * (1 - interpolationValue) + PercentBarInstance2WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance2YFirstValue && setPercentBarInstance2YSecondValue)
                {
                    PercentBarInstance2.Y = PercentBarInstance2YFirstValue * (1 - interpolationValue) + PercentBarInstance2YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance3WidthFirstValue && setPercentBarInstance3WidthSecondValue)
                {
                    PercentBarInstance3.Width = PercentBarInstance3WidthFirstValue * (1 - interpolationValue) + PercentBarInstance3WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance3YFirstValue && setPercentBarInstance3YSecondValue)
                {
                    PercentBarInstance3.Y = PercentBarInstance3YFirstValue * (1 - interpolationValue) + PercentBarInstance3YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance4CurrentBarDecorCategoryStateFirstValue && setPercentBarInstance4CurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarInstance4.InterpolateBetween(PercentBarInstance4CurrentBarDecorCategoryStateFirstValue, PercentBarInstance4CurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarInstance4WidthFirstValue && setPercentBarInstance4WidthSecondValue)
                {
                    PercentBarInstance4.Width = PercentBarInstance4WidthFirstValue * (1 - interpolationValue) + PercentBarInstance4WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance4YFirstValue && setPercentBarInstance4YSecondValue)
                {
                    PercentBarInstance4.Y = PercentBarInstance4YFirstValue * (1 - interpolationValue) + PercentBarInstance4YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance5WidthFirstValue && setPercentBarInstance5WidthSecondValue)
                {
                    PercentBarInstance5.Width = PercentBarInstance5WidthFirstValue * (1 - interpolationValue) + PercentBarInstance5WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance5YFirstValue && setPercentBarInstance5YSecondValue)
                {
                    PercentBarInstance5.Y = PercentBarInstance5YFirstValue * (1 - interpolationValue) + PercentBarInstance5YSecondValue * interpolationValue;
                }
                if (setPlayButtonWidthFirstValue && setPlayButtonWidthSecondValue)
                {
                    PlayButton.Width = PlayButtonWidthFirstValue * (1 - interpolationValue) + PlayButtonWidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance.InterpolateBetween(RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue, RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstanceWidthFirstValue && setRadioButtonInstanceWidthSecondValue)
                {
                    RadioButtonInstance.Width = RadioButtonInstanceWidthFirstValue * (1 - interpolationValue) + RadioButtonInstanceWidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance1.InterpolateBetween(RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue, RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstance1WidthFirstValue && setRadioButtonInstance1WidthSecondValue)
                {
                    RadioButtonInstance1.Width = RadioButtonInstance1WidthFirstValue * (1 - interpolationValue) + RadioButtonInstance1WidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance1YFirstValue && setRadioButtonInstance1YSecondValue)
                {
                    RadioButtonInstance1.Y = RadioButtonInstance1YFirstValue * (1 - interpolationValue) + RadioButtonInstance1YSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance2.InterpolateBetween(RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue, RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstance2WidthFirstValue && setRadioButtonInstance2WidthSecondValue)
                {
                    RadioButtonInstance2.Width = RadioButtonInstance2WidthFirstValue * (1 - interpolationValue) + RadioButtonInstance2WidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance2YFirstValue && setRadioButtonInstance2YSecondValue)
                {
                    RadioButtonInstance2.Y = RadioButtonInstance2YFirstValue * (1 - interpolationValue) + RadioButtonInstance2YSecondValue * interpolationValue;
                }
                if (setResolutionBoxHeightFirstValue && setResolutionBoxHeightSecondValue)
                {
                    ResolutionBox.Height = ResolutionBoxHeightFirstValue * (1 - interpolationValue) + ResolutionBoxHeightSecondValue * interpolationValue;
                }
                if (setResolutionBoxWidthFirstValue && setResolutionBoxWidthSecondValue)
                {
                    ResolutionBox.Width = ResolutionBoxWidthFirstValue * (1 - interpolationValue) + ResolutionBoxWidthSecondValue * interpolationValue;
                }
                if (setSoundSliderWidthFirstValue && setSoundSliderWidthSecondValue)
                {
                    SoundSlider.Width = SoundSliderWidthFirstValue * (1 - interpolationValue) + SoundSliderWidthSecondValue * interpolationValue;
                }
                if (setTab1XFirstValue && setTab1XSecondValue)
                {
                    Tab1.X = Tab1XFirstValue * (1 - interpolationValue) + Tab1XSecondValue * interpolationValue;
                }
                if (setTab1YFirstValue && setTab1YSecondValue)
                {
                    Tab1.Y = Tab1YFirstValue * (1 - interpolationValue) + Tab1YSecondValue * interpolationValue;
                }
                if (setTab2XFirstValue && setTab2XSecondValue)
                {
                    Tab2.X = Tab2XFirstValue * (1 - interpolationValue) + Tab2XSecondValue * interpolationValue;
                }
                if (setTab2YFirstValue && setTab2YSecondValue)
                {
                    Tab2.Y = Tab2YFirstValue * (1 - interpolationValue) + Tab2YSecondValue * interpolationValue;
                }
                if (setTab3XFirstValue && setTab3XSecondValue)
                {
                    Tab3.X = Tab3XFirstValue * (1 - interpolationValue) + Tab3XSecondValue * interpolationValue;
                }
                if (setTab3YFirstValue && setTab3YSecondValue)
                {
                    Tab3.Y = Tab3YFirstValue * (1 - interpolationValue) + Tab3YSecondValue * interpolationValue;
                }
                if (setTabHeaderDividerWidthFirstValue && setTabHeaderDividerWidthSecondValue)
                {
                    TabHeaderDivider.Width = TabHeaderDividerWidthFirstValue * (1 - interpolationValue) + TabHeaderDividerWidthSecondValue * interpolationValue;
                }
                if (setTabHeaderDividerXFirstValue && setTabHeaderDividerXSecondValue)
                {
                    TabHeaderDivider.X = TabHeaderDividerXFirstValue * (1 - interpolationValue) + TabHeaderDividerXSecondValue * interpolationValue;
                }
                if (setTabHeaderDividerYFirstValue && setTabHeaderDividerYSecondValue)
                {
                    TabHeaderDivider.Y = TabHeaderDividerYFirstValue * (1 - interpolationValue) + TabHeaderDividerYSecondValue * interpolationValue;
                }
                if (setTabMarginContainerHeightFirstValue && setTabMarginContainerHeightSecondValue)
                {
                    TabMarginContainer.Height = TabMarginContainerHeightFirstValue * (1 - interpolationValue) + TabMarginContainerHeightSecondValue * interpolationValue;
                }
                if (setTabMarginContainerWidthFirstValue && setTabMarginContainerWidthSecondValue)
                {
                    TabMarginContainer.Width = TabMarginContainerWidthFirstValue * (1 - interpolationValue) + TabMarginContainerWidthSecondValue * interpolationValue;
                }
                if (setTabMarginContainerXFirstValue && setTabMarginContainerXSecondValue)
                {
                    TabMarginContainer.X = TabMarginContainerXFirstValue * (1 - interpolationValue) + TabMarginContainerXSecondValue * interpolationValue;
                }
                if (setTabMarginContainerYFirstValue && setTabMarginContainerYSecondValue)
                {
                    TabMarginContainer.Y = TabMarginContainerYFirstValue * (1 - interpolationValue) + TabMarginContainerYSecondValue * interpolationValue;
                }
                if (setTabMenuBackgroundCurrentColorCategoryStateFirstValue && setTabMenuBackgroundCurrentColorCategoryStateSecondValue)
                {
                    TabMenuBackground.InterpolateBetween(TabMenuBackgroundCurrentColorCategoryStateFirstValue, TabMenuBackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTabMenuBackgroundCurrentStyleCategoryStateFirstValue && setTabMenuBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    TabMenuBackground.InterpolateBetween(TabMenuBackgroundCurrentStyleCategoryStateFirstValue, TabMenuBackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextBoxInstanceWidthFirstValue && setTextBoxInstanceWidthSecondValue)
                {
                    TextBoxInstance.Width = TextBoxInstanceWidthFirstValue * (1 - interpolationValue) + TextBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setTitleTextCurrentColorCategoryStateFirstValue && setTitleTextCurrentColorCategoryStateSecondValue)
                {
                    TitleText.InterpolateBetween(TitleTextCurrentColorCategoryStateFirstValue, TitleTextCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleTextCurrentStyleCategoryStateFirstValue && setTitleTextCurrentStyleCategoryStateSecondValue)
                {
                    TitleText.InterpolateBetween(TitleTextCurrentStyleCategoryStateFirstValue, TitleTextCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText1CurrentColorCategoryStateFirstValue && setTitleText1CurrentColorCategoryStateSecondValue)
                {
                    TitleText1.InterpolateBetween(TitleText1CurrentColorCategoryStateFirstValue, TitleText1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText1CurrentStyleCategoryStateFirstValue && setTitleText1CurrentStyleCategoryStateSecondValue)
                {
                    TitleText1.InterpolateBetween(TitleText1CurrentStyleCategoryStateFirstValue, TitleText1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText2CurrentColorCategoryStateFirstValue && setTitleText2CurrentColorCategoryStateSecondValue)
                {
                    TitleText2.InterpolateBetween(TitleText2CurrentColorCategoryStateFirstValue, TitleText2CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText2CurrentStyleCategoryStateFirstValue && setTitleText2CurrentStyleCategoryStateSecondValue)
                {
                    TitleText2.InterpolateBetween(TitleText2CurrentStyleCategoryStateFirstValue, TitleText2CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setVideoSettingsButtonWidthFirstValue && setVideoSettingsButtonWidthSecondValue)
                {
                    VideoSettingsButton.Width = VideoSettingsButtonWidthFirstValue * (1 - interpolationValue) + VideoSettingsButtonWidthSecondValue * interpolationValue;
                }
                if (setVideoSettingsButtonYFirstValue && setVideoSettingsButtonYSecondValue)
                {
                    VideoSettingsButton.Y = VideoSettingsButtonYFirstValue * (1 - interpolationValue) + VideoSettingsButtonYSecondValue * interpolationValue;
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.DemoScreenGumRuntime.VariableState fromState,NewGum.GumRuntimes.DemoScreenGumRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
                ButtonCloseInstance.StopAnimations();
                ButtonCloseInstance1.StopAnimations();
                DividerInstance.StopAnimations();
                DividerInstance4.StopAnimations();
                ResolutionLabel.StopAnimations();
                ResolutionBox.StopAnimations();
                DetectResolutionsButton.StopAnimations();
                FullScreenCheckbox.StopAnimations();
                DividerInstance1.StopAnimations();
                MusicLabel.StopAnimations();
                MusicSlider.StopAnimations();
                SoundLabel.StopAnimations();
                SoundSlider.StopAnimations();
                DividerInstance2.StopAnimations();
                ControlLabel.StopAnimations();
                RadioButtonInstance.StopAnimations();
                RadioButtonInstance1.StopAnimations();
                RadioButtonInstance2.StopAnimations();
                DividerInstance3.StopAnimations();
                DifficultyLabel.StopAnimations();
                ComboBoxInstance.StopAnimations();
                ButtonConfirmInstance.StopAnimations();
                ButtonDenyInstance.StopAnimations();
                LabelInstance.StopAnimations();
                TextBoxInstance.StopAnimations();
                ButtonConfirmInstance1.StopAnimations();
                PercentBarInstance.StopAnimations();
                HitpointsBar1.StopAnimations();
                HitpointsBar2.StopAnimations();
                HitpointsBar3.StopAnimations();
                PercentBarInstance1.StopAnimations();
                PercentBarInstance2.StopAnimations();
                DividerInstance5.StopAnimations();
                ButtonCloseInstance2.StopAnimations();
                PercentBarInstance3.StopAnimations();
                PercentBarInstance4.StopAnimations();
                PercentBarInstance5.StopAnimations();
                TabMenuClose.StopAnimations();
                TabHeaderDivider.StopAnimations();
                PlayButton.StopAnimations();
                VideoSettingsButton.StopAnimations();
                AudioSettingsButton.StopAnimations();
                CreditsButton.StopAnimations();
                ExitButton.StopAnimations();
                Tab3.StopAnimations();
                Tab2.StopAnimations();
                Tab1.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height",
                            Type = "float",
                            Value = DemoSettingsMenu.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoSettingsMenu.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Width",
                            Type = "float",
                            Value = DemoSettingsMenu.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.X",
                            Type = "float",
                            Value = DemoSettingsMenu.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Y",
                            Type = "float",
                            Value = DemoSettingsMenu.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Parent",
                            Type = "string",
                            Value = Background.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height",
                            Type = "float",
                            Value = MenuTitle.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Parent",
                            Type = "string",
                            Value = MenuTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width",
                            Type = "float",
                            Value = MenuTitle.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height",
                            Type = "float",
                            Value = MenuTitle1.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Parent",
                            Type = "string",
                            Value = MenuTitle1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width",
                            Type = "float",
                            Value = MenuTitle1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MenuItems.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height",
                            Type = "float",
                            Value = MenuItems.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Parent",
                            Type = "string",
                            Value = MenuItems.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width",
                            Type = "float",
                            Value = MenuItems.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X",
                            Type = "float",
                            Value = MenuItems.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MenuItems.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y",
                            Type = "float",
                            Value = MenuItems.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MenuItems.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Parent",
                            Type = "string",
                            Value = TitleText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Text",
                            Type = "string",
                            Value = TitleText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Parent",
                            Type = "string",
                            Value = TitleText1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Text",
                            Type = "string",
                            Value = TitleText1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Parent",
                            Type = "string",
                            Value = DividerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width",
                            Type = "float",
                            Value = DividerInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Parent",
                            Type = "string",
                            Value = DividerInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width",
                            Type = "float",
                            Value = DividerInstance4.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance4.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance4.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.LabelText",
                            Type = "string",
                            Value = ResolutionLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.Parent",
                            Type = "string",
                            Value = ResolutionLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Height",
                            Type = "float",
                            Value = ResolutionBox.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Parent",
                            Type = "string",
                            Value = ResolutionBox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width",
                            Type = "float",
                            Value = ResolutionBox.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width Units",
                            Type = "DimensionUnitType",
                            Value = ResolutionBox.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.ButtonDisplayText",
                            Type = "string",
                            Value = DetectResolutionsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Height",
                            Type = "float",
                            Value = DetectResolutionsButton.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Parent",
                            Type = "string",
                            Value = DetectResolutionsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X",
                            Type = "float",
                            Value = DetectResolutionsButton.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DetectResolutionsButton.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X Units",
                            Type = "PositionUnitType",
                            Value = DetectResolutionsButton.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Y",
                            Type = "float",
                            Value = DetectResolutionsButton.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.CheckboxDisplayText",
                            Type = "string",
                            Value = FullScreenCheckbox.CheckboxDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Parent",
                            Type = "string",
                            Value = FullScreenCheckbox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.X",
                            Type = "float",
                            Value = FullScreenCheckbox.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Y",
                            Type = "float",
                            Value = FullScreenCheckbox.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Parent",
                            Type = "string",
                            Value = DividerInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width",
                            Type = "float",
                            Value = DividerInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Y",
                            Type = "float",
                            Value = DividerInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.LabelText",
                            Type = "string",
                            Value = MusicLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Parent",
                            Type = "string",
                            Value = MusicLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Y",
                            Type = "float",
                            Value = MusicLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Parent",
                            Type = "string",
                            Value = MusicSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width",
                            Type = "float",
                            Value = MusicSlider.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = MusicSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.LabelText",
                            Type = "string",
                            Value = SoundLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.Parent",
                            Type = "string",
                            Value = SoundLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Parent",
                            Type = "string",
                            Value = SoundSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width",
                            Type = "float",
                            Value = SoundSlider.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = SoundSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Parent",
                            Type = "string",
                            Value = DividerInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width",
                            Type = "float",
                            Value = DividerInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Y",
                            Type = "float",
                            Value = DividerInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.LabelText",
                            Type = "string",
                            Value = ControlLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Parent",
                            Type = "string",
                            Value = ControlLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Y",
                            Type = "float",
                            Value = ControlLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Parent",
                            Type = "string",
                            Value = RadioButtonInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance1.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance1.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width",
                            Type = "float",
                            Value = RadioButtonInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Y",
                            Type = "float",
                            Value = RadioButtonInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Parent",
                            Type = "string",
                            Value = RadioButtonInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance2.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance2.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width",
                            Type = "float",
                            Value = RadioButtonInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Y",
                            Type = "float",
                            Value = RadioButtonInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Parent",
                            Type = "string",
                            Value = DividerInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width",
                            Type = "float",
                            Value = DividerInstance3.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Y",
                            Type = "float",
                            Value = DividerInstance3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.LabelText",
                            Type = "string",
                            Value = DifficultyLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Parent",
                            Type = "string",
                            Value = DifficultyLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Y",
                            Type = "float",
                            Value = DifficultyLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height",
                            Type = "float",
                            Value = Background1.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Parent",
                            Type = "string",
                            Value = Background1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width",
                            Type = "float",
                            Value = Background1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X",
                            Type = "float",
                            Value = Background1.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Units",
                            Type = "PositionUnitType",
                            Value = Background1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y",
                            Type = "float",
                            Value = Background1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background1.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Units",
                            Type = "PositionUnitType",
                            Value = Background1.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Height",
                            Type = "float",
                            Value = ButtonContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Parent",
                            Type = "string",
                            Value = ButtonContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width",
                            Type = "float",
                            Value = ButtonContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Y",
                            Type = "float",
                            Value = ButtonContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Height",
                            Type = "float",
                            Value = DemoDialog.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Width",
                            Type = "float",
                            Value = DemoDialog.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.X",
                            Type = "float",
                            Value = DemoDialog.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Y",
                            Type = "float",
                            Value = DemoDialog.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MarginContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height",
                            Type = "float",
                            Value = MarginContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Parent",
                            Type = "string",
                            Value = MarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width",
                            Type = "float",
                            Value = MarginContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X",
                            Type = "float",
                            Value = MarginContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y",
                            Type = "float",
                            Value = MarginContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.LabelText",
                            Type = "string",
                            Value = LabelInstance.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Y",
                            Type = "float",
                            Value = LabelInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width",
                            Type = "float",
                            Value = TextBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = DemoHud.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Height",
                            Type = "float",
                            Value = DemoHud.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoHud.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = DemoHud.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Width",
                            Type = "float",
                            Value = DemoHud.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Width Units",
                            Type = "DimensionUnitType",
                            Value = DemoHud.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X",
                            Type = "float",
                            Value = DemoHud.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DemoHud.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X Units",
                            Type = "PositionUnitType",
                            Value = DemoHud.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y",
                            Type = "float",
                            Value = DemoHud.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DemoHud.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y Units",
                            Type = "PositionUnitType",
                            Value = DemoHud.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Parent",
                            Type = "string",
                            Value = TitleText2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Text",
                            Type = "string",
                            Value = TitleText2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height",
                            Type = "float",
                            Value = MenuTitle2.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Parent",
                            Type = "string",
                            Value = MenuTitle2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width",
                            Type = "float",
                            Value = MenuTitle2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Parent",
                            Type = "string",
                            Value = PercentBarInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width",
                            Type = "float",
                            Value = PercentBarInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Y",
                            Type = "float",
                            Value = PercentBarInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar1.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarPercent",
                            Type = "float",
                            Value = HitpointsBar1.BarPercent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Height",
                            Type = "float",
                            Value = HitpointsBar1.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Parent",
                            Type = "string",
                            Value = HitpointsBar1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Width",
                            Type = "float",
                            Value = HitpointsBar1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.X",
                            Type = "float",
                            Value = HitpointsBar1.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Y",
                            Type = "float",
                            Value = HitpointsBar1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar2.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarPercent",
                            Type = "float",
                            Value = HitpointsBar2.BarPercent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Height",
                            Type = "float",
                            Value = HitpointsBar2.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Parent",
                            Type = "string",
                            Value = HitpointsBar2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Width",
                            Type = "float",
                            Value = HitpointsBar2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.X",
                            Type = "float",
                            Value = HitpointsBar2.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Y",
                            Type = "float",
                            Value = HitpointsBar2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar3.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarPercent",
                            Type = "float",
                            Value = HitpointsBar3.BarPercent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Height",
                            Type = "float",
                            Value = HitpointsBar3.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Parent",
                            Type = "string",
                            Value = HitpointsBar3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Width",
                            Type = "float",
                            Value = HitpointsBar3.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.X",
                            Type = "float",
                            Value = HitpointsBar3.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Y",
                            Type = "float",
                            Value = HitpointsBar3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance1.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Parent",
                            Type = "string",
                            Value = PercentBarInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width",
                            Type = "float",
                            Value = PercentBarInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Y",
                            Type = "float",
                            Value = PercentBarInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance2.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Parent",
                            Type = "string",
                            Value = PercentBarInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width",
                            Type = "float",
                            Value = PercentBarInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Y",
                            Type = "float",
                            Value = PercentBarInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Parent",
                            Type = "string",
                            Value = DividerInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width",
                            Type = "float",
                            Value = DividerInstance5.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance5.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance5.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance2.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance2.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Parent",
                            Type = "string",
                            Value = PercentBarInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width",
                            Type = "float",
                            Value = PercentBarInstance3.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Y",
                            Type = "float",
                            Value = PercentBarInstance3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance4.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance4.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Parent",
                            Type = "string",
                            Value = PercentBarInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width",
                            Type = "float",
                            Value = PercentBarInstance4.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Y",
                            Type = "float",
                            Value = PercentBarInstance4.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance5.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Parent",
                            Type = "string",
                            Value = PercentBarInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width",
                            Type = "float",
                            Value = PercentBarInstance5.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Y",
                            Type = "float",
                            Value = PercentBarInstance5.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ContainerInstance.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height",
                            Type = "float",
                            Value = ContainerInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Parent",
                            Type = "string",
                            Value = ContainerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width",
                            Type = "float",
                            Value = ContainerInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X",
                            Type = "float",
                            Value = ContainerInstance.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ContainerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y",
                            Type = "float",
                            Value = ContainerInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ContainerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Height",
                            Type = "float",
                            Value = DemoTabbedMenu.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Width",
                            Type = "float",
                            Value = DemoTabbedMenu.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.X",
                            Type = "float",
                            Value = DemoTabbedMenu.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Y",
                            Type = "float",
                            Value = DemoTabbedMenu.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabMenuBackground.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.Parent",
                            Type = "string",
                            Value = TabMenuBackground.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TabMenuBackground.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Height",
                            Type = "float",
                            Value = TabMarginContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabMarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Parent",
                            Type = "string",
                            Value = TabMarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Width",
                            Type = "float",
                            Value = TabMarginContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabMarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X",
                            Type = "float",
                            Value = TabMarginContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabMarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = TabMarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y",
                            Type = "float",
                            Value = TabMarginContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabMarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = TabMarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.Parent",
                            Type = "string",
                            Value = TabMenuClose.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabMenuClose.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.X Units",
                            Type = "PositionUnitType",
                            Value = TabMenuClose.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Parent",
                            Type = "string",
                            Value = TabHeaderDivider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Width",
                            Type = "float",
                            Value = TabHeaderDivider.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabHeaderDivider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.X",
                            Type = "float",
                            Value = TabHeaderDivider.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Y",
                            Type = "float",
                            Value = TabHeaderDivider.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ListContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Height",
                            Type = "float",
                            Value = ListContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ListContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Parent",
                            Type = "string",
                            Value = ListContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Width",
                            Type = "float",
                            Value = ListContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ListContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X",
                            Type = "float",
                            Value = ListContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ListContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X Units",
                            Type = "PositionUnitType",
                            Value = ListContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y",
                            Type = "float",
                            Value = ListContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ListContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = ListContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.ButtonDisplayText",
                            Type = "string",
                            Value = PlayButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = PlayButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Parent",
                            Type = "string",
                            Value = PlayButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Width",
                            Type = "float",
                            Value = PlayButton.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = PlayButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.ButtonDisplayText",
                            Type = "string",
                            Value = VideoSettingsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = VideoSettingsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Parent",
                            Type = "string",
                            Value = VideoSettingsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Width",
                            Type = "float",
                            Value = VideoSettingsButton.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = VideoSettingsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Y",
                            Type = "float",
                            Value = VideoSettingsButton.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.ButtonDisplayText",
                            Type = "string",
                            Value = AudioSettingsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = AudioSettingsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Parent",
                            Type = "string",
                            Value = AudioSettingsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Width",
                            Type = "float",
                            Value = AudioSettingsButton.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = AudioSettingsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Y",
                            Type = "float",
                            Value = AudioSettingsButton.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.ButtonDisplayText",
                            Type = "string",
                            Value = CreditsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = CreditsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Parent",
                            Type = "string",
                            Value = CreditsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Width",
                            Type = "float",
                            Value = CreditsButton.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = CreditsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Y",
                            Type = "float",
                            Value = CreditsButton.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.ButtonDisplayText",
                            Type = "string",
                            Value = ExitButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = ExitButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Parent",
                            Type = "string",
                            Value = ExitButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Width",
                            Type = "float",
                            Value = ExitButton.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = ExitButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Y",
                            Type = "float",
                            Value = ExitButton.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.Parent",
                            Type = "string",
                            Value = Tab3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.TabDisplayText",
                            Type = "string",
                            Value = Tab3.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.X",
                            Type = "float",
                            Value = Tab3.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.Y",
                            Type = "float",
                            Value = Tab3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.Parent",
                            Type = "string",
                            Value = Tab2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.TabDisplayText",
                            Type = "string",
                            Value = Tab2.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.X",
                            Type = "float",
                            Value = Tab2.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.Y",
                            Type = "float",
                            Value = Tab2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.Parent",
                            Type = "string",
                            Value = Tab1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.TabDisplayText",
                            Type = "string",
                            Value = Tab1.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.X",
                            Type = "float",
                            Value = Tab1.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.Y",
                            Type = "float",
                            Value = Tab1.Y
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height",
                            Type = "float",
                            Value = DemoSettingsMenu.Height + 16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoSettingsMenu.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Width",
                            Type = "float",
                            Value = DemoSettingsMenu.Width + 400f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.X",
                            Type = "float",
                            Value = DemoSettingsMenu.X + 40f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Y",
                            Type = "float",
                            Value = DemoSettingsMenu.Y + 35f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Parent",
                            Type = "string",
                            Value = Background.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height",
                            Type = "float",
                            Value = MenuTitle.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Parent",
                            Type = "string",
                            Value = MenuTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width",
                            Type = "float",
                            Value = MenuTitle.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height",
                            Type = "float",
                            Value = MenuTitle1.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Parent",
                            Type = "string",
                            Value = MenuTitle1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width",
                            Type = "float",
                            Value = MenuTitle1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MenuItems.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height",
                            Type = "float",
                            Value = MenuItems.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Parent",
                            Type = "string",
                            Value = MenuItems.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width",
                            Type = "float",
                            Value = MenuItems.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X",
                            Type = "float",
                            Value = MenuItems.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MenuItems.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y",
                            Type = "float",
                            Value = MenuItems.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MenuItems.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Parent",
                            Type = "string",
                            Value = TitleText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Text",
                            Type = "string",
                            Value = TitleText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Parent",
                            Type = "string",
                            Value = TitleText1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Text",
                            Type = "string",
                            Value = TitleText1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Parent",
                            Type = "string",
                            Value = DividerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width",
                            Type = "float",
                            Value = DividerInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Parent",
                            Type = "string",
                            Value = DividerInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width",
                            Type = "float",
                            Value = DividerInstance4.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance4.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance4.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.LabelText",
                            Type = "string",
                            Value = ResolutionLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.Parent",
                            Type = "string",
                            Value = ResolutionLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Height",
                            Type = "float",
                            Value = ResolutionBox.Height + 128f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Parent",
                            Type = "string",
                            Value = ResolutionBox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width",
                            Type = "float",
                            Value = ResolutionBox.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width Units",
                            Type = "DimensionUnitType",
                            Value = ResolutionBox.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.ButtonDisplayText",
                            Type = "string",
                            Value = DetectResolutionsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Height",
                            Type = "float",
                            Value = DetectResolutionsButton.Height + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Parent",
                            Type = "string",
                            Value = DetectResolutionsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X",
                            Type = "float",
                            Value = DetectResolutionsButton.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DetectResolutionsButton.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.X Units",
                            Type = "PositionUnitType",
                            Value = DetectResolutionsButton.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DetectResolutionsButton.Y",
                            Type = "float",
                            Value = DetectResolutionsButton.Y + 9f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.CheckboxDisplayText",
                            Type = "string",
                            Value = FullScreenCheckbox.CheckboxDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Parent",
                            Type = "string",
                            Value = FullScreenCheckbox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.X",
                            Type = "float",
                            Value = FullScreenCheckbox.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Y",
                            Type = "float",
                            Value = FullScreenCheckbox.Y + -26f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Parent",
                            Type = "string",
                            Value = DividerInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width",
                            Type = "float",
                            Value = DividerInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Y",
                            Type = "float",
                            Value = DividerInstance1.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.LabelText",
                            Type = "string",
                            Value = MusicLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Parent",
                            Type = "string",
                            Value = MusicLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Y",
                            Type = "float",
                            Value = MusicLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Parent",
                            Type = "string",
                            Value = MusicSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width",
                            Type = "float",
                            Value = MusicSlider.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = MusicSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.LabelText",
                            Type = "string",
                            Value = SoundLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.Parent",
                            Type = "string",
                            Value = SoundLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Parent",
                            Type = "string",
                            Value = SoundSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width",
                            Type = "float",
                            Value = SoundSlider.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = SoundSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Parent",
                            Type = "string",
                            Value = DividerInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width",
                            Type = "float",
                            Value = DividerInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Y",
                            Type = "float",
                            Value = DividerInstance2.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.LabelText",
                            Type = "string",
                            Value = ControlLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Parent",
                            Type = "string",
                            Value = ControlLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Y",
                            Type = "float",
                            Value = ControlLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Parent",
                            Type = "string",
                            Value = RadioButtonInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance1.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance1.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width",
                            Type = "float",
                            Value = RadioButtonInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Y",
                            Type = "float",
                            Value = RadioButtonInstance1.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Parent",
                            Type = "string",
                            Value = RadioButtonInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance2.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance2.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width",
                            Type = "float",
                            Value = RadioButtonInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Y",
                            Type = "float",
                            Value = RadioButtonInstance2.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Parent",
                            Type = "string",
                            Value = DividerInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width",
                            Type = "float",
                            Value = DividerInstance3.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Y",
                            Type = "float",
                            Value = DividerInstance3.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.LabelText",
                            Type = "string",
                            Value = DifficultyLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Parent",
                            Type = "string",
                            Value = DifficultyLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Y",
                            Type = "float",
                            Value = DifficultyLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height",
                            Type = "float",
                            Value = Background1.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Parent",
                            Type = "string",
                            Value = Background1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width",
                            Type = "float",
                            Value = Background1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X",
                            Type = "float",
                            Value = Background1.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Units",
                            Type = "PositionUnitType",
                            Value = Background1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y",
                            Type = "float",
                            Value = Background1.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background1.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Units",
                            Type = "PositionUnitType",
                            Value = Background1.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Height",
                            Type = "float",
                            Value = ButtonContainer.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Parent",
                            Type = "string",
                            Value = ButtonContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width",
                            Type = "float",
                            Value = ButtonContainer.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Y",
                            Type = "float",
                            Value = ButtonContainer.Y + 16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Height",
                            Type = "float",
                            Value = DemoDialog.Height + 163f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Width",
                            Type = "float",
                            Value = DemoDialog.Width + 349f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.X",
                            Type = "float",
                            Value = DemoDialog.X + 488f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Y",
                            Type = "float",
                            Value = DemoDialog.Y + 42f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MarginContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height",
                            Type = "float",
                            Value = MarginContainer.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Parent",
                            Type = "string",
                            Value = MarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width",
                            Type = "float",
                            Value = MarginContainer.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X",
                            Type = "float",
                            Value = MarginContainer.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y",
                            Type = "float",
                            Value = MarginContainer.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.LabelText",
                            Type = "string",
                            Value = LabelInstance.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Y",
                            Type = "float",
                            Value = LabelInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width",
                            Type = "float",
                            Value = TextBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance1.Y + 16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = DemoHud.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Height",
                            Type = "float",
                            Value = DemoHud.Height + 207f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoHud.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = DemoHud.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Width",
                            Type = "float",
                            Value = DemoHud.Width + 279f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Width Units",
                            Type = "DimensionUnitType",
                            Value = DemoHud.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X",
                            Type = "float",
                            Value = DemoHud.X + 486f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DemoHud.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.X Units",
                            Type = "PositionUnitType",
                            Value = DemoHud.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y",
                            Type = "float",
                            Value = DemoHud.Y + 218f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DemoHud.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoHud.Y Units",
                            Type = "PositionUnitType",
                            Value = DemoHud.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Parent",
                            Type = "string",
                            Value = TitleText2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Text",
                            Type = "string",
                            Value = TitleText2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height",
                            Type = "float",
                            Value = MenuTitle2.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Parent",
                            Type = "string",
                            Value = MenuTitle2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width",
                            Type = "float",
                            Value = MenuTitle2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Parent",
                            Type = "string",
                            Value = PercentBarInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width",
                            Type = "float",
                            Value = PercentBarInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Y",
                            Type = "float",
                            Value = PercentBarInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar1.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.BarPercent",
                            Type = "float",
                            Value = HitpointsBar1.BarPercent + 75f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Height",
                            Type = "float",
                            Value = HitpointsBar1.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Parent",
                            Type = "string",
                            Value = HitpointsBar1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Width",
                            Type = "float",
                            Value = HitpointsBar1.Width + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.X",
                            Type = "float",
                            Value = HitpointsBar1.X + 184f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar1.Y",
                            Type = "float",
                            Value = HitpointsBar1.Y + 10f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar2.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.BarPercent",
                            Type = "float",
                            Value = HitpointsBar2.BarPercent + 50f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Height",
                            Type = "float",
                            Value = HitpointsBar2.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Parent",
                            Type = "string",
                            Value = HitpointsBar2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Width",
                            Type = "float",
                            Value = HitpointsBar2.Width + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.X",
                            Type = "float",
                            Value = HitpointsBar2.X + 184f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar2.Y",
                            Type = "float",
                            Value = HitpointsBar2.Y + 20f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarColor",
                            Type = "ColorCategory",
                            Value = HitpointsBar3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = HitpointsBar3.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.BarPercent",
                            Type = "float",
                            Value = HitpointsBar3.BarPercent + 25f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Height",
                            Type = "float",
                            Value = HitpointsBar3.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Parent",
                            Type = "string",
                            Value = HitpointsBar3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Width",
                            Type = "float",
                            Value = HitpointsBar3.Width + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Width Units",
                            Type = "DimensionUnitType",
                            Value = HitpointsBar3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.X",
                            Type = "float",
                            Value = HitpointsBar3.X + 184f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "HitpointsBar3.Y",
                            Type = "float",
                            Value = HitpointsBar3.Y + 31f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance1.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Parent",
                            Type = "string",
                            Value = PercentBarInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width",
                            Type = "float",
                            Value = PercentBarInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Y",
                            Type = "float",
                            Value = PercentBarInstance1.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance2.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Parent",
                            Type = "string",
                            Value = PercentBarInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width",
                            Type = "float",
                            Value = PercentBarInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Y",
                            Type = "float",
                            Value = PercentBarInstance2.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Parent",
                            Type = "string",
                            Value = DividerInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width",
                            Type = "float",
                            Value = DividerInstance5.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance5.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance5.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance2.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance2.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Parent",
                            Type = "string",
                            Value = PercentBarInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width",
                            Type = "float",
                            Value = PercentBarInstance3.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Y",
                            Type = "float",
                            Value = PercentBarInstance3.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance4.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarInstance4.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Parent",
                            Type = "string",
                            Value = PercentBarInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width",
                            Type = "float",
                            Value = PercentBarInstance4.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Y",
                            Type = "float",
                            Value = PercentBarInstance4.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance5.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Parent",
                            Type = "string",
                            Value = PercentBarInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width",
                            Type = "float",
                            Value = PercentBarInstance5.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Y",
                            Type = "float",
                            Value = PercentBarInstance5.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ContainerInstance.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height",
                            Type = "float",
                            Value = ContainerInstance.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Parent",
                            Type = "string",
                            Value = ContainerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width",
                            Type = "float",
                            Value = ContainerInstance.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X",
                            Type = "float",
                            Value = ContainerInstance.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ContainerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y",
                            Type = "float",
                            Value = ContainerInstance.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ContainerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Height",
                            Type = "float",
                            Value = DemoTabbedMenu.Height + 256f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Width",
                            Type = "float",
                            Value = DemoTabbedMenu.Width + 458f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.X",
                            Type = "float",
                            Value = DemoTabbedMenu.X + 498f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoTabbedMenu.Y",
                            Type = "float",
                            Value = DemoTabbedMenu.Y + 456f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabMenuBackground.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.Parent",
                            Type = "string",
                            Value = TabMenuBackground.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuBackground.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TabMenuBackground.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Height",
                            Type = "float",
                            Value = TabMarginContainer.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabMarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Parent",
                            Type = "string",
                            Value = TabMarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Width",
                            Type = "float",
                            Value = TabMarginContainer.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabMarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X",
                            Type = "float",
                            Value = TabMarginContainer.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabMarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = TabMarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y",
                            Type = "float",
                            Value = TabMarginContainer.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabMarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = TabMarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.Parent",
                            Type = "string",
                            Value = TabMenuClose.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabMenuClose.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabMenuClose.X Units",
                            Type = "PositionUnitType",
                            Value = TabMenuClose.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Parent",
                            Type = "string",
                            Value = TabHeaderDivider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Width",
                            Type = "float",
                            Value = TabHeaderDivider.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabHeaderDivider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.X",
                            Type = "float",
                            Value = TabHeaderDivider.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabHeaderDivider.Y",
                            Type = "float",
                            Value = TabHeaderDivider.Y + 35f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ListContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Height",
                            Type = "float",
                            Value = ListContainer.Height + -45f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ListContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Parent",
                            Type = "string",
                            Value = ListContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Width",
                            Type = "float",
                            Value = ListContainer.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ListContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X",
                            Type = "float",
                            Value = ListContainer.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ListContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.X Units",
                            Type = "PositionUnitType",
                            Value = ListContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y",
                            Type = "float",
                            Value = ListContainer.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ListContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = ListContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.ButtonDisplayText",
                            Type = "string",
                            Value = PlayButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = PlayButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Parent",
                            Type = "string",
                            Value = PlayButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Width",
                            Type = "float",
                            Value = PlayButton.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlayButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = PlayButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.ButtonDisplayText",
                            Type = "string",
                            Value = VideoSettingsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = VideoSettingsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Parent",
                            Type = "string",
                            Value = VideoSettingsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Width",
                            Type = "float",
                            Value = VideoSettingsButton.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = VideoSettingsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VideoSettingsButton.Y",
                            Type = "float",
                            Value = VideoSettingsButton.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.ButtonDisplayText",
                            Type = "string",
                            Value = AudioSettingsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = AudioSettingsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Parent",
                            Type = "string",
                            Value = AudioSettingsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Width",
                            Type = "float",
                            Value = AudioSettingsButton.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = AudioSettingsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "AudioSettingsButton.Y",
                            Type = "float",
                            Value = AudioSettingsButton.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.ButtonDisplayText",
                            Type = "string",
                            Value = CreditsButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = CreditsButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Parent",
                            Type = "string",
                            Value = CreditsButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Width",
                            Type = "float",
                            Value = CreditsButton.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = CreditsButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CreditsButton.Y",
                            Type = "float",
                            Value = CreditsButton.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.ButtonDisplayText",
                            Type = "string",
                            Value = ExitButton.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.ButtonIcon",
                            Type = "IconCategory",
                            Value = ExitButton.ButtonIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Parent",
                            Type = "string",
                            Value = ExitButton.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Width",
                            Type = "float",
                            Value = ExitButton.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Width Units",
                            Type = "DimensionUnitType",
                            Value = ExitButton.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ExitButton.Y",
                            Type = "float",
                            Value = ExitButton.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.Parent",
                            Type = "string",
                            Value = Tab3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.TabDisplayText",
                            Type = "string",
                            Value = Tab3.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.X",
                            Type = "float",
                            Value = Tab3.X + -72f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab3.Y",
                            Type = "float",
                            Value = Tab3.Y + 36f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.Parent",
                            Type = "string",
                            Value = Tab2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.TabDisplayText",
                            Type = "string",
                            Value = Tab2.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.X",
                            Type = "float",
                            Value = Tab2.X + -124f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab2.Y",
                            Type = "float",
                            Value = Tab2.Y + 36f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.Parent",
                            Type = "string",
                            Value = Tab1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.TabDisplayText",
                            Type = "string",
                            Value = Tab1.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.X",
                            Type = "float",
                            Value = Tab1.X + -184f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab1.Y",
                            Type = "float",
                            Value = Tab1.Y + 36f
                        }
                        );
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.ContainerRuntime DemoSettingsMenu { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Background { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle1 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuItems { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText1 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance4 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime ResolutionLabel { get; set; }
            public NewGum.GumRuntimes.Controls.ListBoxRuntime ResolutionBox { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardRuntime DetectResolutionsButton { get; set; }
            public NewGum.GumRuntimes.Controls.CheckBoxRuntime FullScreenCheckbox { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime MusicLabel { get; set; }
            public NewGum.GumRuntimes.Controls.SliderRuntime MusicSlider { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime SoundLabel { get; set; }
            public NewGum.GumRuntimes.Controls.SliderRuntime SoundSlider { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime ControlLabel { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance1 { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance3 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime DifficultyLabel { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Background1 { get; set; }
            public NewGum.GumRuntimes.Controls.ComboBoxRuntime ComboBoxInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ButtonContainer { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonConfirmRuntime ButtonConfirmInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonDenyRuntime ButtonDenyInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime DemoDialog { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MarginContainer { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime LabelInstance { get; set; }
            public NewGum.GumRuntimes.Controls.TextBoxRuntime TextBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonConfirmRuntime ButtonConfirmInstance1 { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime DemoHud { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText2 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle2 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime HitpointsBar1 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime HitpointsBar2 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime HitpointsBar3 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerInstance5 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance3 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance4 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarIconRuntime PercentBarInstance5 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ContainerInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime DemoTabbedMenu { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime TabMenuBackground { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime TabMarginContainer { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime TabMenuClose { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime TabHeaderDivider { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ListContainer { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime PlayButton { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime VideoSettingsButton { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime AudioSettingsButton { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime CreditsButton { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime ExitButton { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonTabRuntime Tab3 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonTabRuntime Tab2 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonTabRuntime Tab1 { get; set; }
            public DemoScreenGumRuntime () 
            	: this(true, true)
            {
            }
            public DemoScreenGumRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Screens.First(item => item.Name == "DemoScreenGum");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                var wasSuppressed = this.IsLayoutSuspended;
                if(!wasSuppressed) this.SuspendLayout();
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                if(!wasSuppressed) this.ResumeLayout();
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                DemoSettingsMenu = this.GetGraphicalUiElementByName("DemoSettingsMenu") as NewGum.GumRuntimes.ContainerRuntime;
                Background = this.GetGraphicalUiElementByName("Background") as NewGum.GumRuntimes.NineSliceRuntime;
                MenuTitle = this.GetGraphicalUiElementByName("MenuTitle") as NewGum.GumRuntimes.ContainerRuntime;
                MenuTitle1 = this.GetGraphicalUiElementByName("MenuTitle1") as NewGum.GumRuntimes.ContainerRuntime;
                MenuItems = this.GetGraphicalUiElementByName("MenuItems") as NewGum.GumRuntimes.ContainerRuntime;
                TitleText = this.GetGraphicalUiElementByName("TitleText") as NewGum.GumRuntimes.TextRuntime;
                TitleText1 = this.GetGraphicalUiElementByName("TitleText1") as NewGum.GumRuntimes.TextRuntime;
                ButtonCloseInstance = this.GetGraphicalUiElementByName("ButtonCloseInstance") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                ButtonCloseInstance1 = this.GetGraphicalUiElementByName("ButtonCloseInstance1") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                DividerInstance = this.GetGraphicalUiElementByName("DividerInstance") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                DividerInstance4 = this.GetGraphicalUiElementByName("DividerInstance4") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                ResolutionLabel = this.GetGraphicalUiElementByName("ResolutionLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                ResolutionBox = this.GetGraphicalUiElementByName("ResolutionBox") as NewGum.GumRuntimes.Controls.ListBoxRuntime;
                DetectResolutionsButton = this.GetGraphicalUiElementByName("DetectResolutionsButton") as NewGum.GumRuntimes.Controls.ButtonStandardRuntime;
                FullScreenCheckbox = this.GetGraphicalUiElementByName("FullScreenCheckbox") as NewGum.GumRuntimes.Controls.CheckBoxRuntime;
                DividerInstance1 = this.GetGraphicalUiElementByName("DividerInstance1") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                MusicLabel = this.GetGraphicalUiElementByName("MusicLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                MusicSlider = this.GetGraphicalUiElementByName("MusicSlider") as NewGum.GumRuntimes.Controls.SliderRuntime;
                SoundLabel = this.GetGraphicalUiElementByName("SoundLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                SoundSlider = this.GetGraphicalUiElementByName("SoundSlider") as NewGum.GumRuntimes.Controls.SliderRuntime;
                DividerInstance2 = this.GetGraphicalUiElementByName("DividerInstance2") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                ControlLabel = this.GetGraphicalUiElementByName("ControlLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                RadioButtonInstance = this.GetGraphicalUiElementByName("RadioButtonInstance") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                RadioButtonInstance1 = this.GetGraphicalUiElementByName("RadioButtonInstance1") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                RadioButtonInstance2 = this.GetGraphicalUiElementByName("RadioButtonInstance2") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                DividerInstance3 = this.GetGraphicalUiElementByName("DividerInstance3") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                DifficultyLabel = this.GetGraphicalUiElementByName("DifficultyLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                Background1 = this.GetGraphicalUiElementByName("Background1") as NewGum.GumRuntimes.NineSliceRuntime;
                ComboBoxInstance = this.GetGraphicalUiElementByName("ComboBoxInstance") as NewGum.GumRuntimes.Controls.ComboBoxRuntime;
                ButtonContainer = this.GetGraphicalUiElementByName("ButtonContainer") as NewGum.GumRuntimes.ContainerRuntime;
                ButtonConfirmInstance = this.GetGraphicalUiElementByName("ButtonConfirmInstance") as NewGum.GumRuntimes.Controls.ButtonConfirmRuntime;
                ButtonDenyInstance = this.GetGraphicalUiElementByName("ButtonDenyInstance") as NewGum.GumRuntimes.Controls.ButtonDenyRuntime;
                DemoDialog = this.GetGraphicalUiElementByName("DemoDialog") as NewGum.GumRuntimes.ContainerRuntime;
                MarginContainer = this.GetGraphicalUiElementByName("MarginContainer") as NewGum.GumRuntimes.ContainerRuntime;
                LabelInstance = this.GetGraphicalUiElementByName("LabelInstance") as NewGum.GumRuntimes.Elements.LabelRuntime;
                TextBoxInstance = this.GetGraphicalUiElementByName("TextBoxInstance") as NewGum.GumRuntimes.Controls.TextBoxRuntime;
                ButtonConfirmInstance1 = this.GetGraphicalUiElementByName("ButtonConfirmInstance1") as NewGum.GumRuntimes.Controls.ButtonConfirmRuntime;
                DemoHud = this.GetGraphicalUiElementByName("DemoHud") as NewGum.GumRuntimes.NineSliceRuntime;
                TitleText2 = this.GetGraphicalUiElementByName("TitleText2") as NewGum.GumRuntimes.TextRuntime;
                MenuTitle2 = this.GetGraphicalUiElementByName("MenuTitle2") as NewGum.GumRuntimes.ContainerRuntime;
                PercentBarInstance = this.GetGraphicalUiElementByName("PercentBarInstance") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                HitpointsBar1 = this.GetGraphicalUiElementByName("HitpointsBar1") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                HitpointsBar2 = this.GetGraphicalUiElementByName("HitpointsBar2") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                HitpointsBar3 = this.GetGraphicalUiElementByName("HitpointsBar3") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance1 = this.GetGraphicalUiElementByName("PercentBarInstance1") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance2 = this.GetGraphicalUiElementByName("PercentBarInstance2") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                DividerInstance5 = this.GetGraphicalUiElementByName("DividerInstance5") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                ButtonCloseInstance2 = this.GetGraphicalUiElementByName("ButtonCloseInstance2") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                PercentBarInstance3 = this.GetGraphicalUiElementByName("PercentBarInstance3") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance4 = this.GetGraphicalUiElementByName("PercentBarInstance4") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance5 = this.GetGraphicalUiElementByName("PercentBarInstance5") as NewGum.GumRuntimes.Elements.PercentBarIconRuntime;
                ContainerInstance = this.GetGraphicalUiElementByName("ContainerInstance") as NewGum.GumRuntimes.ContainerRuntime;
                DemoTabbedMenu = this.GetGraphicalUiElementByName("DemoTabbedMenu") as NewGum.GumRuntimes.ContainerRuntime;
                TabMenuBackground = this.GetGraphicalUiElementByName("TabMenuBackground") as NewGum.GumRuntimes.NineSliceRuntime;
                TabMarginContainer = this.GetGraphicalUiElementByName("TabMarginContainer") as NewGum.GumRuntimes.ContainerRuntime;
                TabMenuClose = this.GetGraphicalUiElementByName("TabMenuClose") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                TabHeaderDivider = this.GetGraphicalUiElementByName("TabHeaderDivider") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                ListContainer = this.GetGraphicalUiElementByName("ListContainer") as NewGum.GumRuntimes.ContainerRuntime;
                PlayButton = this.GetGraphicalUiElementByName("PlayButton") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                VideoSettingsButton = this.GetGraphicalUiElementByName("VideoSettingsButton") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                AudioSettingsButton = this.GetGraphicalUiElementByName("AudioSettingsButton") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                CreditsButton = this.GetGraphicalUiElementByName("CreditsButton") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                ExitButton = this.GetGraphicalUiElementByName("ExitButton") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                Tab3 = this.GetGraphicalUiElementByName("Tab3") as NewGum.GumRuntimes.Controls.ButtonTabRuntime;
                Tab2 = this.GetGraphicalUiElementByName("Tab2") as NewGum.GumRuntimes.Controls.ButtonTabRuntime;
                Tab1 = this.GetGraphicalUiElementByName("Tab1") as NewGum.GumRuntimes.Controls.ButtonTabRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new NewGum.FormsControls.Screens.DemoScreenGumForms(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public NewGum.FormsControls.Screens.DemoScreenGumForms FormsControl {get => (NewGum.FormsControls.Screens.DemoScreenGumForms) FormsControlAsObject;}
        }
    }
