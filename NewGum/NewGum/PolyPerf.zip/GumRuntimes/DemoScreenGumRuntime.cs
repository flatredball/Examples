using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes
{
    public partial class DemoScreenGumRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
