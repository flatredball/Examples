using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes
{
    public partial class PolygonScreenGumRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
