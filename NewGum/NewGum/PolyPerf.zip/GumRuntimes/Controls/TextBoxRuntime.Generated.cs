    using System.Linq;
    namespace NewGum.GumRuntimes.Controls
    {
        public partial class TextBoxRuntime : NewGum.GumRuntimes.ContainerRuntime
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            public enum TextBoxCategory
            {
                Enabled,
                Disabled,
                Highlighted,
                Selected
            }
            public enum LineModeCategory
            {
                Single,
                Multi
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            TextBoxCategory? mCurrentTextBoxCategoryState;
            LineModeCategory? mCurrentLineModeCategoryState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                            Background.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                            SelectionInstance.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                            TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextInstance.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            CaretInstance.CurrentColorCategoryState = NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory.Primary;
                            PlaceholderTextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            FocusedIndicator.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            FocusedIndicator.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                            Height = 24f;
                            Width = 256f;
                            SelectionInstance.Height = -4f;
                            SelectionInstance.Width = 7f;
                            SelectionInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            SelectionInstance.X = 15f;
                            SelectionInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            SelectionInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            SelectionInstance.Y = 0f;
                            TextInstance.Height = -4f;
                            TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            TextInstance.Text = "";
                            TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TextInstance.Width = 0f;
                            TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            TextInstance.X = 4f;
                            TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            TextInstance.Y = 0f;
                            TextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            CaretInstance.Height = 14f;
                            CaretInstance.Width = 1f;
                            CaretInstance.X = 9f;
                            CaretInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            CaretInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            CaretInstance.Y = 0f;
                            CaretInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            CaretInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            PlaceholderTextInstance.Height = -4f;
                            PlaceholderTextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PlaceholderTextInstance.Text = "Text Placeholder";
                            PlaceholderTextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            PlaceholderTextInstance.Width = -8f;
                            PlaceholderTextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PlaceholderTextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            PlaceholderTextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            PlaceholderTextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            PlaceholderTextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            FocusedIndicator.Height = 2f;
                            FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            FocusedIndicator.Visible = false;
                            FocusedIndicator.Y = 2f;
                            FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            break;
                    }
                }
            }
            public TextBoxCategory? CurrentTextBoxCategoryState
            {
                get
                {
                    return mCurrentTextBoxCategoryState;
                }
                set
                {
                    if (value != null)
                    {
                        mCurrentTextBoxCategoryState = value;
                        switch(mCurrentTextBoxCategoryState)
                        {
                            case  TextBoxCategory.Enabled:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                PlaceholderTextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = false;
                                break;
                            case  TextBoxCategory.Disabled:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                                PlaceholderTextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                                FocusedIndicator.Visible = false;
                                break;
                            case  TextBoxCategory.Highlighted:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Gray;
                                TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                PlaceholderTextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = false;
                                break;
                            case  TextBoxCategory.Selected:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                PlaceholderTextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = true;
                                break;
                        }
                    }
                }
            }
            public LineModeCategory? CurrentLineModeCategoryState
            {
                get
                {
                    return mCurrentLineModeCategoryState;
                }
                set
                {
                    if (value != null)
                    {
                        mCurrentLineModeCategoryState = value;
                        switch(mCurrentLineModeCategoryState)
                        {
                            case  LineModeCategory.Single:
                                break;
                            case  LineModeCategory.Multi:
                                break;
                        }
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setCaretInstanceCurrentColorCategoryStateFirstValue = false;
                bool setCaretInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory CaretInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory CaretInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory.Black;
                bool setCaretInstanceHeightFirstValue = false;
                bool setCaretInstanceHeightSecondValue = false;
                float CaretInstanceHeightFirstValue= 0;
                float CaretInstanceHeightSecondValue= 0;
                bool setCaretInstanceWidthFirstValue = false;
                bool setCaretInstanceWidthSecondValue = false;
                float CaretInstanceWidthFirstValue= 0;
                float CaretInstanceWidthSecondValue= 0;
                bool setCaretInstanceXFirstValue = false;
                bool setCaretInstanceXSecondValue = false;
                float CaretInstanceXFirstValue= 0;
                float CaretInstanceXSecondValue= 0;
                bool setCaretInstanceYFirstValue = false;
                bool setCaretInstanceYSecondValue = false;
                float CaretInstanceYFirstValue= 0;
                float CaretInstanceYSecondValue= 0;
                bool setFocusedIndicatorCurrentColorCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setFocusedIndicatorHeightFirstValue = false;
                bool setFocusedIndicatorHeightSecondValue = false;
                float FocusedIndicatorHeightFirstValue= 0;
                float FocusedIndicatorHeightSecondValue= 0;
                bool setFocusedIndicatorCurrentStyleCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setFocusedIndicatorYFirstValue = false;
                bool setFocusedIndicatorYSecondValue = false;
                float FocusedIndicatorYFirstValue= 0;
                float FocusedIndicatorYSecondValue= 0;
                bool setHeightFirstValue = false;
                bool setHeightSecondValue = false;
                float HeightFirstValue= 0;
                float HeightSecondValue= 0;
                bool setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = false;
                bool setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory PlaceholderTextInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory PlaceholderTextInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setPlaceholderTextInstanceHeightFirstValue = false;
                bool setPlaceholderTextInstanceHeightSecondValue = false;
                float PlaceholderTextInstanceHeightFirstValue= 0;
                float PlaceholderTextInstanceHeightSecondValue= 0;
                bool setPlaceholderTextInstanceWidthFirstValue = false;
                bool setPlaceholderTextInstanceWidthSecondValue = false;
                float PlaceholderTextInstanceWidthFirstValue= 0;
                float PlaceholderTextInstanceWidthSecondValue= 0;
                bool setSelectionInstanceCurrentColorCategoryStateFirstValue = false;
                bool setSelectionInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory SelectionInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory SelectionInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setSelectionInstanceHeightFirstValue = false;
                bool setSelectionInstanceHeightSecondValue = false;
                float SelectionInstanceHeightFirstValue= 0;
                float SelectionInstanceHeightSecondValue= 0;
                bool setSelectionInstanceWidthFirstValue = false;
                bool setSelectionInstanceWidthSecondValue = false;
                float SelectionInstanceWidthFirstValue= 0;
                float SelectionInstanceWidthSecondValue= 0;
                bool setSelectionInstanceXFirstValue = false;
                bool setSelectionInstanceXSecondValue = false;
                float SelectionInstanceXFirstValue= 0;
                float SelectionInstanceXSecondValue= 0;
                bool setSelectionInstanceYFirstValue = false;
                bool setSelectionInstanceYSecondValue = false;
                float SelectionInstanceYFirstValue= 0;
                float SelectionInstanceYSecondValue= 0;
                bool setTextInstanceCurrentColorCategoryStateFirstValue = false;
                bool setTextInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextInstanceHeightFirstValue = false;
                bool setTextInstanceHeightSecondValue = false;
                float TextInstanceHeightFirstValue= 0;
                float TextInstanceHeightSecondValue= 0;
                bool setTextInstanceCurrentStyleCategoryStateFirstValue = false;
                bool setTextInstanceCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextInstanceCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextInstanceCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextInstanceWidthFirstValue = false;
                bool setTextInstanceWidthSecondValue = false;
                float TextInstanceWidthFirstValue= 0;
                float TextInstanceWidthSecondValue= 0;
                bool setTextInstanceXFirstValue = false;
                bool setTextInstanceXSecondValue = false;
                float TextInstanceXFirstValue= 0;
                float TextInstanceXSecondValue= 0;
                bool setTextInstanceYFirstValue = false;
                bool setTextInstanceYSecondValue = false;
                float TextInstanceYFirstValue= 0;
                float TextInstanceYSecondValue= 0;
                bool setWidthFirstValue = false;
                bool setWidthSecondValue = false;
                float WidthFirstValue= 0;
                float WidthSecondValue= 0;
                switch(firstState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        setBackgroundCurrentStyleCategoryStateFirstValue = true;
                        BackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                        setCaretInstanceCurrentColorCategoryStateFirstValue = true;
                        CaretInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory.Primary;
                        setCaretInstanceHeightFirstValue = true;
                        CaretInstanceHeightFirstValue = 14f;
                        setCaretInstanceWidthFirstValue = true;
                        CaretInstanceWidthFirstValue = 1f;
                        setCaretInstanceXFirstValue = true;
                        CaretInstanceXFirstValue = 9f;
                        if (interpolationValue < 1)
                        {
                            this.CaretInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.CaretInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setCaretInstanceYFirstValue = true;
                        CaretInstanceYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.CaretInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.CaretInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightFirstValue = true;
                        FocusedIndicatorHeightFirstValue = 2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorYFirstValue = true;
                        FocusedIndicatorYFirstValue = 2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightFirstValue = true;
                        HeightFirstValue = 24f;
                        setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setPlaceholderTextInstanceHeightFirstValue = true;
                        PlaceholderTextInstanceHeightFirstValue = -4f;
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.Text = "Text Placeholder";
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setPlaceholderTextInstanceWidthFirstValue = true;
                        PlaceholderTextInstanceWidthFirstValue = -8f;
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PlaceholderTextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setSelectionInstanceCurrentColorCategoryStateFirstValue = true;
                        SelectionInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        setSelectionInstanceHeightFirstValue = true;
                        SelectionInstanceHeightFirstValue = -4f;
                        setSelectionInstanceWidthFirstValue = true;
                        SelectionInstanceWidthFirstValue = 7f;
                        if (interpolationValue < 1)
                        {
                            this.SelectionInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setSelectionInstanceXFirstValue = true;
                        SelectionInstanceXFirstValue = 15f;
                        if (interpolationValue < 1)
                        {
                            this.SelectionInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.SelectionInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setSelectionInstanceYFirstValue = true;
                        SelectionInstanceYFirstValue = 0f;
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceHeightFirstValue = true;
                        TextInstanceHeightFirstValue = -4f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        setTextInstanceCurrentStyleCategoryStateFirstValue = true;
                        TextInstanceCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.Text = "";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setTextInstanceWidthFirstValue = true;
                        TextInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextInstanceXFirstValue = true;
                        TextInstanceXFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTextInstanceYFirstValue = true;
                        TextInstanceYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthFirstValue = true;
                        WidthFirstValue = 256f;
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        setBackgroundCurrentStyleCategoryStateSecondValue = true;
                        BackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                        setCaretInstanceCurrentColorCategoryStateSecondValue = true;
                        CaretInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.ColoredRectangleRuntime.ColorCategory.Primary;
                        setCaretInstanceHeightSecondValue = true;
                        CaretInstanceHeightSecondValue = 14f;
                        setCaretInstanceWidthSecondValue = true;
                        CaretInstanceWidthSecondValue = 1f;
                        setCaretInstanceXSecondValue = true;
                        CaretInstanceXSecondValue = 9f;
                        if (interpolationValue >= 1)
                        {
                            this.CaretInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CaretInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setCaretInstanceYSecondValue = true;
                        CaretInstanceYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.CaretInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CaretInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightSecondValue = true;
                        FocusedIndicatorHeightSecondValue = 2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorYSecondValue = true;
                        FocusedIndicatorYSecondValue = 2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightSecondValue = true;
                        HeightSecondValue = 24f;
                        setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setPlaceholderTextInstanceHeightSecondValue = true;
                        PlaceholderTextInstanceHeightSecondValue = -4f;
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.Text = "Text Placeholder";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setPlaceholderTextInstanceWidthSecondValue = true;
                        PlaceholderTextInstanceWidthSecondValue = -8f;
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PlaceholderTextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setSelectionInstanceCurrentColorCategoryStateSecondValue = true;
                        SelectionInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        setSelectionInstanceHeightSecondValue = true;
                        SelectionInstanceHeightSecondValue = -4f;
                        setSelectionInstanceWidthSecondValue = true;
                        SelectionInstanceWidthSecondValue = 7f;
                        if (interpolationValue >= 1)
                        {
                            this.SelectionInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setSelectionInstanceXSecondValue = true;
                        SelectionInstanceXSecondValue = 15f;
                        if (interpolationValue >= 1)
                        {
                            this.SelectionInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SelectionInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setSelectionInstanceYSecondValue = true;
                        SelectionInstanceYSecondValue = 0f;
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceHeightSecondValue = true;
                        TextInstanceHeightSecondValue = -4f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        setTextInstanceCurrentStyleCategoryStateSecondValue = true;
                        TextInstanceCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.Text = "";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setTextInstanceWidthSecondValue = true;
                        TextInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextInstanceXSecondValue = true;
                        TextInstanceXSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTextInstanceYSecondValue = true;
                        TextInstanceYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthSecondValue = true;
                        WidthSecondValue = 256f;
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundCurrentStyleCategoryStateFirstValue && setBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentStyleCategoryStateFirstValue, BackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setCaretInstanceCurrentColorCategoryStateFirstValue && setCaretInstanceCurrentColorCategoryStateSecondValue)
                {
                    CaretInstance.InterpolateBetween(CaretInstanceCurrentColorCategoryStateFirstValue, CaretInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setCaretInstanceHeightFirstValue && setCaretInstanceHeightSecondValue)
                {
                    CaretInstance.Height = CaretInstanceHeightFirstValue * (1 - interpolationValue) + CaretInstanceHeightSecondValue * interpolationValue;
                }
                if (setCaretInstanceWidthFirstValue && setCaretInstanceWidthSecondValue)
                {
                    CaretInstance.Width = CaretInstanceWidthFirstValue * (1 - interpolationValue) + CaretInstanceWidthSecondValue * interpolationValue;
                }
                if (setCaretInstanceXFirstValue && setCaretInstanceXSecondValue)
                {
                    CaretInstance.X = CaretInstanceXFirstValue * (1 - interpolationValue) + CaretInstanceXSecondValue * interpolationValue;
                }
                if (setCaretInstanceYFirstValue && setCaretInstanceYSecondValue)
                {
                    CaretInstance.Y = CaretInstanceYFirstValue * (1 - interpolationValue) + CaretInstanceYSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentColorCategoryStateFirstValue && setFocusedIndicatorCurrentColorCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentColorCategoryStateFirstValue, FocusedIndicatorCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorHeightFirstValue && setFocusedIndicatorHeightSecondValue)
                {
                    FocusedIndicator.Height = FocusedIndicatorHeightFirstValue * (1 - interpolationValue) + FocusedIndicatorHeightSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentStyleCategoryStateFirstValue && setFocusedIndicatorCurrentStyleCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentStyleCategoryStateFirstValue, FocusedIndicatorCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorYFirstValue && setFocusedIndicatorYSecondValue)
                {
                    FocusedIndicator.Y = FocusedIndicatorYFirstValue * (1 - interpolationValue) + FocusedIndicatorYSecondValue * interpolationValue;
                }
                if (setHeightFirstValue && setHeightSecondValue)
                {
                    Height = HeightFirstValue * (1 - interpolationValue) + HeightSecondValue * interpolationValue;
                }
                if (setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue && setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue)
                {
                    PlaceholderTextInstance.InterpolateBetween(PlaceholderTextInstanceCurrentColorCategoryStateFirstValue, PlaceholderTextInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setPlaceholderTextInstanceHeightFirstValue && setPlaceholderTextInstanceHeightSecondValue)
                {
                    PlaceholderTextInstance.Height = PlaceholderTextInstanceHeightFirstValue * (1 - interpolationValue) + PlaceholderTextInstanceHeightSecondValue * interpolationValue;
                }
                if (setPlaceholderTextInstanceWidthFirstValue && setPlaceholderTextInstanceWidthSecondValue)
                {
                    PlaceholderTextInstance.Width = PlaceholderTextInstanceWidthFirstValue * (1 - interpolationValue) + PlaceholderTextInstanceWidthSecondValue * interpolationValue;
                }
                if (setSelectionInstanceCurrentColorCategoryStateFirstValue && setSelectionInstanceCurrentColorCategoryStateSecondValue)
                {
                    SelectionInstance.InterpolateBetween(SelectionInstanceCurrentColorCategoryStateFirstValue, SelectionInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setSelectionInstanceHeightFirstValue && setSelectionInstanceHeightSecondValue)
                {
                    SelectionInstance.Height = SelectionInstanceHeightFirstValue * (1 - interpolationValue) + SelectionInstanceHeightSecondValue * interpolationValue;
                }
                if (setSelectionInstanceWidthFirstValue && setSelectionInstanceWidthSecondValue)
                {
                    SelectionInstance.Width = SelectionInstanceWidthFirstValue * (1 - interpolationValue) + SelectionInstanceWidthSecondValue * interpolationValue;
                }
                if (setSelectionInstanceXFirstValue && setSelectionInstanceXSecondValue)
                {
                    SelectionInstance.X = SelectionInstanceXFirstValue * (1 - interpolationValue) + SelectionInstanceXSecondValue * interpolationValue;
                }
                if (setSelectionInstanceYFirstValue && setSelectionInstanceYSecondValue)
                {
                    SelectionInstance.Y = SelectionInstanceYFirstValue * (1 - interpolationValue) + SelectionInstanceYSecondValue * interpolationValue;
                }
                if (setTextInstanceCurrentColorCategoryStateFirstValue && setTextInstanceCurrentColorCategoryStateSecondValue)
                {
                    TextInstance.InterpolateBetween(TextInstanceCurrentColorCategoryStateFirstValue, TextInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextInstanceHeightFirstValue && setTextInstanceHeightSecondValue)
                {
                    TextInstance.Height = TextInstanceHeightFirstValue * (1 - interpolationValue) + TextInstanceHeightSecondValue * interpolationValue;
                }
                if (setTextInstanceCurrentStyleCategoryStateFirstValue && setTextInstanceCurrentStyleCategoryStateSecondValue)
                {
                    TextInstance.InterpolateBetween(TextInstanceCurrentStyleCategoryStateFirstValue, TextInstanceCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextInstanceWidthFirstValue && setTextInstanceWidthSecondValue)
                {
                    TextInstance.Width = TextInstanceWidthFirstValue * (1 - interpolationValue) + TextInstanceWidthSecondValue * interpolationValue;
                }
                if (setTextInstanceXFirstValue && setTextInstanceXSecondValue)
                {
                    TextInstance.X = TextInstanceXFirstValue * (1 - interpolationValue) + TextInstanceXSecondValue * interpolationValue;
                }
                if (setTextInstanceYFirstValue && setTextInstanceYSecondValue)
                {
                    TextInstance.Y = TextInstanceYFirstValue * (1 - interpolationValue) + TextInstanceYSecondValue * interpolationValue;
                }
                if (setWidthFirstValue && setWidthSecondValue)
                {
                    Width = WidthFirstValue * (1 - interpolationValue) + WidthSecondValue * interpolationValue;
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            public void InterpolateBetween (TextBoxCategory firstState, TextBoxCategory secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = false;
                bool setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory PlaceholderTextInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory PlaceholderTextInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextInstanceCurrentColorCategoryStateFirstValue = false;
                bool setTextInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                switch(firstState)
                {
                    case  TextBoxCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  TextBoxCategory.Disabled:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                    case  TextBoxCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Gray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  TextBoxCategory.Selected:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                }
                switch(secondState)
                {
                    case  TextBoxCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  TextBoxCategory.Disabled:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                    case  TextBoxCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Gray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  TextBoxCategory.Selected:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue = true;
                        PlaceholderTextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setPlaceholderTextInstanceCurrentColorCategoryStateFirstValue && setPlaceholderTextInstanceCurrentColorCategoryStateSecondValue)
                {
                    PlaceholderTextInstance.InterpolateBetween(PlaceholderTextInstanceCurrentColorCategoryStateFirstValue, PlaceholderTextInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextInstanceCurrentColorCategoryStateFirstValue && setTextInstanceCurrentColorCategoryStateSecondValue)
                {
                    TextInstance.InterpolateBetween(TextInstanceCurrentColorCategoryStateFirstValue, TextInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (interpolationValue < 1)
                {
                    mCurrentTextBoxCategoryState = firstState;
                }
                else
                {
                    mCurrentTextBoxCategoryState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            public void InterpolateBetween (LineModeCategory firstState, LineModeCategory secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                switch(firstState)
                {
                    case  LineModeCategory.Single:
                        break;
                    case  LineModeCategory.Multi:
                        break;
                }
                switch(secondState)
                {
                    case  LineModeCategory.Single:
                        break;
                    case  LineModeCategory.Multi:
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (interpolationValue < 1)
                {
                    mCurrentLineModeCategoryState = firstState;
                }
                else
                {
                    mCurrentLineModeCategoryState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.TextBoxRuntime.VariableState fromState,NewGum.GumRuntimes.Controls.TextBoxRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.TextBoxRuntime.TextBoxCategory fromState,NewGum.GumRuntimes.Controls.TextBoxRuntime.TextBoxCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (TextBoxCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.Categories.First(item => item.Name == "TextBoxCategory").States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentTextBoxCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (TextBoxCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentTextBoxCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.TextBoxRuntime.LineModeCategory fromState,NewGum.GumRuntimes.Controls.TextBoxRuntime.LineModeCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (LineModeCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.Categories.First(item => item.Name == "LineModeCategory").States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentLineModeCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (LineModeCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentLineModeCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = SelectionInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Height",
                            Type = "float",
                            Value = SelectionInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Width",
                            Type = "float",
                            Value = SelectionInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = SelectionInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X",
                            Type = "float",
                            Value = SelectionInstance.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = SelectionInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X Units",
                            Type = "PositionUnitType",
                            Value = SelectionInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Y",
                            Type = "float",
                            Value = SelectionInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height",
                            Type = "float",
                            Value = TextInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextInstance.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Text",
                            Type = "string",
                            Value = TextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width",
                            Type = "float",
                            Value = TextInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X",
                            Type = "float",
                            Value = TextInstance.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y",
                            Type = "float",
                            Value = TextInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TextInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = CaretInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Height",
                            Type = "float",
                            Value = CaretInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Width",
                            Type = "float",
                            Value = CaretInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X",
                            Type = "float",
                            Value = CaretInstance.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = CaretInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X Units",
                            Type = "PositionUnitType",
                            Value = CaretInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y",
                            Type = "float",
                            Value = CaretInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = CaretInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = CaretInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Height",
                            Type = "float",
                            Value = PlaceholderTextInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = PlaceholderTextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Text",
                            Type = "string",
                            Value = PlaceholderTextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = PlaceholderTextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Width",
                            Type = "float",
                            Value = PlaceholderTextInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PlaceholderTextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = PlaceholderTextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = PlaceholderTextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = PlaceholderTextInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = PlaceholderTextInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width + 256f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = SelectionInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Height",
                            Type = "float",
                            Value = SelectionInstance.Height + -4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Width",
                            Type = "float",
                            Value = SelectionInstance.Width + 7f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = SelectionInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X",
                            Type = "float",
                            Value = SelectionInstance.X + 15f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = SelectionInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.X Units",
                            Type = "PositionUnitType",
                            Value = SelectionInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SelectionInstance.Y",
                            Type = "float",
                            Value = SelectionInstance.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height",
                            Type = "float",
                            Value = TextInstance.Height + -4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextInstance.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Text",
                            Type = "string",
                            Value = TextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width",
                            Type = "float",
                            Value = TextInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X",
                            Type = "float",
                            Value = TextInstance.X + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y",
                            Type = "float",
                            Value = TextInstance.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TextInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = CaretInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Height",
                            Type = "float",
                            Value = CaretInstance.Height + 14f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Width",
                            Type = "float",
                            Value = CaretInstance.Width + 1f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X",
                            Type = "float",
                            Value = CaretInstance.X + 9f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = CaretInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.X Units",
                            Type = "PositionUnitType",
                            Value = CaretInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y",
                            Type = "float",
                            Value = CaretInstance.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = CaretInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CaretInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = CaretInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Height",
                            Type = "float",
                            Value = PlaceholderTextInstance.Height + -4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = PlaceholderTextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Text",
                            Type = "string",
                            Value = PlaceholderTextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = PlaceholderTextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Width",
                            Type = "float",
                            Value = PlaceholderTextInstance.Width + -8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PlaceholderTextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = PlaceholderTextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = PlaceholderTextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = PlaceholderTextInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = PlaceholderTextInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height + 2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y + 2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (TextBoxCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  TextBoxCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Disabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Selected:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (TextBoxCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  TextBoxCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Disabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  TextBoxCategory.Selected:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PlaceholderTextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = PlaceholderTextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (LineModeCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  LineModeCategory.Single:
                        break;
                    case  LineModeCategory.Multi:
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (LineModeCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  LineModeCategory.Single:
                        break;
                    case  LineModeCategory.Multi:
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                    else if (category.Name == "TextBoxCategory")
                    {
                        if(state.Name == "Enabled") this.mCurrentTextBoxCategoryState = TextBoxCategory.Enabled;
                        if(state.Name == "Disabled") this.mCurrentTextBoxCategoryState = TextBoxCategory.Disabled;
                        if(state.Name == "Highlighted") this.mCurrentTextBoxCategoryState = TextBoxCategory.Highlighted;
                        if(state.Name == "Selected") this.mCurrentTextBoxCategoryState = TextBoxCategory.Selected;
                    }
                    else if (category.Name == "LineModeCategory")
                    {
                        if(state.Name == "Single") this.mCurrentLineModeCategoryState = LineModeCategory.Single;
                        if(state.Name == "Multi") this.mCurrentLineModeCategoryState = LineModeCategory.Multi;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.NineSliceRuntime Background { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime SelectionInstance { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextInstance { get; set; }
            public NewGum.GumRuntimes.ColoredRectangleRuntime CaretInstance { get; set; }
            public NewGum.GumRuntimes.TextRuntime PlaceholderTextInstance { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime FocusedIndicator { get; set; }
            public string PlaceholderText
            {
                get
                {
                    return PlaceholderTextInstance.Text;
                }
                set
                {
                    if (PlaceholderTextInstance.Text != value)
                    {
                        PlaceholderTextInstance.Text = value;
                        PlaceholderTextChanged?.Invoke(this, null);
                    }
                }
            }
            public event System.EventHandler PlaceholderTextChanged;
            public TextBoxRuntime () 
            	: this(true, true)
            {
            }
            public TextBoxRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            	: base(false, tryCreateFormsObject)
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Components.First(item => item.Name == "Controls/TextBox");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                var wasSuppressed = this.IsLayoutSuspended;
                if(!wasSuppressed) this.SuspendLayout();
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                if(!wasSuppressed) this.ResumeLayout();
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                Background = this.GetGraphicalUiElementByName("Background") as NewGum.GumRuntimes.NineSliceRuntime;
                SelectionInstance = this.GetGraphicalUiElementByName("SelectionInstance") as NewGum.GumRuntimes.NineSliceRuntime;
                TextInstance = this.GetGraphicalUiElementByName("TextInstance") as NewGum.GumRuntimes.TextRuntime;
                CaretInstance = this.GetGraphicalUiElementByName("CaretInstance") as NewGum.GumRuntimes.ColoredRectangleRuntime;
                PlaceholderTextInstance = this.GetGraphicalUiElementByName("PlaceholderTextInstance") as NewGum.GumRuntimes.TextRuntime;
                FocusedIndicator = this.GetGraphicalUiElementByName("FocusedIndicator") as NewGum.GumRuntimes.NineSliceRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new FlatRedBall.Forms.Controls.TextBox(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public FlatRedBall.Forms.Controls.TextBox FormsControl {get => (FlatRedBall.Forms.Controls.TextBox) FormsControlAsObject;}
        }
    }
