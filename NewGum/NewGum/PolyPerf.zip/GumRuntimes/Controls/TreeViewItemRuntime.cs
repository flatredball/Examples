using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes.Controls
{
    public partial class TreeViewItemRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
