    using System.Linq;
    namespace NewGum.GumRuntimes.Controls
    {
        public partial class ListBoxItemRuntime : NewGum.GumRuntimes.ContainerRuntime
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            public enum ListBoxItemCategory
            {
                Enabled,
                Highlighted,
                Selected,
                Focused
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            ListBoxItemCategory? mCurrentListBoxItemCategoryState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                            Background.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                            TextInstance.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextInstance.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            FocusedIndicator.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            FocusedIndicator.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                            Height = 0f;
                            HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            Width = 0f;
                            WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background.Height = 0f;
                            Background.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background.Width = 0f;
                            Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background.X = 0f;
                            Background.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            Background.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            Background.Y = 0f;
                            Background.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            Background.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TextInstance.Height = 0f;
                            TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            TextInstance.Text = "ListBox Item";
                            TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TextInstance.Width = -8f;
                            TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            FocusedIndicator.Height = 2f;
                            FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            FocusedIndicator.Visible = false;
                            FocusedIndicator.Y = -2f;
                            FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            break;
                    }
                }
            }
            public ListBoxItemCategory? CurrentListBoxItemCategoryState
            {
                get
                {
                    return mCurrentListBoxItemCategoryState;
                }
                set
                {
                    if (value != null)
                    {
                        mCurrentListBoxItemCategoryState = value;
                        switch(mCurrentListBoxItemCategoryState)
                        {
                            case  ListBoxItemCategory.Enabled:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                Background.Visible = false;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ListBoxItemCategory.Highlighted:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                                Background.Visible = true;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ListBoxItemCategory.Selected:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                                Background.Visible = true;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ListBoxItemCategory.Focused:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                Background.Visible = false;
                                FocusedIndicator.Visible = true;
                                break;
                        }
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackgroundHeightFirstValue = false;
                bool setBackgroundHeightSecondValue = false;
                float BackgroundHeightFirstValue= 0;
                float BackgroundHeightSecondValue= 0;
                bool setBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackgroundWidthFirstValue = false;
                bool setBackgroundWidthSecondValue = false;
                float BackgroundWidthFirstValue= 0;
                float BackgroundWidthSecondValue= 0;
                bool setBackgroundXFirstValue = false;
                bool setBackgroundXSecondValue = false;
                float BackgroundXFirstValue= 0;
                float BackgroundXSecondValue= 0;
                bool setBackgroundYFirstValue = false;
                bool setBackgroundYSecondValue = false;
                float BackgroundYFirstValue= 0;
                float BackgroundYSecondValue= 0;
                bool setFocusedIndicatorCurrentColorCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setFocusedIndicatorHeightFirstValue = false;
                bool setFocusedIndicatorHeightSecondValue = false;
                float FocusedIndicatorHeightFirstValue= 0;
                float FocusedIndicatorHeightSecondValue= 0;
                bool setFocusedIndicatorCurrentStyleCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setFocusedIndicatorYFirstValue = false;
                bool setFocusedIndicatorYSecondValue = false;
                float FocusedIndicatorYFirstValue= 0;
                float FocusedIndicatorYSecondValue= 0;
                bool setHeightFirstValue = false;
                bool setHeightSecondValue = false;
                float HeightFirstValue= 0;
                float HeightSecondValue= 0;
                bool setTextInstanceCurrentColorCategoryStateFirstValue = false;
                bool setTextInstanceCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextInstanceCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextInstanceHeightFirstValue = false;
                bool setTextInstanceHeightSecondValue = false;
                float TextInstanceHeightFirstValue= 0;
                float TextInstanceHeightSecondValue= 0;
                bool setTextInstanceCurrentStyleCategoryStateFirstValue = false;
                bool setTextInstanceCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextInstanceCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextInstanceCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextInstanceWidthFirstValue = false;
                bool setTextInstanceWidthSecondValue = false;
                float TextInstanceWidthFirstValue= 0;
                float TextInstanceWidthSecondValue= 0;
                bool setWidthFirstValue = false;
                bool setWidthSecondValue = false;
                float WidthFirstValue= 0;
                float WidthSecondValue= 0;
                switch(firstState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        setBackgroundHeightFirstValue = true;
                        BackgroundHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackgroundCurrentStyleCategoryStateFirstValue = true;
                        BackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        setBackgroundWidthFirstValue = true;
                        BackgroundWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackgroundXFirstValue = true;
                        BackgroundXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackgroundYFirstValue = true;
                        BackgroundYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightFirstValue = true;
                        FocusedIndicatorHeightFirstValue = 2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorYFirstValue = true;
                        FocusedIndicatorYFirstValue = -2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightFirstValue = true;
                        HeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextInstanceCurrentColorCategoryStateFirstValue = true;
                        TextInstanceCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceHeightFirstValue = true;
                        TextInstanceHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        setTextInstanceCurrentStyleCategoryStateFirstValue = true;
                        TextInstanceCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.Text = "ListBox Item";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setTextInstanceWidthFirstValue = true;
                        TextInstanceWidthFirstValue = -8f;
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthFirstValue = true;
                        WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        setBackgroundHeightSecondValue = true;
                        BackgroundHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackgroundCurrentStyleCategoryStateSecondValue = true;
                        BackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        setBackgroundWidthSecondValue = true;
                        BackgroundWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackgroundXSecondValue = true;
                        BackgroundXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackgroundYSecondValue = true;
                        BackgroundYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightSecondValue = true;
                        FocusedIndicatorHeightSecondValue = 2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorYSecondValue = true;
                        FocusedIndicatorYSecondValue = -2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightSecondValue = true;
                        HeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextInstanceCurrentColorCategoryStateSecondValue = true;
                        TextInstanceCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        setTextInstanceHeightSecondValue = true;
                        TextInstanceHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        setTextInstanceCurrentStyleCategoryStateSecondValue = true;
                        TextInstanceCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.Text = "ListBox Item";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        setTextInstanceWidthSecondValue = true;
                        TextInstanceWidthSecondValue = -8f;
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthSecondValue = true;
                        WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundHeightFirstValue && setBackgroundHeightSecondValue)
                {
                    Background.Height = BackgroundHeightFirstValue * (1 - interpolationValue) + BackgroundHeightSecondValue * interpolationValue;
                }
                if (setBackgroundCurrentStyleCategoryStateFirstValue && setBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentStyleCategoryStateFirstValue, BackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundWidthFirstValue && setBackgroundWidthSecondValue)
                {
                    Background.Width = BackgroundWidthFirstValue * (1 - interpolationValue) + BackgroundWidthSecondValue * interpolationValue;
                }
                if (setBackgroundXFirstValue && setBackgroundXSecondValue)
                {
                    Background.X = BackgroundXFirstValue * (1 - interpolationValue) + BackgroundXSecondValue * interpolationValue;
                }
                if (setBackgroundYFirstValue && setBackgroundYSecondValue)
                {
                    Background.Y = BackgroundYFirstValue * (1 - interpolationValue) + BackgroundYSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentColorCategoryStateFirstValue && setFocusedIndicatorCurrentColorCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentColorCategoryStateFirstValue, FocusedIndicatorCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorHeightFirstValue && setFocusedIndicatorHeightSecondValue)
                {
                    FocusedIndicator.Height = FocusedIndicatorHeightFirstValue * (1 - interpolationValue) + FocusedIndicatorHeightSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentStyleCategoryStateFirstValue && setFocusedIndicatorCurrentStyleCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentStyleCategoryStateFirstValue, FocusedIndicatorCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorYFirstValue && setFocusedIndicatorYSecondValue)
                {
                    FocusedIndicator.Y = FocusedIndicatorYFirstValue * (1 - interpolationValue) + FocusedIndicatorYSecondValue * interpolationValue;
                }
                if (setHeightFirstValue && setHeightSecondValue)
                {
                    Height = HeightFirstValue * (1 - interpolationValue) + HeightSecondValue * interpolationValue;
                }
                if (setTextInstanceCurrentColorCategoryStateFirstValue && setTextInstanceCurrentColorCategoryStateSecondValue)
                {
                    TextInstance.InterpolateBetween(TextInstanceCurrentColorCategoryStateFirstValue, TextInstanceCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextInstanceHeightFirstValue && setTextInstanceHeightSecondValue)
                {
                    TextInstance.Height = TextInstanceHeightFirstValue * (1 - interpolationValue) + TextInstanceHeightSecondValue * interpolationValue;
                }
                if (setTextInstanceCurrentStyleCategoryStateFirstValue && setTextInstanceCurrentStyleCategoryStateSecondValue)
                {
                    TextInstance.InterpolateBetween(TextInstanceCurrentStyleCategoryStateFirstValue, TextInstanceCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextInstanceWidthFirstValue && setTextInstanceWidthSecondValue)
                {
                    TextInstance.Width = TextInstanceWidthFirstValue * (1 - interpolationValue) + TextInstanceWidthSecondValue * interpolationValue;
                }
                if (setWidthFirstValue && setWidthSecondValue)
                {
                    Width = WidthFirstValue * (1 - interpolationValue) + WidthSecondValue * interpolationValue;
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            public void InterpolateBetween (ListBoxItemCategory firstState, ListBoxItemCategory secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                switch(firstState)
                {
                    case  ListBoxItemCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.Background.Visible = false;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue < 1)
                        {
                            this.Background.Visible = true;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Selected:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.Background.Visible = true;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Focused:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.Background.Visible = false;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        break;
                }
                switch(secondState)
                {
                    case  ListBoxItemCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Visible = false;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Visible = true;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Selected:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Visible = true;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        break;
                    case  ListBoxItemCategory.Focused:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Visible = false;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (interpolationValue < 1)
                {
                    mCurrentListBoxItemCategoryState = firstState;
                }
                else
                {
                    mCurrentListBoxItemCategoryState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.ListBoxItemRuntime.VariableState fromState,NewGum.GumRuntimes.Controls.ListBoxItemRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.ListBoxItemRuntime.ListBoxItemCategory fromState,NewGum.GumRuntimes.Controls.ListBoxItemRuntime.ListBoxItemCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (ListBoxItemCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.Categories.First(item => item.Name == "ListBoxItemCategory").States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentListBoxItemCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (ListBoxItemCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentListBoxItemCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height Units",
                            Type = "DimensionUnitType",
                            Value = HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width Units",
                            Type = "DimensionUnitType",
                            Value = WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Height",
                            Type = "float",
                            Value = Background.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width",
                            Type = "float",
                            Value = Background.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X",
                            Type = "float",
                            Value = Background.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X Units",
                            Type = "PositionUnitType",
                            Value = Background.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y",
                            Type = "float",
                            Value = Background.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y Units",
                            Type = "PositionUnitType",
                            Value = Background.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height",
                            Type = "float",
                            Value = TextInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextInstance.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Text",
                            Type = "string",
                            Value = TextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width",
                            Type = "float",
                            Value = TextInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height Units",
                            Type = "DimensionUnitType",
                            Value = HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width Units",
                            Type = "DimensionUnitType",
                            Value = WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Height",
                            Type = "float",
                            Value = Background.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width",
                            Type = "float",
                            Value = Background.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X",
                            Type = "float",
                            Value = Background.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.X Units",
                            Type = "PositionUnitType",
                            Value = Background.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y",
                            Type = "float",
                            Value = Background.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Y Units",
                            Type = "PositionUnitType",
                            Value = Background.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextInstance.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height",
                            Type = "float",
                            Value = TextInstance.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextInstance.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Text",
                            Type = "string",
                            Value = TextInstance.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TextInstance.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width",
                            Type = "float",
                            Value = TextInstance.Width + -8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TextInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextInstance.X Units",
                            Type = "PositionUnitType",
                            Value = TextInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height + 2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y + -2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (ListBoxItemCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  ListBoxItemCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Selected:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Focused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (ListBoxItemCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  ListBoxItemCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Selected:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ListBoxItemCategory.Focused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Visible",
                            Type = "bool",
                            Value = Background.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                    else if (category.Name == "ListBoxItemCategory")
                    {
                        if(state.Name == "Enabled") this.mCurrentListBoxItemCategoryState = ListBoxItemCategory.Enabled;
                        if(state.Name == "Highlighted") this.mCurrentListBoxItemCategoryState = ListBoxItemCategory.Highlighted;
                        if(state.Name == "Selected") this.mCurrentListBoxItemCategoryState = ListBoxItemCategory.Selected;
                        if(state.Name == "Focused") this.mCurrentListBoxItemCategoryState = ListBoxItemCategory.Focused;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.NineSliceRuntime Background { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextInstance { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime FocusedIndicator { get; set; }
            public string ListItemDisplayText
            {
                get
                {
                    return TextInstance.Text;
                }
                set
                {
                    if (TextInstance.Text != value)
                    {
                        TextInstance.Text = value;
                        ListItemDisplayTextChanged?.Invoke(this, null);
                    }
                }
            }
            public event System.EventHandler ListItemDisplayTextChanged;
            public ListBoxItemRuntime () 
            	: this(true, true)
            {
            }
            public ListBoxItemRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            	: base(false, tryCreateFormsObject)
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Components.First(item => item.Name == "Controls/ListBoxItem");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                var wasSuppressed = this.IsLayoutSuspended;
                if(!wasSuppressed) this.SuspendLayout();
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                if(!wasSuppressed) this.ResumeLayout();
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                Background = this.GetGraphicalUiElementByName("Background") as NewGum.GumRuntimes.NineSliceRuntime;
                TextInstance = this.GetGraphicalUiElementByName("TextInstance") as NewGum.GumRuntimes.TextRuntime;
                FocusedIndicator = this.GetGraphicalUiElementByName("FocusedIndicator") as NewGum.GumRuntimes.NineSliceRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new FlatRedBall.Forms.Controls.ListBoxItem(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public FlatRedBall.Forms.Controls.ListBoxItem FormsControl {get => (FlatRedBall.Forms.Controls.ListBoxItem) FormsControlAsObject;}
        }
    }
