    using System.Linq;
    namespace NewGum.GumRuntimes.Controls
    {
        public partial class ButtonTabRuntime : NewGum.GumRuntimes.ContainerRuntime
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            public enum ButtonCategory
            {
                Enabled,
                Disabled,
                Highlighted,
                Pushed,
                HighlightedFocused,
                Focused,
                DisabledFocused
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            ButtonCategory? mCurrentButtonCategoryState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            TabText.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                            FocusedIndicator.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                            Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Background.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                            TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            FocusedIndicator.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            FocusedIndicator.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                            Height = 32f;
                            Width = 0f;
                            WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            Background.Width = 32f;
                            Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            TabText.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TabText.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            TabText.Text = "Tab 1";
                            TabText.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TabText.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            TabText.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TabText.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            TabText.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            FocusedIndicator.Height = 2f;
                            FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            FocusedIndicator.Visible = false;
                            FocusedIndicator.Width = -8f;
                            FocusedIndicator.Y = 2f;
                            FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            break;
                    }
                }
            }
            public ButtonCategory? CurrentButtonCategoryState
            {
                get
                {
                    return mCurrentButtonCategoryState;
                }
                set
                {
                    if (value != null)
                    {
                        mCurrentButtonCategoryState = value;
                        switch(mCurrentButtonCategoryState)
                        {
                            case  ButtonCategory.Enabled:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ButtonCategory.Disabled:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ButtonCategory.Highlighted:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ButtonCategory.Pushed:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryDark;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = false;
                                break;
                            case  ButtonCategory.HighlightedFocused:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = true;
                                break;
                            case  ButtonCategory.Focused:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                                FocusedIndicator.Visible = true;
                                break;
                            case  ButtonCategory.DisabledFocused:
                                Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                                TabText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                                FocusedIndicator.Visible = true;
                                break;
                        }
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackgroundWidthFirstValue = false;
                bool setBackgroundWidthSecondValue = false;
                float BackgroundWidthFirstValue= 0;
                float BackgroundWidthSecondValue= 0;
                bool setFocusedIndicatorCurrentColorCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory FocusedIndicatorCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setFocusedIndicatorHeightFirstValue = false;
                bool setFocusedIndicatorHeightSecondValue = false;
                float FocusedIndicatorHeightFirstValue= 0;
                float FocusedIndicatorHeightSecondValue= 0;
                bool setFocusedIndicatorCurrentStyleCategoryStateFirstValue = false;
                bool setFocusedIndicatorCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory FocusedIndicatorCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setFocusedIndicatorWidthFirstValue = false;
                bool setFocusedIndicatorWidthSecondValue = false;
                float FocusedIndicatorWidthFirstValue= 0;
                float FocusedIndicatorWidthSecondValue= 0;
                bool setFocusedIndicatorYFirstValue = false;
                bool setFocusedIndicatorYSecondValue = false;
                float FocusedIndicatorYFirstValue= 0;
                float FocusedIndicatorYSecondValue= 0;
                bool setHeightFirstValue = false;
                bool setHeightSecondValue = false;
                float HeightFirstValue= 0;
                float HeightSecondValue= 0;
                bool setTabTextCurrentColorCategoryStateFirstValue = false;
                bool setTabTextCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TabTextCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TabTextCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setWidthFirstValue = false;
                bool setWidthSecondValue = false;
                float WidthFirstValue= 0;
                float WidthSecondValue= 0;
                switch(firstState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackgroundCurrentStyleCategoryStateFirstValue = true;
                        BackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                        setBackgroundWidthFirstValue = true;
                        BackgroundWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightFirstValue = true;
                        FocusedIndicatorHeightFirstValue = 2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateFirstValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorWidthFirstValue = true;
                        FocusedIndicatorWidthFirstValue = -8f;
                        setFocusedIndicatorYFirstValue = true;
                        FocusedIndicatorYFirstValue = 2f;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightFirstValue = true;
                        HeightFirstValue = 32f;
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TabText.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.Text = "Tab 1";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabText.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthFirstValue = true;
                        WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackgroundCurrentStyleCategoryStateSecondValue = true;
                        BackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                        setBackgroundWidthSecondValue = true;
                        BackgroundWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Background.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setFocusedIndicatorCurrentColorCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        setFocusedIndicatorHeightSecondValue = true;
                        FocusedIndicatorHeightSecondValue = 2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                        }
                        setFocusedIndicatorCurrentStyleCategoryStateSecondValue = true;
                        FocusedIndicatorCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setFocusedIndicatorWidthSecondValue = true;
                        FocusedIndicatorWidthSecondValue = -8f;
                        setFocusedIndicatorYSecondValue = true;
                        FocusedIndicatorYSecondValue = 2f;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setHeightSecondValue = true;
                        HeightSecondValue = 32f;
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TabText.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.HorizontalAlignment = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.Parent = this.GetGraphicalUiElementByName("Background") ?? this;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.Text = "Tab 1";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.VerticalAlignment = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabText.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setWidthSecondValue = true;
                        WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundCurrentStyleCategoryStateFirstValue && setBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentStyleCategoryStateFirstValue, BackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundWidthFirstValue && setBackgroundWidthSecondValue)
                {
                    Background.Width = BackgroundWidthFirstValue * (1 - interpolationValue) + BackgroundWidthSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentColorCategoryStateFirstValue && setFocusedIndicatorCurrentColorCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentColorCategoryStateFirstValue, FocusedIndicatorCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorHeightFirstValue && setFocusedIndicatorHeightSecondValue)
                {
                    FocusedIndicator.Height = FocusedIndicatorHeightFirstValue * (1 - interpolationValue) + FocusedIndicatorHeightSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorCurrentStyleCategoryStateFirstValue && setFocusedIndicatorCurrentStyleCategoryStateSecondValue)
                {
                    FocusedIndicator.InterpolateBetween(FocusedIndicatorCurrentStyleCategoryStateFirstValue, FocusedIndicatorCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setFocusedIndicatorWidthFirstValue && setFocusedIndicatorWidthSecondValue)
                {
                    FocusedIndicator.Width = FocusedIndicatorWidthFirstValue * (1 - interpolationValue) + FocusedIndicatorWidthSecondValue * interpolationValue;
                }
                if (setFocusedIndicatorYFirstValue && setFocusedIndicatorYSecondValue)
                {
                    FocusedIndicator.Y = FocusedIndicatorYFirstValue * (1 - interpolationValue) + FocusedIndicatorYSecondValue * interpolationValue;
                }
                if (setHeightFirstValue && setHeightSecondValue)
                {
                    Height = HeightFirstValue * (1 - interpolationValue) + HeightSecondValue * interpolationValue;
                }
                if (setTabTextCurrentColorCategoryStateFirstValue && setTabTextCurrentColorCategoryStateSecondValue)
                {
                    TabText.InterpolateBetween(TabTextCurrentColorCategoryStateFirstValue, TabTextCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setWidthFirstValue && setWidthSecondValue)
                {
                    Width = WidthFirstValue * (1 - interpolationValue) + WidthSecondValue * interpolationValue;
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            public void InterpolateBetween (ButtonCategory firstState, ButtonCategory secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setTabTextCurrentColorCategoryStateFirstValue = false;
                bool setTabTextCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TabTextCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TabTextCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                switch(firstState)
                {
                    case  ButtonCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Disabled:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                    case  ButtonCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Pushed:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryDark;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.HighlightedFocused:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Focused:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.DisabledFocused:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateFirstValue = true;
                        TabTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                }
                switch(secondState)
                {
                    case  ButtonCategory.Enabled:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Disabled:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                    case  ButtonCategory.Highlighted:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Pushed:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryDark;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = false;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.HighlightedFocused:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.Focused:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        break;
                    case  ButtonCategory.DisabledFocused:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.FocusedIndicator.Visible = true;
                        }
                        setTabTextCurrentColorCategoryStateSecondValue = true;
                        TabTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTabTextCurrentColorCategoryStateFirstValue && setTabTextCurrentColorCategoryStateSecondValue)
                {
                    TabText.InterpolateBetween(TabTextCurrentColorCategoryStateFirstValue, TabTextCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (interpolationValue < 1)
                {
                    mCurrentButtonCategoryState = firstState;
                }
                else
                {
                    mCurrentButtonCategoryState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.ButtonTabRuntime.VariableState fromState,NewGum.GumRuntimes.Controls.ButtonTabRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.Controls.ButtonTabRuntime.ButtonCategory fromState,NewGum.GumRuntimes.Controls.ButtonTabRuntime.ButtonCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (ButtonCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.Categories.First(item => item.Name == "ButtonCategory").States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentButtonCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (ButtonCategory toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentButtonCategoryState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width Units",
                            Type = "DimensionUnitType",
                            Value = WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "X Origin",
                            Type = "HorizontalAlignment",
                            Value = XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "X Units",
                            Type = "PositionUnitType",
                            Value = XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Y Origin",
                            Type = "VerticalAlignment",
                            Value = YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width",
                            Type = "float",
                            Value = Background.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabText.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TabText.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Parent",
                            Type = "string",
                            Value = TabText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Text",
                            Type = "string",
                            Value = TabText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TabText.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabText.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.X Units",
                            Type = "PositionUnitType",
                            Value = TabText.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabText.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Y Units",
                            Type = "PositionUnitType",
                            Value = TabText.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Parent",
                            Type = "string",
                            Value = FocusedIndicator.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Width",
                            Type = "float",
                            Value = FocusedIndicator.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Height",
                            Type = "float",
                            Value = Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width",
                            Type = "float",
                            Value = Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Width Units",
                            Type = "DimensionUnitType",
                            Value = WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "X Origin",
                            Type = "HorizontalAlignment",
                            Value = XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "X Units",
                            Type = "PositionUnitType",
                            Value = XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Y Origin",
                            Type = "VerticalAlignment",
                            Value = YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width",
                            Type = "float",
                            Value = Background.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabText.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.HorizontalAlignment",
                            Type = "HorizontalAlignment",
                            Value = TabText.HorizontalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Parent",
                            Type = "string",
                            Value = TabText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Text",
                            Type = "string",
                            Value = TabText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.VerticalAlignment",
                            Type = "VerticalAlignment",
                            Value = TabText.VerticalAlignment
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabText.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.X Units",
                            Type = "PositionUnitType",
                            Value = TabText.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabText.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.Y Units",
                            Type = "PositionUnitType",
                            Value = TabText.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = FocusedIndicator.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height",
                            Type = "float",
                            Value = FocusedIndicator.Height + 2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Height Units",
                            Type = "DimensionUnitType",
                            Value = FocusedIndicator.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Parent",
                            Type = "string",
                            Value = FocusedIndicator.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = FocusedIndicator.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Width",
                            Type = "float",
                            Value = FocusedIndicator.Width + -8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y",
                            Type = "float",
                            Value = FocusedIndicator.Y + 2f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Origin",
                            Type = "VerticalAlignment",
                            Value = FocusedIndicator.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Y Units",
                            Type = "PositionUnitType",
                            Value = FocusedIndicator.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (ButtonCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  ButtonCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Disabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Pushed:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.HighlightedFocused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Focused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.DisabledFocused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (ButtonCategory state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  ButtonCategory.Enabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Disabled:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Highlighted:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Pushed:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.HighlightedFocused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.Focused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                    case  ButtonCategory.DisabledFocused:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FocusedIndicator.Visible",
                            Type = "bool",
                            Value = FocusedIndicator.Visible
                        }
                        );
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                    else if (category.Name == "ButtonCategory")
                    {
                        if(state.Name == "Enabled") this.mCurrentButtonCategoryState = ButtonCategory.Enabled;
                        if(state.Name == "Disabled") this.mCurrentButtonCategoryState = ButtonCategory.Disabled;
                        if(state.Name == "Highlighted") this.mCurrentButtonCategoryState = ButtonCategory.Highlighted;
                        if(state.Name == "Pushed") this.mCurrentButtonCategoryState = ButtonCategory.Pushed;
                        if(state.Name == "HighlightedFocused") this.mCurrentButtonCategoryState = ButtonCategory.HighlightedFocused;
                        if(state.Name == "Focused") this.mCurrentButtonCategoryState = ButtonCategory.Focused;
                        if(state.Name == "DisabledFocused") this.mCurrentButtonCategoryState = ButtonCategory.DisabledFocused;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.NineSliceRuntime Background { get; set; }
            public NewGum.GumRuntimes.TextRuntime TabText { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime FocusedIndicator { get; set; }
            public string TabDisplayText
            {
                get
                {
                    return TabText.Text;
                }
                set
                {
                    if (TabText.Text != value)
                    {
                        TabText.Text = value;
                        TabDisplayTextChanged?.Invoke(this, null);
                    }
                }
            }
            public event System.EventHandler TabDisplayTextChanged;
            public ButtonTabRuntime () 
            	: this(true, true)
            {
            }
            public ButtonTabRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            	: base(false, tryCreateFormsObject)
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Components.First(item => item.Name == "Controls/ButtonTab");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                var wasSuppressed = this.IsLayoutSuspended;
                if(!wasSuppressed) this.SuspendLayout();
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                if(!wasSuppressed) this.ResumeLayout();
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                Background = this.GetGraphicalUiElementByName("Background") as NewGum.GumRuntimes.NineSliceRuntime;
                TabText = this.GetGraphicalUiElementByName("TabText") as NewGum.GumRuntimes.TextRuntime;
                FocusedIndicator = this.GetGraphicalUiElementByName("FocusedIndicator") as NewGum.GumRuntimes.NineSliceRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new FlatRedBall.Forms.Controls.Button(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public FlatRedBall.Forms.Controls.Button FormsControl {get => (FlatRedBall.Forms.Controls.Button) FormsControlAsObject;}
        }
    }
