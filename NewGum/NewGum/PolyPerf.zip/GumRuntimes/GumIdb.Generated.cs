    namespace FlatRedBall.Gum
    {
        public  class GumIdbExtensions
        {
            public static void RegisterTypes () 
            {
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Circle", typeof(NewGum.GumRuntimes.CircleRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("ColoredRectangle", typeof(NewGum.GumRuntimes.ColoredRectangleRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Container", typeof(NewGum.GumRuntimes.ContainerRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Container<T>", typeof(NewGum.GumRuntimes.ContainerRuntime<>));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("NineSlice", typeof(NewGum.GumRuntimes.NineSliceRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Polygon", typeof(NewGum.GumRuntimes.PolygonRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Rectangle", typeof(NewGum.GumRuntimes.RectangleRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Sprite", typeof(NewGum.GumRuntimes.SpriteRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Text", typeof(NewGum.GumRuntimes.TextRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonClose", typeof(NewGum.GumRuntimes.Controls.ButtonCloseRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonConfirm", typeof(NewGum.GumRuntimes.Controls.ButtonConfirmRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonDeny", typeof(NewGum.GumRuntimes.Controls.ButtonDenyRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonIcon", typeof(NewGum.GumRuntimes.Controls.ButtonIconRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonStandard", typeof(NewGum.GumRuntimes.Controls.ButtonStandardRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonStandardIcon", typeof(NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ButtonTab", typeof(NewGum.GumRuntimes.Controls.ButtonTabRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/CheckBox", typeof(NewGum.GumRuntimes.Controls.CheckBoxRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ComboBox", typeof(NewGum.GumRuntimes.Controls.ComboBoxRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ListBox", typeof(NewGum.GumRuntimes.Controls.ListBoxRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ListBoxItem", typeof(NewGum.GumRuntimes.Controls.ListBoxItemRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/PasswordBox", typeof(NewGum.GumRuntimes.Controls.PasswordBoxRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/RadioButton", typeof(NewGum.GumRuntimes.Controls.RadioButtonRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ScrollBar", typeof(NewGum.GumRuntimes.Controls.ScrollBarRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/ScrollViewer", typeof(NewGum.GumRuntimes.Controls.ScrollViewerRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/Slider", typeof(NewGum.GumRuntimes.Controls.SliderRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/TextBox", typeof(NewGum.GumRuntimes.Controls.TextBoxRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/TreeView", typeof(NewGum.GumRuntimes.Controls.TreeViewRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/TreeViewItem", typeof(NewGum.GumRuntimes.Controls.TreeViewItemRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/TreeViewToggle", typeof(NewGum.GumRuntimes.Controls.TreeViewToggleRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Controls/UserControl", typeof(NewGum.GumRuntimes.Controls.UserControlRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/CautionLines", typeof(NewGum.GumRuntimes.Elements.CautionLinesRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/DividerHorizontal", typeof(NewGum.GumRuntimes.Elements.DividerHorizontalRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/DividerVertical", typeof(NewGum.GumRuntimes.Elements.DividerVerticalRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/Icon", typeof(NewGum.GumRuntimes.Elements.IconRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/Label", typeof(NewGum.GumRuntimes.Elements.LabelRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/PercentBar", typeof(NewGum.GumRuntimes.Elements.PercentBarRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/PercentBarIcon", typeof(NewGum.GumRuntimes.Elements.PercentBarIconRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("Elements/VerticalLines", typeof(NewGum.GumRuntimes.Elements.VerticalLinesRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("DemoScreenGum", typeof(NewGum.GumRuntimes.DemoScreenGumRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("NewScreenGum", typeof(NewGum.GumRuntimes.NewScreenGumRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("StylesScreen", typeof(NewGum.GumRuntimes.StylesScreenRuntime));
                GumRuntime.ElementSaveExtensions.RegisterGueInstantiationType("PolygonScreenGum", typeof(NewGum.GumRuntimes.PolygonScreenGumRuntime));
                
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.Button)] = typeof(NewGum.GumRuntimes.Controls.ButtonCloseRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.CheckBox)] = typeof(NewGum.GumRuntimes.Controls.CheckBoxRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ComboBox)] = typeof(NewGum.GumRuntimes.Controls.ComboBoxRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ListBox)] = typeof(NewGum.GumRuntimes.Controls.ListBoxRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ListBoxItem)] = typeof(NewGum.GumRuntimes.Controls.ListBoxItemRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.PasswordBox)] = typeof(NewGum.GumRuntimes.Controls.PasswordBoxRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.RadioButton)] = typeof(NewGum.GumRuntimes.Controls.RadioButtonRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ScrollBar)] = typeof(NewGum.GumRuntimes.Controls.ScrollBarRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ScrollViewer)] = typeof(NewGum.GumRuntimes.Controls.ScrollViewerRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.Slider)] = typeof(NewGum.GumRuntimes.Controls.SliderRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.TextBox)] = typeof(NewGum.GumRuntimes.Controls.TextBoxRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.TreeView)] = typeof(NewGum.GumRuntimes.Controls.TreeViewRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.TreeViewItem)] = typeof(NewGum.GumRuntimes.Controls.TreeViewItemRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.ToggleButton)] = typeof(NewGum.GumRuntimes.Controls.TreeViewToggleRuntime);
                FlatRedBall.Forms.Controls.FrameworkElement.DefaultFormsComponents[typeof(FlatRedBall.Forms.Controls.UserControl)] = typeof(NewGum.GumRuntimes.Controls.UserControlRuntime);
            }
        }
    }
