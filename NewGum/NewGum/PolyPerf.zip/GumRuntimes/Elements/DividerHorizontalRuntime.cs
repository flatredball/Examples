using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes.Elements
{
    public partial class DividerHorizontalRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
