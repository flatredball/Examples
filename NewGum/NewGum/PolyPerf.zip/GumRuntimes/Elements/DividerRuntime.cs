using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes.Elements
{
    public partial class DividerRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
