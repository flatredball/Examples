using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes.Elements
{
    public partial class IconRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
