using System;
using System.Collections.Generic;
using System.Linq;

namespace NewGum.GumRuntimes
{
    public partial class StylesScreenRuntime
    {
        partial void CustomInitialize () 
        {
        }
    }
}
