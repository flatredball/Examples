    using System.Linq;
    namespace NewGum.GumRuntimes
    {
        public partial class StylesScreenRuntime : Gum.Wireframe.GraphicalUiElement
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            TextTitle.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextH1.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextH2.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextH3.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextNormal.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextStrong.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextEmphasis.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextSmall.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            TextTiny.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                            Solid.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            Bordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            BracketHorizontal.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            BracketVertical.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            Tab.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            TabBordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            Outlined.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            OutlinedHeavy.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            Panel.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                            ButtonStandardInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonStandardIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonTabInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                            PercentBarPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            PercentBarLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            PercentBarCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            PercentBarIconPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            PercentBarIconLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            PercentBarIconCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            LabelInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            CheckBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            ListBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            SliderInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            TextBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            PasswordBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                            DividerVerticalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            DividerHorizontalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            IconInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            CautionLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            VerticalLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                            TextBlack.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextDarkGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextLightGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextWhite.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextPrimaryDark.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextPrimary.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextPrimaryLight.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextAccent.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextSuccess.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextWarning.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextWarning1.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                            TextTitle.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextTitle.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            TextH1.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextH1.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.H1;
                            TextH2.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextH2.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.H2;
                            TextH3.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextH3.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.H3;
                            TextNormal.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextNormal.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextStrong.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextStrong.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Strong;
                            TextEmphasis.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextEmphasis.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Emphasis;
                            TextSmall.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextSmall.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Small;
                            TextTiny.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextTiny.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                            Solid.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Solid.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                            Bordered.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Bordered.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                            BracketHorizontal.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            BracketHorizontal.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketHorizontal;
                            BracketVertical.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            BracketVertical.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketVertical;
                            Tab.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Tab.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Tab;
                            TabBordered.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            TabBordered.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                            Outlined.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Outlined.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Outlined;
                            OutlinedHeavy.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            OutlinedHeavy.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.OutlinedHeavy;
                            Panel.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Panel.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            PercentBarLinesDecor.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                            PercentBarCautionDecor.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                            PercentBarIconPrimary.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            PercentBarIconPrimary.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                            PercentBarIconPrimary.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                            PercentBarIconPrimary.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                            PercentBarIconLinesDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            PercentBarIconLinesDecor.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.VerticalLines;
                            PercentBarIconLinesDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                            PercentBarIconLinesDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                            PercentBarIconCautionDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            PercentBarIconCautionDecor.CurrentBarDecorCategoryState = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.CautionLines;
                            PercentBarIconCautionDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                            PercentBarIconCautionDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                            CautionLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                            VerticalLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                            TextBlack.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                            TextBlack.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextDarkGray.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.DarkGray;
                            TextDarkGray.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextGray.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                            TextGray.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextLightGray.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.LightGray;
                            TextLightGray.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextWhite.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                            TextWhite.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextPrimaryDark.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryDark;
                            TextPrimaryDark.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextPrimary.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TextPrimary.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextPrimaryLight.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryLight;
                            TextPrimaryLight.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextAccent.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Accent;
                            TextAccent.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextSuccess.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Success;
                            TextSuccess.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextWarning.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Warning;
                            TextWarning.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextWarning1.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Danger;
                            TextWarning1.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                            TextStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            TextStyleContainer.Height = 0f;
                            TextStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            TextStyleContainer.Width = 85f;
                            TextStyleContainer.X = 57f;
                            TextStyleContainer.Y = 11f;
                            TextTitle.Text = "H2";
                            TextH1.Text = "Heading 1";
                            TextH2.Text = "Heading 2";
                            TextH3.Text = "Heading 3";
                            TextNormal.Text = "Normal";
                            TextStrong.Text = "Strong";
                            TextEmphasis.Text = "Emphasis";
                            TextSmall.Text = "Small";
                            TextTiny.Text = "Tiny";
                            Solid.Height = 32f;
                            Solid.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Solid.Width = 32f;
                            Solid.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Solid.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            Solid.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Solid.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            Solid.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Bordered.Height = 32f;
                            Bordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Bordered.Width = 32f;
                            Bordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Bordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            Bordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Bordered.Y = 8f;
                            Bordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            Bordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            BracketHorizontal.Height = 32f;
                            BracketHorizontal.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            BracketHorizontal.Width = 32f;
                            BracketHorizontal.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            BracketHorizontal.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            BracketHorizontal.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            BracketHorizontal.Y = 8f;
                            BracketHorizontal.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            BracketHorizontal.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            BracketVertical.Height = 32f;
                            BracketVertical.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            BracketVertical.Width = 32f;
                            BracketVertical.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            BracketVertical.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            BracketVertical.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            BracketVertical.Y = 8f;
                            BracketVertical.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            BracketVertical.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Tab.Height = 32f;
                            Tab.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Tab.Width = 32f;
                            Tab.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Tab.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            Tab.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Tab.Y = 8f;
                            Tab.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            Tab.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            TabBordered.Height = 32f;
                            TabBordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            TabBordered.Width = 32f;
                            TabBordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            TabBordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            TabBordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            TabBordered.Y = 8f;
                            TabBordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            TabBordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Outlined.Height = 32f;
                            Outlined.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Outlined.Width = 32f;
                            Outlined.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Outlined.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            Outlined.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Outlined.Y = 8f;
                            Outlined.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            Outlined.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            OutlinedHeavy.Height = 32f;
                            OutlinedHeavy.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            OutlinedHeavy.Width = 32f;
                            OutlinedHeavy.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            OutlinedHeavy.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            OutlinedHeavy.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            OutlinedHeavy.Y = 8f;
                            OutlinedHeavy.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            OutlinedHeavy.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Panel.Height = 32f;
                            Panel.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Panel.Width = 32f;
                            Panel.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Panel.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            Panel.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            Panel.Y = 8f;
                            Panel.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            Panel.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            NineSliceStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            NineSliceStyleContainer.Height = 0f;
                            NineSliceStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            NineSliceStyleContainer.Width = 0f;
                            NineSliceStyleContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            NineSliceStyleContainer.X = 9f;
                            NineSliceStyleContainer.Y = 14f;
                            ButtonsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ButtonsContainer.Height = 0f;
                            ButtonsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            ButtonsContainer.Width = 0f;
                            ButtonsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            ButtonsContainer.X = 159f;
                            ButtonsContainer.Y = 12f;
                            ButtonStandardInstance.ButtonDisplayText = "Standard";
                            ButtonStandardIconInstance.ButtonDisplayText = "Standard Icon";
                            ButtonStandardIconInstance.Y = 8f;
                            ButtonTabInstance.TabDisplayText = "Tab";
                            ButtonTabInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                            ButtonTabInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                            ButtonTabInstance.Y = 8f;
                            ButtonTabInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                            ButtonIconInstance.Y = 8f;
                            ButtonConfirmInstance.ButtonDisplayText = "Confirm";
                            ButtonConfirmInstance.Y = 8f;
                            ButtonDenyInstance.ButtonDisplayText = "Deny";
                            ButtonDenyInstance.Y = 8f;
                            ButtonCloseInstance.Y = 8f;
                            ElementsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ElementsContainer.Height = 0f;
                            ElementsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            ElementsContainer.X = 310f;
                            ElementsContainer.Y = 14f;
                            PercentBarPrimary.Width = 0f;
                            PercentBarPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarLinesDecor.Width = 0f;
                            PercentBarLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarLinesDecor.Y = 4f;
                            PercentBarCautionDecor.Width = 0f;
                            PercentBarCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarCautionDecor.Y = 4f;
                            PercentBarIconPrimary.Width = 0f;
                            PercentBarIconPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarIconPrimary.Y = 4f;
                            PercentBarIconLinesDecor.Width = 0f;
                            PercentBarIconLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarIconLinesDecor.Y = 4f;
                            PercentBarIconCautionDecor.Width = 0f;
                            PercentBarIconCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarIconCautionDecor.Y = 4f;
                            ControlsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ControlsContainer.Height = 0f;
                            ControlsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            ControlsContainer.Width = 256f;
                            ControlsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            ControlsContainer.X = 482f;
                            ControlsContainer.Y = 12f;
                            CheckBoxInstance.Width = 0f;
                            CheckBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance.Width = 0f;
                            RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance.Y = 4f;
                            ComboBoxInstance.Width = 0f;
                            ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ComboBoxInstance.Y = 4f;
                            ListBoxInstance.Height = 96f;
                            ListBoxInstance.Width = 0f;
                            ListBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ListBoxInstance.Y = 4f;
                            SliderInstance.Width = 0f;
                            SliderInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            SliderInstance.Y = 4f;
                            TextBoxInstance.Y = 4f;
                            PasswordBoxInstance.Y = 4f;
                            DividerVerticalInstance.Height = 24f;
                            DividerVerticalInstance.Y = 4f;
                            DividerHorizontalInstance.Width = 0f;
                            DividerHorizontalInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerHorizontalInstance.Y = 4f;
                            CautionLinesInstance.Width = 0f;
                            CautionLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            CautionLinesInstance.Y = 4f;
                            VerticalLinesInstance.Width = 0f;
                            VerticalLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            VerticalLinesInstance.Y = 4f;
                            ColorContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ColorContainer.Height = 0f;
                            ColorContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            ColorContainer.X = 774f;
                            ColorContainer.Y = 24f;
                            TextBlack.Text = "Black";
                            TextBlack.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextDarkGray.Text = "Dark Gray";
                            TextDarkGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextGray.Text = "Gray";
                            TextGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextLightGray.Text = "Light Gray";
                            TextLightGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextWhite.Text = "White";
                            TextWhite.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextPrimaryDark.Text = "Primary Dark";
                            TextPrimaryDark.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextPrimary.Text = "Primary";
                            TextPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextPrimaryLight.Text = "Primary Light";
                            TextPrimaryLight.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextAccent.Text = "Accent";
                            TextAccent.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextSuccess.Text = "Success";
                            TextSuccess.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextWarning.Text = "Warning";
                            TextWarning.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            TextWarning1.Text = "Danger";
                            TextWarning1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            break;
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBorderedCurrentColorCategoryStateFirstValue = false;
                bool setBorderedCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BorderedCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BorderedCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBorderedHeightFirstValue = false;
                bool setBorderedHeightSecondValue = false;
                float BorderedHeightFirstValue= 0;
                float BorderedHeightSecondValue= 0;
                bool setBorderedCurrentStyleCategoryStateFirstValue = false;
                bool setBorderedCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BorderedCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BorderedCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBorderedWidthFirstValue = false;
                bool setBorderedWidthSecondValue = false;
                float BorderedWidthFirstValue= 0;
                float BorderedWidthSecondValue= 0;
                bool setBorderedYFirstValue = false;
                bool setBorderedYSecondValue = false;
                float BorderedYFirstValue= 0;
                float BorderedYSecondValue= 0;
                bool setBracketHorizontalCurrentColorCategoryStateFirstValue = false;
                bool setBracketHorizontalCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BracketHorizontalCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BracketHorizontalCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBracketHorizontalHeightFirstValue = false;
                bool setBracketHorizontalHeightSecondValue = false;
                float BracketHorizontalHeightFirstValue= 0;
                float BracketHorizontalHeightSecondValue= 0;
                bool setBracketHorizontalCurrentStyleCategoryStateFirstValue = false;
                bool setBracketHorizontalCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BracketHorizontalCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BracketHorizontalCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBracketHorizontalWidthFirstValue = false;
                bool setBracketHorizontalWidthSecondValue = false;
                float BracketHorizontalWidthFirstValue= 0;
                float BracketHorizontalWidthSecondValue= 0;
                bool setBracketHorizontalYFirstValue = false;
                bool setBracketHorizontalYSecondValue = false;
                float BracketHorizontalYFirstValue= 0;
                float BracketHorizontalYSecondValue= 0;
                bool setBracketVerticalCurrentColorCategoryStateFirstValue = false;
                bool setBracketVerticalCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BracketVerticalCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BracketVerticalCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBracketVerticalHeightFirstValue = false;
                bool setBracketVerticalHeightSecondValue = false;
                float BracketVerticalHeightFirstValue= 0;
                float BracketVerticalHeightSecondValue= 0;
                bool setBracketVerticalCurrentStyleCategoryStateFirstValue = false;
                bool setBracketVerticalCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BracketVerticalCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BracketVerticalCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBracketVerticalWidthFirstValue = false;
                bool setBracketVerticalWidthSecondValue = false;
                float BracketVerticalWidthFirstValue= 0;
                float BracketVerticalWidthSecondValue= 0;
                bool setBracketVerticalYFirstValue = false;
                bool setBracketVerticalYSecondValue = false;
                float BracketVerticalYFirstValue= 0;
                float BracketVerticalYSecondValue= 0;
                bool setButtonCloseInstanceYFirstValue = false;
                bool setButtonCloseInstanceYSecondValue = false;
                float ButtonCloseInstanceYFirstValue= 0;
                float ButtonCloseInstanceYSecondValue= 0;
                bool setButtonConfirmInstanceYFirstValue = false;
                bool setButtonConfirmInstanceYSecondValue = false;
                float ButtonConfirmInstanceYFirstValue= 0;
                float ButtonConfirmInstanceYSecondValue= 0;
                bool setButtonDenyInstanceYFirstValue = false;
                bool setButtonDenyInstanceYSecondValue = false;
                float ButtonDenyInstanceYFirstValue= 0;
                float ButtonDenyInstanceYSecondValue= 0;
                bool setButtonIconInstanceYFirstValue = false;
                bool setButtonIconInstanceYSecondValue = false;
                float ButtonIconInstanceYFirstValue= 0;
                float ButtonIconInstanceYSecondValue= 0;
                bool setButtonsContainerHeightFirstValue = false;
                bool setButtonsContainerHeightSecondValue = false;
                float ButtonsContainerHeightFirstValue= 0;
                float ButtonsContainerHeightSecondValue= 0;
                bool setButtonsContainerWidthFirstValue = false;
                bool setButtonsContainerWidthSecondValue = false;
                float ButtonsContainerWidthFirstValue= 0;
                float ButtonsContainerWidthSecondValue= 0;
                bool setButtonsContainerXFirstValue = false;
                bool setButtonsContainerXSecondValue = false;
                float ButtonsContainerXFirstValue= 0;
                float ButtonsContainerXSecondValue= 0;
                bool setButtonsContainerYFirstValue = false;
                bool setButtonsContainerYSecondValue = false;
                float ButtonsContainerYFirstValue= 0;
                float ButtonsContainerYSecondValue= 0;
                bool setButtonStandardIconInstanceYFirstValue = false;
                bool setButtonStandardIconInstanceYSecondValue = false;
                float ButtonStandardIconInstanceYFirstValue= 0;
                float ButtonStandardIconInstanceYSecondValue= 0;
                bool setButtonTabInstanceYFirstValue = false;
                bool setButtonTabInstanceYSecondValue = false;
                float ButtonTabInstanceYFirstValue= 0;
                float ButtonTabInstanceYSecondValue= 0;
                bool setCautionLinesInstanceWidthFirstValue = false;
                bool setCautionLinesInstanceWidthSecondValue = false;
                float CautionLinesInstanceWidthFirstValue= 0;
                float CautionLinesInstanceWidthSecondValue= 0;
                bool setCautionLinesInstanceYFirstValue = false;
                bool setCautionLinesInstanceYSecondValue = false;
                float CautionLinesInstanceYFirstValue= 0;
                float CautionLinesInstanceYSecondValue= 0;
                bool setCheckBoxInstanceWidthFirstValue = false;
                bool setCheckBoxInstanceWidthSecondValue = false;
                float CheckBoxInstanceWidthFirstValue= 0;
                float CheckBoxInstanceWidthSecondValue= 0;
                bool setColorContainerHeightFirstValue = false;
                bool setColorContainerHeightSecondValue = false;
                float ColorContainerHeightFirstValue= 0;
                float ColorContainerHeightSecondValue= 0;
                bool setColorContainerXFirstValue = false;
                bool setColorContainerXSecondValue = false;
                float ColorContainerXFirstValue= 0;
                float ColorContainerXSecondValue= 0;
                bool setColorContainerYFirstValue = false;
                bool setColorContainerYSecondValue = false;
                float ColorContainerYFirstValue= 0;
                float ColorContainerYSecondValue= 0;
                bool setComboBoxInstanceWidthFirstValue = false;
                bool setComboBoxInstanceWidthSecondValue = false;
                float ComboBoxInstanceWidthFirstValue= 0;
                float ComboBoxInstanceWidthSecondValue= 0;
                bool setComboBoxInstanceYFirstValue = false;
                bool setComboBoxInstanceYSecondValue = false;
                float ComboBoxInstanceYFirstValue= 0;
                float ComboBoxInstanceYSecondValue= 0;
                bool setControlsContainerHeightFirstValue = false;
                bool setControlsContainerHeightSecondValue = false;
                float ControlsContainerHeightFirstValue= 0;
                float ControlsContainerHeightSecondValue= 0;
                bool setControlsContainerWidthFirstValue = false;
                bool setControlsContainerWidthSecondValue = false;
                float ControlsContainerWidthFirstValue= 0;
                float ControlsContainerWidthSecondValue= 0;
                bool setControlsContainerXFirstValue = false;
                bool setControlsContainerXSecondValue = false;
                float ControlsContainerXFirstValue= 0;
                float ControlsContainerXSecondValue= 0;
                bool setControlsContainerYFirstValue = false;
                bool setControlsContainerYSecondValue = false;
                float ControlsContainerYFirstValue= 0;
                float ControlsContainerYSecondValue= 0;
                bool setDividerHorizontalInstanceWidthFirstValue = false;
                bool setDividerHorizontalInstanceWidthSecondValue = false;
                float DividerHorizontalInstanceWidthFirstValue= 0;
                float DividerHorizontalInstanceWidthSecondValue= 0;
                bool setDividerHorizontalInstanceYFirstValue = false;
                bool setDividerHorizontalInstanceYSecondValue = false;
                float DividerHorizontalInstanceYFirstValue= 0;
                float DividerHorizontalInstanceYSecondValue= 0;
                bool setDividerVerticalInstanceHeightFirstValue = false;
                bool setDividerVerticalInstanceHeightSecondValue = false;
                float DividerVerticalInstanceHeightFirstValue= 0;
                float DividerVerticalInstanceHeightSecondValue= 0;
                bool setDividerVerticalInstanceYFirstValue = false;
                bool setDividerVerticalInstanceYSecondValue = false;
                float DividerVerticalInstanceYFirstValue= 0;
                float DividerVerticalInstanceYSecondValue= 0;
                bool setElementsContainerHeightFirstValue = false;
                bool setElementsContainerHeightSecondValue = false;
                float ElementsContainerHeightFirstValue= 0;
                float ElementsContainerHeightSecondValue= 0;
                bool setElementsContainerXFirstValue = false;
                bool setElementsContainerXSecondValue = false;
                float ElementsContainerXFirstValue= 0;
                float ElementsContainerXSecondValue= 0;
                bool setElementsContainerYFirstValue = false;
                bool setElementsContainerYSecondValue = false;
                float ElementsContainerYFirstValue= 0;
                float ElementsContainerYSecondValue= 0;
                bool setListBoxInstanceHeightFirstValue = false;
                bool setListBoxInstanceHeightSecondValue = false;
                float ListBoxInstanceHeightFirstValue= 0;
                float ListBoxInstanceHeightSecondValue= 0;
                bool setListBoxInstanceWidthFirstValue = false;
                bool setListBoxInstanceWidthSecondValue = false;
                float ListBoxInstanceWidthFirstValue= 0;
                float ListBoxInstanceWidthSecondValue= 0;
                bool setListBoxInstanceYFirstValue = false;
                bool setListBoxInstanceYSecondValue = false;
                float ListBoxInstanceYFirstValue= 0;
                float ListBoxInstanceYSecondValue= 0;
                bool setNineSliceStyleContainerHeightFirstValue = false;
                bool setNineSliceStyleContainerHeightSecondValue = false;
                float NineSliceStyleContainerHeightFirstValue= 0;
                float NineSliceStyleContainerHeightSecondValue= 0;
                bool setNineSliceStyleContainerWidthFirstValue = false;
                bool setNineSliceStyleContainerWidthSecondValue = false;
                float NineSliceStyleContainerWidthFirstValue= 0;
                float NineSliceStyleContainerWidthSecondValue= 0;
                bool setNineSliceStyleContainerXFirstValue = false;
                bool setNineSliceStyleContainerXSecondValue = false;
                float NineSliceStyleContainerXFirstValue= 0;
                float NineSliceStyleContainerXSecondValue= 0;
                bool setNineSliceStyleContainerYFirstValue = false;
                bool setNineSliceStyleContainerYSecondValue = false;
                float NineSliceStyleContainerYFirstValue= 0;
                float NineSliceStyleContainerYSecondValue= 0;
                bool setOutlinedCurrentColorCategoryStateFirstValue = false;
                bool setOutlinedCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory OutlinedCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory OutlinedCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setOutlinedHeightFirstValue = false;
                bool setOutlinedHeightSecondValue = false;
                float OutlinedHeightFirstValue= 0;
                float OutlinedHeightSecondValue= 0;
                bool setOutlinedCurrentStyleCategoryStateFirstValue = false;
                bool setOutlinedCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory OutlinedCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory OutlinedCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setOutlinedWidthFirstValue = false;
                bool setOutlinedWidthSecondValue = false;
                float OutlinedWidthFirstValue= 0;
                float OutlinedWidthSecondValue= 0;
                bool setOutlinedYFirstValue = false;
                bool setOutlinedYSecondValue = false;
                float OutlinedYFirstValue= 0;
                float OutlinedYSecondValue= 0;
                bool setOutlinedHeavyCurrentColorCategoryStateFirstValue = false;
                bool setOutlinedHeavyCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory OutlinedHeavyCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory OutlinedHeavyCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setOutlinedHeavyHeightFirstValue = false;
                bool setOutlinedHeavyHeightSecondValue = false;
                float OutlinedHeavyHeightFirstValue= 0;
                float OutlinedHeavyHeightSecondValue= 0;
                bool setOutlinedHeavyCurrentStyleCategoryStateFirstValue = false;
                bool setOutlinedHeavyCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory OutlinedHeavyCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory OutlinedHeavyCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setOutlinedHeavyWidthFirstValue = false;
                bool setOutlinedHeavyWidthSecondValue = false;
                float OutlinedHeavyWidthFirstValue= 0;
                float OutlinedHeavyWidthSecondValue= 0;
                bool setOutlinedHeavyYFirstValue = false;
                bool setOutlinedHeavyYSecondValue = false;
                float OutlinedHeavyYFirstValue= 0;
                float OutlinedHeavyYSecondValue= 0;
                bool setPanelCurrentColorCategoryStateFirstValue = false;
                bool setPanelCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory PanelCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory PanelCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setPanelHeightFirstValue = false;
                bool setPanelHeightSecondValue = false;
                float PanelHeightFirstValue= 0;
                float PanelHeightSecondValue= 0;
                bool setPanelCurrentStyleCategoryStateFirstValue = false;
                bool setPanelCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory PanelCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory PanelCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setPanelWidthFirstValue = false;
                bool setPanelWidthSecondValue = false;
                float PanelWidthFirstValue= 0;
                float PanelWidthSecondValue= 0;
                bool setPanelYFirstValue = false;
                bool setPanelYSecondValue = false;
                float PanelYFirstValue= 0;
                float PanelYSecondValue= 0;
                bool setPasswordBoxInstanceYFirstValue = false;
                bool setPasswordBoxInstanceYSecondValue = false;
                float PasswordBoxInstanceYFirstValue= 0;
                float PasswordBoxInstanceYSecondValue= 0;
                bool setPercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setPercentBarCautionDecorWidthFirstValue = false;
                bool setPercentBarCautionDecorWidthSecondValue = false;
                float PercentBarCautionDecorWidthFirstValue= 0;
                float PercentBarCautionDecorWidthSecondValue= 0;
                bool setPercentBarCautionDecorYFirstValue = false;
                bool setPercentBarCautionDecorYSecondValue = false;
                float PercentBarCautionDecorYFirstValue= 0;
                float PercentBarCautionDecorYSecondValue= 0;
                bool setPercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                bool setPercentBarIconCautionDecorWidthFirstValue = false;
                bool setPercentBarIconCautionDecorWidthSecondValue = false;
                float PercentBarIconCautionDecorWidthFirstValue= 0;
                float PercentBarIconCautionDecorWidthSecondValue= 0;
                bool setPercentBarIconCautionDecorYFirstValue = false;
                bool setPercentBarIconCautionDecorYSecondValue = false;
                float PercentBarIconCautionDecorYFirstValue= 0;
                float PercentBarIconCautionDecorYSecondValue= 0;
                bool setPercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                bool setPercentBarIconLinesDecorWidthFirstValue = false;
                bool setPercentBarIconLinesDecorWidthSecondValue = false;
                float PercentBarIconLinesDecorWidthFirstValue= 0;
                float PercentBarIconLinesDecorWidthSecondValue= 0;
                bool setPercentBarIconLinesDecorYFirstValue = false;
                bool setPercentBarIconLinesDecorYSecondValue = false;
                float PercentBarIconLinesDecorYFirstValue= 0;
                float PercentBarIconLinesDecorYSecondValue= 0;
                bool setPercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory PercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                bool setPercentBarIconPrimaryWidthFirstValue = false;
                bool setPercentBarIconPrimaryWidthSecondValue = false;
                float PercentBarIconPrimaryWidthFirstValue= 0;
                float PercentBarIconPrimaryWidthSecondValue= 0;
                bool setPercentBarIconPrimaryYFirstValue = false;
                bool setPercentBarIconPrimaryYSecondValue = false;
                float PercentBarIconPrimaryYFirstValue= 0;
                float PercentBarIconPrimaryYSecondValue= 0;
                bool setPercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue = false;
                bool setPercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory PercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue= NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.None;
                bool setPercentBarLinesDecorWidthFirstValue = false;
                bool setPercentBarLinesDecorWidthSecondValue = false;
                float PercentBarLinesDecorWidthFirstValue= 0;
                float PercentBarLinesDecorWidthSecondValue= 0;
                bool setPercentBarLinesDecorYFirstValue = false;
                bool setPercentBarLinesDecorYSecondValue = false;
                float PercentBarLinesDecorYFirstValue= 0;
                float PercentBarLinesDecorYSecondValue= 0;
                bool setPercentBarPrimaryWidthFirstValue = false;
                bool setPercentBarPrimaryWidthSecondValue = false;
                float PercentBarPrimaryWidthFirstValue= 0;
                float PercentBarPrimaryWidthSecondValue= 0;
                bool setRadioButtonInstanceWidthFirstValue = false;
                bool setRadioButtonInstanceWidthSecondValue = false;
                float RadioButtonInstanceWidthFirstValue= 0;
                float RadioButtonInstanceWidthSecondValue= 0;
                bool setRadioButtonInstanceYFirstValue = false;
                bool setRadioButtonInstanceYSecondValue = false;
                float RadioButtonInstanceYFirstValue= 0;
                float RadioButtonInstanceYSecondValue= 0;
                bool setSliderInstanceWidthFirstValue = false;
                bool setSliderInstanceWidthSecondValue = false;
                float SliderInstanceWidthFirstValue= 0;
                float SliderInstanceWidthSecondValue= 0;
                bool setSliderInstanceYFirstValue = false;
                bool setSliderInstanceYSecondValue = false;
                float SliderInstanceYFirstValue= 0;
                float SliderInstanceYSecondValue= 0;
                bool setSolidCurrentColorCategoryStateFirstValue = false;
                bool setSolidCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory SolidCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory SolidCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setSolidHeightFirstValue = false;
                bool setSolidHeightSecondValue = false;
                float SolidHeightFirstValue= 0;
                float SolidHeightSecondValue= 0;
                bool setSolidCurrentStyleCategoryStateFirstValue = false;
                bool setSolidCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory SolidCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory SolidCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setSolidWidthFirstValue = false;
                bool setSolidWidthSecondValue = false;
                float SolidWidthFirstValue= 0;
                float SolidWidthSecondValue= 0;
                bool setTabCurrentColorCategoryStateFirstValue = false;
                bool setTabCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setTabHeightFirstValue = false;
                bool setTabHeightSecondValue = false;
                float TabHeightFirstValue= 0;
                float TabHeightSecondValue= 0;
                bool setTabCurrentStyleCategoryStateFirstValue = false;
                bool setTabCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setTabWidthFirstValue = false;
                bool setTabWidthSecondValue = false;
                float TabWidthFirstValue= 0;
                float TabWidthSecondValue= 0;
                bool setTabYFirstValue = false;
                bool setTabYSecondValue = false;
                float TabYFirstValue= 0;
                float TabYSecondValue= 0;
                bool setTabBorderedCurrentColorCategoryStateFirstValue = false;
                bool setTabBorderedCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabBorderedCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory TabBorderedCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setTabBorderedHeightFirstValue = false;
                bool setTabBorderedHeightSecondValue = false;
                float TabBorderedHeightFirstValue= 0;
                float TabBorderedHeightSecondValue= 0;
                bool setTabBorderedCurrentStyleCategoryStateFirstValue = false;
                bool setTabBorderedCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabBorderedCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory TabBorderedCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setTabBorderedWidthFirstValue = false;
                bool setTabBorderedWidthSecondValue = false;
                float TabBorderedWidthFirstValue= 0;
                float TabBorderedWidthSecondValue= 0;
                bool setTabBorderedYFirstValue = false;
                bool setTabBorderedYSecondValue = false;
                float TabBorderedYFirstValue= 0;
                float TabBorderedYSecondValue= 0;
                bool setTextAccentCurrentColorCategoryStateFirstValue = false;
                bool setTextAccentCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextAccentCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextAccentCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextAccentCurrentStyleCategoryStateFirstValue = false;
                bool setTextAccentCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextAccentCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextAccentCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextBlackCurrentColorCategoryStateFirstValue = false;
                bool setTextBlackCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextBlackCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextBlackCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextBlackCurrentStyleCategoryStateFirstValue = false;
                bool setTextBlackCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextBlackCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextBlackCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextBoxInstanceYFirstValue = false;
                bool setTextBoxInstanceYSecondValue = false;
                float TextBoxInstanceYFirstValue= 0;
                float TextBoxInstanceYSecondValue= 0;
                bool setTextDarkGrayCurrentColorCategoryStateFirstValue = false;
                bool setTextDarkGrayCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextDarkGrayCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextDarkGrayCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextDarkGrayCurrentStyleCategoryStateFirstValue = false;
                bool setTextDarkGrayCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextDarkGrayCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextDarkGrayCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextEmphasisCurrentColorCategoryStateFirstValue = false;
                bool setTextEmphasisCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextEmphasisCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextEmphasisCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextEmphasisCurrentStyleCategoryStateFirstValue = false;
                bool setTextEmphasisCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextEmphasisCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextEmphasisCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextGrayCurrentColorCategoryStateFirstValue = false;
                bool setTextGrayCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextGrayCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextGrayCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextGrayCurrentStyleCategoryStateFirstValue = false;
                bool setTextGrayCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextGrayCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextGrayCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextH1CurrentColorCategoryStateFirstValue = false;
                bool setTextH1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextH1CurrentStyleCategoryStateFirstValue = false;
                bool setTextH1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextH2CurrentColorCategoryStateFirstValue = false;
                bool setTextH2CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH2CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH2CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextH2CurrentStyleCategoryStateFirstValue = false;
                bool setTextH2CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH2CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH2CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextH3CurrentColorCategoryStateFirstValue = false;
                bool setTextH3CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH3CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextH3CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextH3CurrentStyleCategoryStateFirstValue = false;
                bool setTextH3CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH3CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextH3CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextLightGrayCurrentColorCategoryStateFirstValue = false;
                bool setTextLightGrayCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextLightGrayCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextLightGrayCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextLightGrayCurrentStyleCategoryStateFirstValue = false;
                bool setTextLightGrayCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextLightGrayCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextLightGrayCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextNormalCurrentColorCategoryStateFirstValue = false;
                bool setTextNormalCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextNormalCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextNormalCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextNormalCurrentStyleCategoryStateFirstValue = false;
                bool setTextNormalCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextNormalCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextNormalCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextPrimaryCurrentColorCategoryStateFirstValue = false;
                bool setTextPrimaryCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextPrimaryCurrentStyleCategoryStateFirstValue = false;
                bool setTextPrimaryCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextPrimaryDarkCurrentColorCategoryStateFirstValue = false;
                bool setTextPrimaryDarkCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryDarkCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryDarkCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextPrimaryDarkCurrentStyleCategoryStateFirstValue = false;
                bool setTextPrimaryDarkCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryDarkCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryDarkCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextPrimaryLightCurrentColorCategoryStateFirstValue = false;
                bool setTextPrimaryLightCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryLightCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextPrimaryLightCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextPrimaryLightCurrentStyleCategoryStateFirstValue = false;
                bool setTextPrimaryLightCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryLightCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextPrimaryLightCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextSmallCurrentColorCategoryStateFirstValue = false;
                bool setTextSmallCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextSmallCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextSmallCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextSmallCurrentStyleCategoryStateFirstValue = false;
                bool setTextSmallCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextSmallCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextSmallCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextStrongCurrentColorCategoryStateFirstValue = false;
                bool setTextStrongCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextStrongCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextStrongCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextStrongCurrentStyleCategoryStateFirstValue = false;
                bool setTextStrongCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextStrongCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextStrongCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextStyleContainerHeightFirstValue = false;
                bool setTextStyleContainerHeightSecondValue = false;
                float TextStyleContainerHeightFirstValue= 0;
                float TextStyleContainerHeightSecondValue= 0;
                bool setTextStyleContainerWidthFirstValue = false;
                bool setTextStyleContainerWidthSecondValue = false;
                float TextStyleContainerWidthFirstValue= 0;
                float TextStyleContainerWidthSecondValue= 0;
                bool setTextStyleContainerXFirstValue = false;
                bool setTextStyleContainerXSecondValue = false;
                float TextStyleContainerXFirstValue= 0;
                float TextStyleContainerXSecondValue= 0;
                bool setTextStyleContainerYFirstValue = false;
                bool setTextStyleContainerYSecondValue = false;
                float TextStyleContainerYFirstValue= 0;
                float TextStyleContainerYSecondValue= 0;
                bool setTextSuccessCurrentColorCategoryStateFirstValue = false;
                bool setTextSuccessCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextSuccessCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextSuccessCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextSuccessCurrentStyleCategoryStateFirstValue = false;
                bool setTextSuccessCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextSuccessCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextSuccessCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextTinyCurrentColorCategoryStateFirstValue = false;
                bool setTextTinyCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextTinyCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextTinyCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextTinyCurrentStyleCategoryStateFirstValue = false;
                bool setTextTinyCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextTinyCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextTinyCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextTitleCurrentColorCategoryStateFirstValue = false;
                bool setTextTitleCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextTitleCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextTitleCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextTitleCurrentStyleCategoryStateFirstValue = false;
                bool setTextTitleCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextTitleCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextTitleCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextWarningCurrentColorCategoryStateFirstValue = false;
                bool setTextWarningCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWarningCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWarningCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextWarningCurrentStyleCategoryStateFirstValue = false;
                bool setTextWarningCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWarningCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWarningCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextWarning1CurrentColorCategoryStateFirstValue = false;
                bool setTextWarning1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWarning1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWarning1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextWarning1CurrentStyleCategoryStateFirstValue = false;
                bool setTextWarning1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWarning1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWarning1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTextWhiteCurrentColorCategoryStateFirstValue = false;
                bool setTextWhiteCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWhiteCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TextWhiteCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTextWhiteCurrentStyleCategoryStateFirstValue = false;
                bool setTextWhiteCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWhiteCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TextWhiteCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setVerticalLinesInstanceWidthFirstValue = false;
                bool setVerticalLinesInstanceWidthSecondValue = false;
                float VerticalLinesInstanceWidthFirstValue= 0;
                float VerticalLinesInstanceWidthSecondValue= 0;
                bool setVerticalLinesInstanceYFirstValue = false;
                bool setVerticalLinesInstanceYSecondValue = false;
                float VerticalLinesInstanceYFirstValue= 0;
                float VerticalLinesInstanceYSecondValue= 0;
                switch(firstState)
                {
                    case  VariableState.Default:
                        setBorderedCurrentColorCategoryStateFirstValue = true;
                        BorderedCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBorderedHeightFirstValue = true;
                        BorderedHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Bordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Bordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBorderedCurrentStyleCategoryStateFirstValue = true;
                        BorderedCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                        setBorderedWidthFirstValue = true;
                        BorderedWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Bordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Bordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Bordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBorderedYFirstValue = true;
                        BorderedYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.Bordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Bordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketHorizontalCurrentColorCategoryStateFirstValue = true;
                        BracketHorizontalCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBracketHorizontalHeightFirstValue = true;
                        BracketHorizontalHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBracketHorizontalCurrentStyleCategoryStateFirstValue = true;
                        BracketHorizontalCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketHorizontal;
                        setBracketHorizontalWidthFirstValue = true;
                        BracketHorizontalWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketHorizontalYFirstValue = true;
                        BracketHorizontalYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketHorizontal.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketVerticalCurrentColorCategoryStateFirstValue = true;
                        BracketVerticalCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBracketVerticalHeightFirstValue = true;
                        BracketVerticalHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBracketVerticalCurrentStyleCategoryStateFirstValue = true;
                        BracketVerticalCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketVertical;
                        setBracketVerticalWidthFirstValue = true;
                        BracketVerticalWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketVerticalYFirstValue = true;
                        BracketVerticalYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.BracketVertical.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonCloseInstanceYFirstValue = true;
                        ButtonCloseInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.ButtonDisplayText = "Confirm";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonConfirmInstanceYFirstValue = true;
                        ButtonConfirmInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonDenyInstance.ButtonDisplayText = "Deny";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonDenyInstanceYFirstValue = true;
                        ButtonDenyInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonIconInstanceYFirstValue = true;
                        ButtonIconInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setButtonsContainerHeightFirstValue = true;
                        ButtonsContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setButtonsContainerWidthFirstValue = true;
                        ButtonsContainerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setButtonsContainerXFirstValue = true;
                        ButtonsContainerXFirstValue = 159f;
                        setButtonsContainerYFirstValue = true;
                        ButtonsContainerYFirstValue = 12f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonStandardIconInstance.ButtonDisplayText = "Standard Icon";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonStandardIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonStandardIconInstanceYFirstValue = true;
                        ButtonStandardIconInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonStandardInstance.ButtonDisplayText = "Standard";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonStandardInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonTabInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonTabInstance.TabDisplayText = "Tab";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonTabInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonTabInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setButtonTabInstanceYFirstValue = true;
                        ButtonTabInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonTabInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.CautionLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue < 1)
                        {
                            this.CautionLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setCautionLinesInstanceWidthFirstValue = true;
                        CautionLinesInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.CautionLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setCautionLinesInstanceYFirstValue = true;
                        CautionLinesInstanceYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.CheckBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setCheckBoxInstanceWidthFirstValue = true;
                        CheckBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.CheckBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ColorContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setColorContainerHeightFirstValue = true;
                        ColorContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ColorContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setColorContainerXFirstValue = true;
                        ColorContainerXFirstValue = 774f;
                        setColorContainerYFirstValue = true;
                        ColorContainerYFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setComboBoxInstanceWidthFirstValue = true;
                        ComboBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setComboBoxInstanceYFirstValue = true;
                        ComboBoxInstanceYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.ControlsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setControlsContainerHeightFirstValue = true;
                        ControlsContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ControlsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setControlsContainerWidthFirstValue = true;
                        ControlsContainerWidthFirstValue = 256f;
                        if (interpolationValue < 1)
                        {
                            this.ControlsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setControlsContainerXFirstValue = true;
                        ControlsContainerXFirstValue = 482f;
                        setControlsContainerYFirstValue = true;
                        ControlsContainerYFirstValue = 12f;
                        if (interpolationValue < 1)
                        {
                            this.DividerHorizontalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setDividerHorizontalInstanceWidthFirstValue = true;
                        DividerHorizontalInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerHorizontalInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerHorizontalInstanceYFirstValue = true;
                        DividerHorizontalInstanceYFirstValue = 4f;
                        setDividerVerticalInstanceHeightFirstValue = true;
                        DividerVerticalInstanceHeightFirstValue = 24f;
                        if (interpolationValue < 1)
                        {
                            this.DividerVerticalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setDividerVerticalInstanceYFirstValue = true;
                        DividerVerticalInstanceYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.ElementsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setElementsContainerHeightFirstValue = true;
                        ElementsContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ElementsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setElementsContainerXFirstValue = true;
                        ElementsContainerXFirstValue = 310f;
                        setElementsContainerYFirstValue = true;
                        ElementsContainerYFirstValue = 14f;
                        if (interpolationValue < 1)
                        {
                            this.IconInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setListBoxInstanceHeightFirstValue = true;
                        ListBoxInstanceHeightFirstValue = 96f;
                        if (interpolationValue < 1)
                        {
                            this.ListBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setListBoxInstanceWidthFirstValue = true;
                        ListBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ListBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setListBoxInstanceYFirstValue = true;
                        ListBoxInstanceYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.NineSliceStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setNineSliceStyleContainerHeightFirstValue = true;
                        NineSliceStyleContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.NineSliceStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setNineSliceStyleContainerWidthFirstValue = true;
                        NineSliceStyleContainerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.NineSliceStyleContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setNineSliceStyleContainerXFirstValue = true;
                        NineSliceStyleContainerXFirstValue = 9f;
                        setNineSliceStyleContainerYFirstValue = true;
                        NineSliceStyleContainerYFirstValue = 14f;
                        setOutlinedCurrentColorCategoryStateFirstValue = true;
                        OutlinedCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setOutlinedHeightFirstValue = true;
                        OutlinedHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Outlined.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Outlined.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setOutlinedCurrentStyleCategoryStateFirstValue = true;
                        OutlinedCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Outlined;
                        setOutlinedWidthFirstValue = true;
                        OutlinedWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Outlined.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Outlined.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Outlined.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedYFirstValue = true;
                        OutlinedYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.Outlined.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Outlined.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedHeavyCurrentColorCategoryStateFirstValue = true;
                        OutlinedHeavyCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setOutlinedHeavyHeightFirstValue = true;
                        OutlinedHeavyHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setOutlinedHeavyCurrentStyleCategoryStateFirstValue = true;
                        OutlinedHeavyCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.OutlinedHeavy;
                        setOutlinedHeavyWidthFirstValue = true;
                        OutlinedHeavyWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedHeavyYFirstValue = true;
                        OutlinedHeavyYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.OutlinedHeavy.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setPanelCurrentColorCategoryStateFirstValue = true;
                        PanelCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setPanelHeightFirstValue = true;
                        PanelHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Panel.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Panel.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setPanelCurrentStyleCategoryStateFirstValue = true;
                        PanelCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setPanelWidthFirstValue = true;
                        PanelWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Panel.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Panel.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Panel.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setPanelYFirstValue = true;
                        PanelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.Panel.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Panel.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PasswordBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setPasswordBoxInstanceYFirstValue = true;
                        PasswordBoxInstanceYFirstValue = 4f;
                        setPercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarCautionDecorWidthFirstValue = true;
                        PercentBarCautionDecorWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarCautionDecorYFirstValue = true;
                        PercentBarCautionDecorYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconCautionDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconCautionDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconCautionDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconCautionDecorWidthFirstValue = true;
                        PercentBarIconCautionDecorWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconCautionDecorYFirstValue = true;
                        PercentBarIconCautionDecorYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconLinesDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconLinesDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconLinesDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconLinesDecorWidthFirstValue = true;
                        PercentBarIconLinesDecorWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconLinesDecorYFirstValue = true;
                        PercentBarIconLinesDecorYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconPrimary.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconPrimary.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconPrimary.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconPrimaryWidthFirstValue = true;
                        PercentBarIconPrimaryWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarIconPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconPrimaryYFirstValue = true;
                        PercentBarIconPrimaryYFirstValue = 4f;
                        setPercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue = true;
                        PercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarLinesDecorWidthFirstValue = true;
                        PercentBarLinesDecorWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarLinesDecorYFirstValue = true;
                        PercentBarLinesDecorYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarPrimaryWidthFirstValue = true;
                        PercentBarPrimaryWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setRadioButtonInstanceWidthFirstValue = true;
                        RadioButtonInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstanceYFirstValue = true;
                        RadioButtonInstanceYFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.SliderInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setSliderInstanceWidthFirstValue = true;
                        SliderInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.SliderInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setSliderInstanceYFirstValue = true;
                        SliderInstanceYFirstValue = 4f;
                        setSolidCurrentColorCategoryStateFirstValue = true;
                        SolidCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setSolidHeightFirstValue = true;
                        SolidHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Solid.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Solid.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setSolidCurrentStyleCategoryStateFirstValue = true;
                        SolidCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        setSolidWidthFirstValue = true;
                        SolidWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Solid.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Solid.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Solid.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Solid.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Solid.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabCurrentColorCategoryStateFirstValue = true;
                        TabCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setTabHeightFirstValue = true;
                        TabHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Tab.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setTabCurrentStyleCategoryStateFirstValue = true;
                        TabCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Tab;
                        setTabWidthFirstValue = true;
                        TabWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.Tab.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabYFirstValue = true;
                        TabYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.Tab.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Tab.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabBorderedCurrentColorCategoryStateFirstValue = true;
                        TabBorderedCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setTabBorderedHeightFirstValue = true;
                        TabBorderedHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setTabBorderedCurrentStyleCategoryStateFirstValue = true;
                        TabBorderedCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                        setTabBorderedWidthFirstValue = true;
                        TabBorderedWidthFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabBorderedYFirstValue = true;
                        TabBorderedYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TabBordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTextAccentCurrentColorCategoryStateFirstValue = true;
                        TextAccentCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Accent;
                        if (interpolationValue < 1)
                        {
                            this.TextAccent.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextAccentCurrentStyleCategoryStateFirstValue = true;
                        TextAccentCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextAccent.Text = "Accent";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextAccent.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextBlackCurrentColorCategoryStateFirstValue = true;
                        TextBlackCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                        if (interpolationValue < 1)
                        {
                            this.TextBlack.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextBlackCurrentStyleCategoryStateFirstValue = true;
                        TextBlackCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextBlack.Text = "Black";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextBlack.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setTextBoxInstanceYFirstValue = true;
                        TextBoxInstanceYFirstValue = 4f;
                        setTextDarkGrayCurrentColorCategoryStateFirstValue = true;
                        TextDarkGrayCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.DarkGray;
                        if (interpolationValue < 1)
                        {
                            this.TextDarkGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextDarkGrayCurrentStyleCategoryStateFirstValue = true;
                        TextDarkGrayCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextDarkGray.Text = "Dark Gray";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextDarkGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextEmphasisCurrentColorCategoryStateFirstValue = true;
                        TextEmphasisCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextEmphasis.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextEmphasisCurrentStyleCategoryStateFirstValue = true;
                        TextEmphasisCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Emphasis;
                        if (interpolationValue < 1)
                        {
                            this.TextEmphasis.Text = "Emphasis";
                        }
                        setTextGrayCurrentColorCategoryStateFirstValue = true;
                        TextGrayCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        if (interpolationValue < 1)
                        {
                            this.TextGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextGrayCurrentStyleCategoryStateFirstValue = true;
                        TextGrayCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextGray.Text = "Gray";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextH1CurrentColorCategoryStateFirstValue = true;
                        TextH1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextH1.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH1CurrentStyleCategoryStateFirstValue = true;
                        TextH1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H1;
                        if (interpolationValue < 1)
                        {
                            this.TextH1.Text = "Heading 1";
                        }
                        setTextH2CurrentColorCategoryStateFirstValue = true;
                        TextH2CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextH2.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH2CurrentStyleCategoryStateFirstValue = true;
                        TextH2CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H2;
                        if (interpolationValue < 1)
                        {
                            this.TextH2.Text = "Heading 2";
                        }
                        setTextH3CurrentColorCategoryStateFirstValue = true;
                        TextH3CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextH3.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH3CurrentStyleCategoryStateFirstValue = true;
                        TextH3CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H3;
                        if (interpolationValue < 1)
                        {
                            this.TextH3.Text = "Heading 3";
                        }
                        setTextLightGrayCurrentColorCategoryStateFirstValue = true;
                        TextLightGrayCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.LightGray;
                        if (interpolationValue < 1)
                        {
                            this.TextLightGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextLightGrayCurrentStyleCategoryStateFirstValue = true;
                        TextLightGrayCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextLightGray.Text = "Light Gray";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextLightGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextNormalCurrentColorCategoryStateFirstValue = true;
                        TextNormalCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextNormal.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextNormalCurrentStyleCategoryStateFirstValue = true;
                        TextNormalCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextNormal.Text = "Normal";
                        }
                        setTextPrimaryCurrentColorCategoryStateFirstValue = true;
                        TextPrimaryCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimary.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryCurrentStyleCategoryStateFirstValue = true;
                        TextPrimaryCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimary.Text = "Primary";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextPrimaryDarkCurrentColorCategoryStateFirstValue = true;
                        TextPrimaryDarkCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryDark;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryDark.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryDarkCurrentStyleCategoryStateFirstValue = true;
                        TextPrimaryDarkCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryDark.Text = "Primary Dark";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryDark.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextPrimaryLightCurrentColorCategoryStateFirstValue = true;
                        TextPrimaryLightCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryLight.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryLightCurrentStyleCategoryStateFirstValue = true;
                        TextPrimaryLightCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryLight.Text = "Primary Light";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextPrimaryLight.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextSmallCurrentColorCategoryStateFirstValue = true;
                        TextSmallCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextSmall.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextSmallCurrentStyleCategoryStateFirstValue = true;
                        TextSmallCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Small;
                        if (interpolationValue < 1)
                        {
                            this.TextSmall.Text = "Small";
                        }
                        setTextStrongCurrentColorCategoryStateFirstValue = true;
                        TextStrongCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextStrong.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextStrongCurrentStyleCategoryStateFirstValue = true;
                        TextStrongCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Strong;
                        if (interpolationValue < 1)
                        {
                            this.TextStrong.Text = "Strong";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setTextStyleContainerHeightFirstValue = true;
                        TextStyleContainerHeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextStyleContainerWidthFirstValue = true;
                        TextStyleContainerWidthFirstValue = 85f;
                        setTextStyleContainerXFirstValue = true;
                        TextStyleContainerXFirstValue = 57f;
                        setTextStyleContainerYFirstValue = true;
                        TextStyleContainerYFirstValue = 11f;
                        setTextSuccessCurrentColorCategoryStateFirstValue = true;
                        TextSuccessCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Success;
                        if (interpolationValue < 1)
                        {
                            this.TextSuccess.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextSuccessCurrentStyleCategoryStateFirstValue = true;
                        TextSuccessCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextSuccess.Text = "Success";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextSuccess.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextTinyCurrentColorCategoryStateFirstValue = true;
                        TextTinyCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextTiny.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextTinyCurrentStyleCategoryStateFirstValue = true;
                        TextTinyCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                        if (interpolationValue < 1)
                        {
                            this.TextTiny.Text = "Tiny";
                        }
                        setTextTitleCurrentColorCategoryStateFirstValue = true;
                        TextTitleCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextTitle.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextTitleCurrentStyleCategoryStateFirstValue = true;
                        TextTitleCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TextTitle.Text = "H2";
                        }
                        setTextWarningCurrentColorCategoryStateFirstValue = true;
                        TextWarningCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Warning;
                        if (interpolationValue < 1)
                        {
                            this.TextWarning.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWarningCurrentStyleCategoryStateFirstValue = true;
                        TextWarningCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextWarning.Text = "Warning";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextWarning.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextWarning1CurrentColorCategoryStateFirstValue = true;
                        TextWarning1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Danger;
                        if (interpolationValue < 1)
                        {
                            this.TextWarning1.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWarning1CurrentStyleCategoryStateFirstValue = true;
                        TextWarning1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextWarning1.Text = "Danger";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextWarning1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextWhiteCurrentColorCategoryStateFirstValue = true;
                        TextWhiteCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue < 1)
                        {
                            this.TextWhite.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWhiteCurrentStyleCategoryStateFirstValue = true;
                        TextWhiteCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue < 1)
                        {
                            this.TextWhite.Text = "White";
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextWhite.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.VerticalLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue < 1)
                        {
                            this.VerticalLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setVerticalLinesInstanceWidthFirstValue = true;
                        VerticalLinesInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.VerticalLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setVerticalLinesInstanceYFirstValue = true;
                        VerticalLinesInstanceYFirstValue = 4f;
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        setBorderedCurrentColorCategoryStateSecondValue = true;
                        BorderedCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBorderedHeightSecondValue = true;
                        BorderedHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBorderedCurrentStyleCategoryStateSecondValue = true;
                        BorderedCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Bordered;
                        setBorderedWidthSecondValue = true;
                        BorderedWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBorderedYSecondValue = true;
                        BorderedYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Bordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketHorizontalCurrentColorCategoryStateSecondValue = true;
                        BracketHorizontalCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBracketHorizontalHeightSecondValue = true;
                        BracketHorizontalHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBracketHorizontalCurrentStyleCategoryStateSecondValue = true;
                        BracketHorizontalCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketHorizontal;
                        setBracketHorizontalWidthSecondValue = true;
                        BracketHorizontalWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketHorizontalYSecondValue = true;
                        BracketHorizontalYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketHorizontal.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketVerticalCurrentColorCategoryStateSecondValue = true;
                        BracketVerticalCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBracketVerticalHeightSecondValue = true;
                        BracketVerticalHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setBracketVerticalCurrentStyleCategoryStateSecondValue = true;
                        BracketVerticalCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.BracketVertical;
                        setBracketVerticalWidthSecondValue = true;
                        BracketVerticalWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setBracketVerticalYSecondValue = true;
                        BracketVerticalYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.BracketVertical.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonCloseInstanceYSecondValue = true;
                        ButtonCloseInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.ButtonDisplayText = "Confirm";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonConfirmInstanceYSecondValue = true;
                        ButtonConfirmInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonDenyInstance.ButtonDisplayText = "Deny";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonDenyInstanceYSecondValue = true;
                        ButtonDenyInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonIconInstanceYSecondValue = true;
                        ButtonIconInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setButtonsContainerHeightSecondValue = true;
                        ButtonsContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setButtonsContainerWidthSecondValue = true;
                        ButtonsContainerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setButtonsContainerXSecondValue = true;
                        ButtonsContainerXSecondValue = 159f;
                        setButtonsContainerYSecondValue = true;
                        ButtonsContainerYSecondValue = 12f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonStandardIconInstance.ButtonDisplayText = "Standard Icon";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonStandardIconInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        setButtonStandardIconInstanceYSecondValue = true;
                        ButtonStandardIconInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonStandardInstance.ButtonDisplayText = "Standard";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonStandardInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonTabInstance.Parent = this.GetGraphicalUiElementByName("ButtonsContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonTabInstance.TabDisplayText = "Tab";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonTabInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonTabInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setButtonTabInstanceYSecondValue = true;
                        ButtonTabInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonTabInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CautionLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.CautionLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setCautionLinesInstanceWidthSecondValue = true;
                        CautionLinesInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.CautionLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setCautionLinesInstanceYSecondValue = true;
                        CautionLinesInstanceYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.CheckBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setCheckBoxInstanceWidthSecondValue = true;
                        CheckBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.CheckBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ColorContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setColorContainerHeightSecondValue = true;
                        ColorContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ColorContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setColorContainerXSecondValue = true;
                        ColorContainerXSecondValue = 774f;
                        setColorContainerYSecondValue = true;
                        ColorContainerYSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setComboBoxInstanceWidthSecondValue = true;
                        ComboBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setComboBoxInstanceYSecondValue = true;
                        ComboBoxInstanceYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.ControlsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setControlsContainerHeightSecondValue = true;
                        ControlsContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ControlsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setControlsContainerWidthSecondValue = true;
                        ControlsContainerWidthSecondValue = 256f;
                        if (interpolationValue >= 1)
                        {
                            this.ControlsContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setControlsContainerXSecondValue = true;
                        ControlsContainerXSecondValue = 482f;
                        setControlsContainerYSecondValue = true;
                        ControlsContainerYSecondValue = 12f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerHorizontalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setDividerHorizontalInstanceWidthSecondValue = true;
                        DividerHorizontalInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerHorizontalInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerHorizontalInstanceYSecondValue = true;
                        DividerHorizontalInstanceYSecondValue = 4f;
                        setDividerVerticalInstanceHeightSecondValue = true;
                        DividerVerticalInstanceHeightSecondValue = 24f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerVerticalInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setDividerVerticalInstanceYSecondValue = true;
                        DividerVerticalInstanceYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.ElementsContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setElementsContainerHeightSecondValue = true;
                        ElementsContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ElementsContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setElementsContainerXSecondValue = true;
                        ElementsContainerXSecondValue = 310f;
                        setElementsContainerYSecondValue = true;
                        ElementsContainerYSecondValue = 14f;
                        if (interpolationValue >= 1)
                        {
                            this.IconInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setListBoxInstanceHeightSecondValue = true;
                        ListBoxInstanceHeightSecondValue = 96f;
                        if (interpolationValue >= 1)
                        {
                            this.ListBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setListBoxInstanceWidthSecondValue = true;
                        ListBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ListBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setListBoxInstanceYSecondValue = true;
                        ListBoxInstanceYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.NineSliceStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setNineSliceStyleContainerHeightSecondValue = true;
                        NineSliceStyleContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.NineSliceStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setNineSliceStyleContainerWidthSecondValue = true;
                        NineSliceStyleContainerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.NineSliceStyleContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setNineSliceStyleContainerXSecondValue = true;
                        NineSliceStyleContainerXSecondValue = 9f;
                        setNineSliceStyleContainerYSecondValue = true;
                        NineSliceStyleContainerYSecondValue = 14f;
                        setOutlinedCurrentColorCategoryStateSecondValue = true;
                        OutlinedCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setOutlinedHeightSecondValue = true;
                        OutlinedHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setOutlinedCurrentStyleCategoryStateSecondValue = true;
                        OutlinedCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Outlined;
                        setOutlinedWidthSecondValue = true;
                        OutlinedWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedYSecondValue = true;
                        OutlinedYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Outlined.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedHeavyCurrentColorCategoryStateSecondValue = true;
                        OutlinedHeavyCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setOutlinedHeavyHeightSecondValue = true;
                        OutlinedHeavyHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setOutlinedHeavyCurrentStyleCategoryStateSecondValue = true;
                        OutlinedHeavyCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.OutlinedHeavy;
                        setOutlinedHeavyWidthSecondValue = true;
                        OutlinedHeavyWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setOutlinedHeavyYSecondValue = true;
                        OutlinedHeavyYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.OutlinedHeavy.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setPanelCurrentColorCategoryStateSecondValue = true;
                        PanelCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setPanelHeightSecondValue = true;
                        PanelHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Panel.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Panel.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setPanelCurrentStyleCategoryStateSecondValue = true;
                        PanelCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setPanelWidthSecondValue = true;
                        PanelWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Panel.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Panel.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Panel.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setPanelYSecondValue = true;
                        PanelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.Panel.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Panel.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PasswordBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setPasswordBoxInstanceYSecondValue = true;
                        PasswordBoxInstanceYSecondValue = 4f;
                        setPercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarCautionDecorWidthSecondValue = true;
                        PercentBarCautionDecorWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarCautionDecorYSecondValue = true;
                        PercentBarCautionDecorYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconCautionDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.CautionLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconCautionDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconCautionDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconCautionDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconCautionDecorWidthSecondValue = true;
                        PercentBarIconCautionDecorWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconCautionDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconCautionDecorYSecondValue = true;
                        PercentBarIconCautionDecorYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconLinesDecor.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconLinesDecor.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconLinesDecor.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconLinesDecorWidthSecondValue = true;
                        PercentBarIconLinesDecorWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconLinesDecorYSecondValue = true;
                        PercentBarIconLinesDecorYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconPrimary.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        }
                        setPercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarIconRuntime.BarDecorCategory.None;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconPrimary.BarIcon = NewGum.GumRuntimes.Elements.IconRuntime.IconCategory.Battery;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconPrimary.BarIconColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarIconPrimaryWidthSecondValue = true;
                        PercentBarIconPrimaryWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarIconPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarIconPrimaryYSecondValue = true;
                        PercentBarIconPrimaryYSecondValue = 4f;
                        setPercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue = true;
                        PercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue = NewGum.GumRuntimes.Elements.PercentBarRuntime.BarDecorCategory.VerticalLines;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarLinesDecor.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarLinesDecorWidthSecondValue = true;
                        PercentBarLinesDecorWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarLinesDecor.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarLinesDecorYSecondValue = true;
                        PercentBarLinesDecorYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarPrimary.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setPercentBarPrimaryWidthSecondValue = true;
                        PercentBarPrimaryWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setRadioButtonInstanceWidthSecondValue = true;
                        RadioButtonInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstanceYSecondValue = true;
                        RadioButtonInstanceYSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.SliderInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setSliderInstanceWidthSecondValue = true;
                        SliderInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.SliderInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setSliderInstanceYSecondValue = true;
                        SliderInstanceYSecondValue = 4f;
                        setSolidCurrentColorCategoryStateSecondValue = true;
                        SolidCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setSolidHeightSecondValue = true;
                        SolidHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Solid.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Solid.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setSolidCurrentStyleCategoryStateSecondValue = true;
                        SolidCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                        setSolidWidthSecondValue = true;
                        SolidWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Solid.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Solid.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Solid.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Solid.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Solid.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabCurrentColorCategoryStateSecondValue = true;
                        TabCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setTabHeightSecondValue = true;
                        TabHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Tab.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setTabCurrentStyleCategoryStateSecondValue = true;
                        TabCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Tab;
                        setTabWidthSecondValue = true;
                        TabWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.Tab.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabYSecondValue = true;
                        TabYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.Tab.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Tab.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabBorderedCurrentColorCategoryStateSecondValue = true;
                        TabBorderedCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setTabBorderedHeightSecondValue = true;
                        TabBorderedHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.Parent = this.GetGraphicalUiElementByName("NineSliceStyleContainer");
                        }
                        setTabBorderedCurrentStyleCategoryStateSecondValue = true;
                        TabBorderedCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.TabBordered;
                        setTabBorderedWidthSecondValue = true;
                        TabBorderedWidthSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Left;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.XUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTabBorderedYSecondValue = true;
                        TabBorderedYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Top;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TabBordered.YUnits = Gum.Converters.GeneralUnitType.PixelsFromSmall;
                        }
                        setTextAccentCurrentColorCategoryStateSecondValue = true;
                        TextAccentCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Accent;
                        if (interpolationValue >= 1)
                        {
                            this.TextAccent.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextAccentCurrentStyleCategoryStateSecondValue = true;
                        TextAccentCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextAccent.Text = "Accent";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextAccent.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextBlackCurrentColorCategoryStateSecondValue = true;
                        TextBlackCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                        if (interpolationValue >= 1)
                        {
                            this.TextBlack.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextBlackCurrentStyleCategoryStateSecondValue = true;
                        TextBlackCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextBlack.Text = "Black";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextBlack.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("ControlsContainer");
                        }
                        setTextBoxInstanceYSecondValue = true;
                        TextBoxInstanceYSecondValue = 4f;
                        setTextDarkGrayCurrentColorCategoryStateSecondValue = true;
                        TextDarkGrayCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.DarkGray;
                        if (interpolationValue >= 1)
                        {
                            this.TextDarkGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextDarkGrayCurrentStyleCategoryStateSecondValue = true;
                        TextDarkGrayCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextDarkGray.Text = "Dark Gray";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextDarkGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextEmphasisCurrentColorCategoryStateSecondValue = true;
                        TextEmphasisCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextEmphasis.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextEmphasisCurrentStyleCategoryStateSecondValue = true;
                        TextEmphasisCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Emphasis;
                        if (interpolationValue >= 1)
                        {
                            this.TextEmphasis.Text = "Emphasis";
                        }
                        setTextGrayCurrentColorCategoryStateSecondValue = true;
                        TextGrayCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Gray;
                        if (interpolationValue >= 1)
                        {
                            this.TextGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextGrayCurrentStyleCategoryStateSecondValue = true;
                        TextGrayCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextGray.Text = "Gray";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextH1CurrentColorCategoryStateSecondValue = true;
                        TextH1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextH1.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH1CurrentStyleCategoryStateSecondValue = true;
                        TextH1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H1;
                        if (interpolationValue >= 1)
                        {
                            this.TextH1.Text = "Heading 1";
                        }
                        setTextH2CurrentColorCategoryStateSecondValue = true;
                        TextH2CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextH2.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH2CurrentStyleCategoryStateSecondValue = true;
                        TextH2CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H2;
                        if (interpolationValue >= 1)
                        {
                            this.TextH2.Text = "Heading 2";
                        }
                        setTextH3CurrentColorCategoryStateSecondValue = true;
                        TextH3CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextH3.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextH3CurrentStyleCategoryStateSecondValue = true;
                        TextH3CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.H3;
                        if (interpolationValue >= 1)
                        {
                            this.TextH3.Text = "Heading 3";
                        }
                        setTextLightGrayCurrentColorCategoryStateSecondValue = true;
                        TextLightGrayCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.LightGray;
                        if (interpolationValue >= 1)
                        {
                            this.TextLightGray.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextLightGrayCurrentStyleCategoryStateSecondValue = true;
                        TextLightGrayCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextLightGray.Text = "Light Gray";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextLightGray.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextNormalCurrentColorCategoryStateSecondValue = true;
                        TextNormalCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextNormal.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextNormalCurrentStyleCategoryStateSecondValue = true;
                        TextNormalCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextNormal.Text = "Normal";
                        }
                        setTextPrimaryCurrentColorCategoryStateSecondValue = true;
                        TextPrimaryCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimary.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryCurrentStyleCategoryStateSecondValue = true;
                        TextPrimaryCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimary.Text = "Primary";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimary.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextPrimaryDarkCurrentColorCategoryStateSecondValue = true;
                        TextPrimaryDarkCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryDark;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryDark.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryDarkCurrentStyleCategoryStateSecondValue = true;
                        TextPrimaryDarkCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryDark.Text = "Primary Dark";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryDark.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextPrimaryLightCurrentColorCategoryStateSecondValue = true;
                        TextPrimaryLightCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.PrimaryLight;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryLight.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextPrimaryLightCurrentStyleCategoryStateSecondValue = true;
                        TextPrimaryLightCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryLight.Text = "Primary Light";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextPrimaryLight.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextSmallCurrentColorCategoryStateSecondValue = true;
                        TextSmallCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextSmall.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextSmallCurrentStyleCategoryStateSecondValue = true;
                        TextSmallCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Small;
                        if (interpolationValue >= 1)
                        {
                            this.TextSmall.Text = "Small";
                        }
                        setTextStrongCurrentColorCategoryStateSecondValue = true;
                        TextStrongCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextStrong.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextStrongCurrentStyleCategoryStateSecondValue = true;
                        TextStrongCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Strong;
                        if (interpolationValue >= 1)
                        {
                            this.TextStrong.Text = "Strong";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextStyleContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setTextStyleContainerHeightSecondValue = true;
                        TextStyleContainerHeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextStyleContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        setTextStyleContainerWidthSecondValue = true;
                        TextStyleContainerWidthSecondValue = 85f;
                        setTextStyleContainerXSecondValue = true;
                        TextStyleContainerXSecondValue = 57f;
                        setTextStyleContainerYSecondValue = true;
                        TextStyleContainerYSecondValue = 11f;
                        setTextSuccessCurrentColorCategoryStateSecondValue = true;
                        TextSuccessCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Success;
                        if (interpolationValue >= 1)
                        {
                            this.TextSuccess.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextSuccessCurrentStyleCategoryStateSecondValue = true;
                        TextSuccessCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextSuccess.Text = "Success";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextSuccess.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextTinyCurrentColorCategoryStateSecondValue = true;
                        TextTinyCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextTiny.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextTinyCurrentStyleCategoryStateSecondValue = true;
                        TextTinyCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                        if (interpolationValue >= 1)
                        {
                            this.TextTiny.Text = "Tiny";
                        }
                        setTextTitleCurrentColorCategoryStateSecondValue = true;
                        TextTitleCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextTitle.Parent = this.GetGraphicalUiElementByName("TextStyleContainer");
                        }
                        setTextTitleCurrentStyleCategoryStateSecondValue = true;
                        TextTitleCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TextTitle.Text = "H2";
                        }
                        setTextWarningCurrentColorCategoryStateSecondValue = true;
                        TextWarningCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Warning;
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWarningCurrentStyleCategoryStateSecondValue = true;
                        TextWarningCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning.Text = "Warning";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextWarning1CurrentColorCategoryStateSecondValue = true;
                        TextWarning1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Danger;
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning1.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWarning1CurrentStyleCategoryStateSecondValue = true;
                        TextWarning1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning1.Text = "Danger";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextWarning1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTextWhiteCurrentColorCategoryStateSecondValue = true;
                        TextWhiteCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.White;
                        if (interpolationValue >= 1)
                        {
                            this.TextWhite.Parent = this.GetGraphicalUiElementByName("ColorContainer");
                        }
                        setTextWhiteCurrentStyleCategoryStateSecondValue = true;
                        TextWhiteCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Normal;
                        if (interpolationValue >= 1)
                        {
                            this.TextWhite.Text = "White";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextWhite.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.VerticalLinesInstance.LineColor = NewGum.GumRuntimes.SpriteRuntime.ColorCategory.Primary;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.VerticalLinesInstance.Parent = this.GetGraphicalUiElementByName("ElementsContainer");
                        }
                        setVerticalLinesInstanceWidthSecondValue = true;
                        VerticalLinesInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.VerticalLinesInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setVerticalLinesInstanceYSecondValue = true;
                        VerticalLinesInstanceYSecondValue = 4f;
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBorderedCurrentColorCategoryStateFirstValue && setBorderedCurrentColorCategoryStateSecondValue)
                {
                    Bordered.InterpolateBetween(BorderedCurrentColorCategoryStateFirstValue, BorderedCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBorderedHeightFirstValue && setBorderedHeightSecondValue)
                {
                    Bordered.Height = BorderedHeightFirstValue * (1 - interpolationValue) + BorderedHeightSecondValue * interpolationValue;
                }
                if (setBorderedCurrentStyleCategoryStateFirstValue && setBorderedCurrentStyleCategoryStateSecondValue)
                {
                    Bordered.InterpolateBetween(BorderedCurrentStyleCategoryStateFirstValue, BorderedCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBorderedWidthFirstValue && setBorderedWidthSecondValue)
                {
                    Bordered.Width = BorderedWidthFirstValue * (1 - interpolationValue) + BorderedWidthSecondValue * interpolationValue;
                }
                if (setBorderedYFirstValue && setBorderedYSecondValue)
                {
                    Bordered.Y = BorderedYFirstValue * (1 - interpolationValue) + BorderedYSecondValue * interpolationValue;
                }
                if (setBracketHorizontalCurrentColorCategoryStateFirstValue && setBracketHorizontalCurrentColorCategoryStateSecondValue)
                {
                    BracketHorizontal.InterpolateBetween(BracketHorizontalCurrentColorCategoryStateFirstValue, BracketHorizontalCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBracketHorizontalHeightFirstValue && setBracketHorizontalHeightSecondValue)
                {
                    BracketHorizontal.Height = BracketHorizontalHeightFirstValue * (1 - interpolationValue) + BracketHorizontalHeightSecondValue * interpolationValue;
                }
                if (setBracketHorizontalCurrentStyleCategoryStateFirstValue && setBracketHorizontalCurrentStyleCategoryStateSecondValue)
                {
                    BracketHorizontal.InterpolateBetween(BracketHorizontalCurrentStyleCategoryStateFirstValue, BracketHorizontalCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBracketHorizontalWidthFirstValue && setBracketHorizontalWidthSecondValue)
                {
                    BracketHorizontal.Width = BracketHorizontalWidthFirstValue * (1 - interpolationValue) + BracketHorizontalWidthSecondValue * interpolationValue;
                }
                if (setBracketHorizontalYFirstValue && setBracketHorizontalYSecondValue)
                {
                    BracketHorizontal.Y = BracketHorizontalYFirstValue * (1 - interpolationValue) + BracketHorizontalYSecondValue * interpolationValue;
                }
                if (setBracketVerticalCurrentColorCategoryStateFirstValue && setBracketVerticalCurrentColorCategoryStateSecondValue)
                {
                    BracketVertical.InterpolateBetween(BracketVerticalCurrentColorCategoryStateFirstValue, BracketVerticalCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBracketVerticalHeightFirstValue && setBracketVerticalHeightSecondValue)
                {
                    BracketVertical.Height = BracketVerticalHeightFirstValue * (1 - interpolationValue) + BracketVerticalHeightSecondValue * interpolationValue;
                }
                if (setBracketVerticalCurrentStyleCategoryStateFirstValue && setBracketVerticalCurrentStyleCategoryStateSecondValue)
                {
                    BracketVertical.InterpolateBetween(BracketVerticalCurrentStyleCategoryStateFirstValue, BracketVerticalCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBracketVerticalWidthFirstValue && setBracketVerticalWidthSecondValue)
                {
                    BracketVertical.Width = BracketVerticalWidthFirstValue * (1 - interpolationValue) + BracketVerticalWidthSecondValue * interpolationValue;
                }
                if (setBracketVerticalYFirstValue && setBracketVerticalYSecondValue)
                {
                    BracketVertical.Y = BracketVerticalYFirstValue * (1 - interpolationValue) + BracketVerticalYSecondValue * interpolationValue;
                }
                if (setButtonCloseInstanceYFirstValue && setButtonCloseInstanceYSecondValue)
                {
                    ButtonCloseInstance.Y = ButtonCloseInstanceYFirstValue * (1 - interpolationValue) + ButtonCloseInstanceYSecondValue * interpolationValue;
                }
                if (setButtonConfirmInstanceYFirstValue && setButtonConfirmInstanceYSecondValue)
                {
                    ButtonConfirmInstance.Y = ButtonConfirmInstanceYFirstValue * (1 - interpolationValue) + ButtonConfirmInstanceYSecondValue * interpolationValue;
                }
                if (setButtonDenyInstanceYFirstValue && setButtonDenyInstanceYSecondValue)
                {
                    ButtonDenyInstance.Y = ButtonDenyInstanceYFirstValue * (1 - interpolationValue) + ButtonDenyInstanceYSecondValue * interpolationValue;
                }
                if (setButtonIconInstanceYFirstValue && setButtonIconInstanceYSecondValue)
                {
                    ButtonIconInstance.Y = ButtonIconInstanceYFirstValue * (1 - interpolationValue) + ButtonIconInstanceYSecondValue * interpolationValue;
                }
                if (setButtonsContainerHeightFirstValue && setButtonsContainerHeightSecondValue)
                {
                    ButtonsContainer.Height = ButtonsContainerHeightFirstValue * (1 - interpolationValue) + ButtonsContainerHeightSecondValue * interpolationValue;
                }
                if (setButtonsContainerWidthFirstValue && setButtonsContainerWidthSecondValue)
                {
                    ButtonsContainer.Width = ButtonsContainerWidthFirstValue * (1 - interpolationValue) + ButtonsContainerWidthSecondValue * interpolationValue;
                }
                if (setButtonsContainerXFirstValue && setButtonsContainerXSecondValue)
                {
                    ButtonsContainer.X = ButtonsContainerXFirstValue * (1 - interpolationValue) + ButtonsContainerXSecondValue * interpolationValue;
                }
                if (setButtonsContainerYFirstValue && setButtonsContainerYSecondValue)
                {
                    ButtonsContainer.Y = ButtonsContainerYFirstValue * (1 - interpolationValue) + ButtonsContainerYSecondValue * interpolationValue;
                }
                if (setButtonStandardIconInstanceYFirstValue && setButtonStandardIconInstanceYSecondValue)
                {
                    ButtonStandardIconInstance.Y = ButtonStandardIconInstanceYFirstValue * (1 - interpolationValue) + ButtonStandardIconInstanceYSecondValue * interpolationValue;
                }
                if (setButtonTabInstanceYFirstValue && setButtonTabInstanceYSecondValue)
                {
                    ButtonTabInstance.Y = ButtonTabInstanceYFirstValue * (1 - interpolationValue) + ButtonTabInstanceYSecondValue * interpolationValue;
                }
                if (setCautionLinesInstanceWidthFirstValue && setCautionLinesInstanceWidthSecondValue)
                {
                    CautionLinesInstance.Width = CautionLinesInstanceWidthFirstValue * (1 - interpolationValue) + CautionLinesInstanceWidthSecondValue * interpolationValue;
                }
                if (setCautionLinesInstanceYFirstValue && setCautionLinesInstanceYSecondValue)
                {
                    CautionLinesInstance.Y = CautionLinesInstanceYFirstValue * (1 - interpolationValue) + CautionLinesInstanceYSecondValue * interpolationValue;
                }
                if (setCheckBoxInstanceWidthFirstValue && setCheckBoxInstanceWidthSecondValue)
                {
                    CheckBoxInstance.Width = CheckBoxInstanceWidthFirstValue * (1 - interpolationValue) + CheckBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setColorContainerHeightFirstValue && setColorContainerHeightSecondValue)
                {
                    ColorContainer.Height = ColorContainerHeightFirstValue * (1 - interpolationValue) + ColorContainerHeightSecondValue * interpolationValue;
                }
                if (setColorContainerXFirstValue && setColorContainerXSecondValue)
                {
                    ColorContainer.X = ColorContainerXFirstValue * (1 - interpolationValue) + ColorContainerXSecondValue * interpolationValue;
                }
                if (setColorContainerYFirstValue && setColorContainerYSecondValue)
                {
                    ColorContainer.Y = ColorContainerYFirstValue * (1 - interpolationValue) + ColorContainerYSecondValue * interpolationValue;
                }
                if (setComboBoxInstanceWidthFirstValue && setComboBoxInstanceWidthSecondValue)
                {
                    ComboBoxInstance.Width = ComboBoxInstanceWidthFirstValue * (1 - interpolationValue) + ComboBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setComboBoxInstanceYFirstValue && setComboBoxInstanceYSecondValue)
                {
                    ComboBoxInstance.Y = ComboBoxInstanceYFirstValue * (1 - interpolationValue) + ComboBoxInstanceYSecondValue * interpolationValue;
                }
                if (setControlsContainerHeightFirstValue && setControlsContainerHeightSecondValue)
                {
                    ControlsContainer.Height = ControlsContainerHeightFirstValue * (1 - interpolationValue) + ControlsContainerHeightSecondValue * interpolationValue;
                }
                if (setControlsContainerWidthFirstValue && setControlsContainerWidthSecondValue)
                {
                    ControlsContainer.Width = ControlsContainerWidthFirstValue * (1 - interpolationValue) + ControlsContainerWidthSecondValue * interpolationValue;
                }
                if (setControlsContainerXFirstValue && setControlsContainerXSecondValue)
                {
                    ControlsContainer.X = ControlsContainerXFirstValue * (1 - interpolationValue) + ControlsContainerXSecondValue * interpolationValue;
                }
                if (setControlsContainerYFirstValue && setControlsContainerYSecondValue)
                {
                    ControlsContainer.Y = ControlsContainerYFirstValue * (1 - interpolationValue) + ControlsContainerYSecondValue * interpolationValue;
                }
                if (setDividerHorizontalInstanceWidthFirstValue && setDividerHorizontalInstanceWidthSecondValue)
                {
                    DividerHorizontalInstance.Width = DividerHorizontalInstanceWidthFirstValue * (1 - interpolationValue) + DividerHorizontalInstanceWidthSecondValue * interpolationValue;
                }
                if (setDividerHorizontalInstanceYFirstValue && setDividerHorizontalInstanceYSecondValue)
                {
                    DividerHorizontalInstance.Y = DividerHorizontalInstanceYFirstValue * (1 - interpolationValue) + DividerHorizontalInstanceYSecondValue * interpolationValue;
                }
                if (setDividerVerticalInstanceHeightFirstValue && setDividerVerticalInstanceHeightSecondValue)
                {
                    DividerVerticalInstance.Height = DividerVerticalInstanceHeightFirstValue * (1 - interpolationValue) + DividerVerticalInstanceHeightSecondValue * interpolationValue;
                }
                if (setDividerVerticalInstanceYFirstValue && setDividerVerticalInstanceYSecondValue)
                {
                    DividerVerticalInstance.Y = DividerVerticalInstanceYFirstValue * (1 - interpolationValue) + DividerVerticalInstanceYSecondValue * interpolationValue;
                }
                if (setElementsContainerHeightFirstValue && setElementsContainerHeightSecondValue)
                {
                    ElementsContainer.Height = ElementsContainerHeightFirstValue * (1 - interpolationValue) + ElementsContainerHeightSecondValue * interpolationValue;
                }
                if (setElementsContainerXFirstValue && setElementsContainerXSecondValue)
                {
                    ElementsContainer.X = ElementsContainerXFirstValue * (1 - interpolationValue) + ElementsContainerXSecondValue * interpolationValue;
                }
                if (setElementsContainerYFirstValue && setElementsContainerYSecondValue)
                {
                    ElementsContainer.Y = ElementsContainerYFirstValue * (1 - interpolationValue) + ElementsContainerYSecondValue * interpolationValue;
                }
                if (setListBoxInstanceHeightFirstValue && setListBoxInstanceHeightSecondValue)
                {
                    ListBoxInstance.Height = ListBoxInstanceHeightFirstValue * (1 - interpolationValue) + ListBoxInstanceHeightSecondValue * interpolationValue;
                }
                if (setListBoxInstanceWidthFirstValue && setListBoxInstanceWidthSecondValue)
                {
                    ListBoxInstance.Width = ListBoxInstanceWidthFirstValue * (1 - interpolationValue) + ListBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setListBoxInstanceYFirstValue && setListBoxInstanceYSecondValue)
                {
                    ListBoxInstance.Y = ListBoxInstanceYFirstValue * (1 - interpolationValue) + ListBoxInstanceYSecondValue * interpolationValue;
                }
                if (setNineSliceStyleContainerHeightFirstValue && setNineSliceStyleContainerHeightSecondValue)
                {
                    NineSliceStyleContainer.Height = NineSliceStyleContainerHeightFirstValue * (1 - interpolationValue) + NineSliceStyleContainerHeightSecondValue * interpolationValue;
                }
                if (setNineSliceStyleContainerWidthFirstValue && setNineSliceStyleContainerWidthSecondValue)
                {
                    NineSliceStyleContainer.Width = NineSliceStyleContainerWidthFirstValue * (1 - interpolationValue) + NineSliceStyleContainerWidthSecondValue * interpolationValue;
                }
                if (setNineSliceStyleContainerXFirstValue && setNineSliceStyleContainerXSecondValue)
                {
                    NineSliceStyleContainer.X = NineSliceStyleContainerXFirstValue * (1 - interpolationValue) + NineSliceStyleContainerXSecondValue * interpolationValue;
                }
                if (setNineSliceStyleContainerYFirstValue && setNineSliceStyleContainerYSecondValue)
                {
                    NineSliceStyleContainer.Y = NineSliceStyleContainerYFirstValue * (1 - interpolationValue) + NineSliceStyleContainerYSecondValue * interpolationValue;
                }
                if (setOutlinedCurrentColorCategoryStateFirstValue && setOutlinedCurrentColorCategoryStateSecondValue)
                {
                    Outlined.InterpolateBetween(OutlinedCurrentColorCategoryStateFirstValue, OutlinedCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setOutlinedHeightFirstValue && setOutlinedHeightSecondValue)
                {
                    Outlined.Height = OutlinedHeightFirstValue * (1 - interpolationValue) + OutlinedHeightSecondValue * interpolationValue;
                }
                if (setOutlinedCurrentStyleCategoryStateFirstValue && setOutlinedCurrentStyleCategoryStateSecondValue)
                {
                    Outlined.InterpolateBetween(OutlinedCurrentStyleCategoryStateFirstValue, OutlinedCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setOutlinedWidthFirstValue && setOutlinedWidthSecondValue)
                {
                    Outlined.Width = OutlinedWidthFirstValue * (1 - interpolationValue) + OutlinedWidthSecondValue * interpolationValue;
                }
                if (setOutlinedYFirstValue && setOutlinedYSecondValue)
                {
                    Outlined.Y = OutlinedYFirstValue * (1 - interpolationValue) + OutlinedYSecondValue * interpolationValue;
                }
                if (setOutlinedHeavyCurrentColorCategoryStateFirstValue && setOutlinedHeavyCurrentColorCategoryStateSecondValue)
                {
                    OutlinedHeavy.InterpolateBetween(OutlinedHeavyCurrentColorCategoryStateFirstValue, OutlinedHeavyCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setOutlinedHeavyHeightFirstValue && setOutlinedHeavyHeightSecondValue)
                {
                    OutlinedHeavy.Height = OutlinedHeavyHeightFirstValue * (1 - interpolationValue) + OutlinedHeavyHeightSecondValue * interpolationValue;
                }
                if (setOutlinedHeavyCurrentStyleCategoryStateFirstValue && setOutlinedHeavyCurrentStyleCategoryStateSecondValue)
                {
                    OutlinedHeavy.InterpolateBetween(OutlinedHeavyCurrentStyleCategoryStateFirstValue, OutlinedHeavyCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setOutlinedHeavyWidthFirstValue && setOutlinedHeavyWidthSecondValue)
                {
                    OutlinedHeavy.Width = OutlinedHeavyWidthFirstValue * (1 - interpolationValue) + OutlinedHeavyWidthSecondValue * interpolationValue;
                }
                if (setOutlinedHeavyYFirstValue && setOutlinedHeavyYSecondValue)
                {
                    OutlinedHeavy.Y = OutlinedHeavyYFirstValue * (1 - interpolationValue) + OutlinedHeavyYSecondValue * interpolationValue;
                }
                if (setPanelCurrentColorCategoryStateFirstValue && setPanelCurrentColorCategoryStateSecondValue)
                {
                    Panel.InterpolateBetween(PanelCurrentColorCategoryStateFirstValue, PanelCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setPanelHeightFirstValue && setPanelHeightSecondValue)
                {
                    Panel.Height = PanelHeightFirstValue * (1 - interpolationValue) + PanelHeightSecondValue * interpolationValue;
                }
                if (setPanelCurrentStyleCategoryStateFirstValue && setPanelCurrentStyleCategoryStateSecondValue)
                {
                    Panel.InterpolateBetween(PanelCurrentStyleCategoryStateFirstValue, PanelCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setPanelWidthFirstValue && setPanelWidthSecondValue)
                {
                    Panel.Width = PanelWidthFirstValue * (1 - interpolationValue) + PanelWidthSecondValue * interpolationValue;
                }
                if (setPanelYFirstValue && setPanelYSecondValue)
                {
                    Panel.Y = PanelYFirstValue * (1 - interpolationValue) + PanelYSecondValue * interpolationValue;
                }
                if (setPasswordBoxInstanceYFirstValue && setPasswordBoxInstanceYSecondValue)
                {
                    PasswordBoxInstance.Y = PasswordBoxInstanceYFirstValue * (1 - interpolationValue) + PasswordBoxInstanceYSecondValue * interpolationValue;
                }
                if (setPercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue && setPercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarCautionDecor.InterpolateBetween(PercentBarCautionDecorCurrentBarDecorCategoryStateFirstValue, PercentBarCautionDecorCurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarCautionDecorWidthFirstValue && setPercentBarCautionDecorWidthSecondValue)
                {
                    PercentBarCautionDecor.Width = PercentBarCautionDecorWidthFirstValue * (1 - interpolationValue) + PercentBarCautionDecorWidthSecondValue * interpolationValue;
                }
                if (setPercentBarCautionDecorYFirstValue && setPercentBarCautionDecorYSecondValue)
                {
                    PercentBarCautionDecor.Y = PercentBarCautionDecorYFirstValue * (1 - interpolationValue) + PercentBarCautionDecorYSecondValue * interpolationValue;
                }
                if (setPercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue && setPercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarIconCautionDecor.InterpolateBetween(PercentBarIconCautionDecorCurrentBarDecorCategoryStateFirstValue, PercentBarIconCautionDecorCurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarIconCautionDecorWidthFirstValue && setPercentBarIconCautionDecorWidthSecondValue)
                {
                    PercentBarIconCautionDecor.Width = PercentBarIconCautionDecorWidthFirstValue * (1 - interpolationValue) + PercentBarIconCautionDecorWidthSecondValue * interpolationValue;
                }
                if (setPercentBarIconCautionDecorYFirstValue && setPercentBarIconCautionDecorYSecondValue)
                {
                    PercentBarIconCautionDecor.Y = PercentBarIconCautionDecorYFirstValue * (1 - interpolationValue) + PercentBarIconCautionDecorYSecondValue * interpolationValue;
                }
                if (setPercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue && setPercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarIconLinesDecor.InterpolateBetween(PercentBarIconLinesDecorCurrentBarDecorCategoryStateFirstValue, PercentBarIconLinesDecorCurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarIconLinesDecorWidthFirstValue && setPercentBarIconLinesDecorWidthSecondValue)
                {
                    PercentBarIconLinesDecor.Width = PercentBarIconLinesDecorWidthFirstValue * (1 - interpolationValue) + PercentBarIconLinesDecorWidthSecondValue * interpolationValue;
                }
                if (setPercentBarIconLinesDecorYFirstValue && setPercentBarIconLinesDecorYSecondValue)
                {
                    PercentBarIconLinesDecor.Y = PercentBarIconLinesDecorYFirstValue * (1 - interpolationValue) + PercentBarIconLinesDecorYSecondValue * interpolationValue;
                }
                if (setPercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue && setPercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarIconPrimary.InterpolateBetween(PercentBarIconPrimaryCurrentBarDecorCategoryStateFirstValue, PercentBarIconPrimaryCurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarIconPrimaryWidthFirstValue && setPercentBarIconPrimaryWidthSecondValue)
                {
                    PercentBarIconPrimary.Width = PercentBarIconPrimaryWidthFirstValue * (1 - interpolationValue) + PercentBarIconPrimaryWidthSecondValue * interpolationValue;
                }
                if (setPercentBarIconPrimaryYFirstValue && setPercentBarIconPrimaryYSecondValue)
                {
                    PercentBarIconPrimary.Y = PercentBarIconPrimaryYFirstValue * (1 - interpolationValue) + PercentBarIconPrimaryYSecondValue * interpolationValue;
                }
                if (setPercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue && setPercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue)
                {
                    PercentBarLinesDecor.InterpolateBetween(PercentBarLinesDecorCurrentBarDecorCategoryStateFirstValue, PercentBarLinesDecorCurrentBarDecorCategoryStateSecondValue, interpolationValue);
                }
                if (setPercentBarLinesDecorWidthFirstValue && setPercentBarLinesDecorWidthSecondValue)
                {
                    PercentBarLinesDecor.Width = PercentBarLinesDecorWidthFirstValue * (1 - interpolationValue) + PercentBarLinesDecorWidthSecondValue * interpolationValue;
                }
                if (setPercentBarLinesDecorYFirstValue && setPercentBarLinesDecorYSecondValue)
                {
                    PercentBarLinesDecor.Y = PercentBarLinesDecorYFirstValue * (1 - interpolationValue) + PercentBarLinesDecorYSecondValue * interpolationValue;
                }
                if (setPercentBarPrimaryWidthFirstValue && setPercentBarPrimaryWidthSecondValue)
                {
                    PercentBarPrimary.Width = PercentBarPrimaryWidthFirstValue * (1 - interpolationValue) + PercentBarPrimaryWidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstanceWidthFirstValue && setRadioButtonInstanceWidthSecondValue)
                {
                    RadioButtonInstance.Width = RadioButtonInstanceWidthFirstValue * (1 - interpolationValue) + RadioButtonInstanceWidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstanceYFirstValue && setRadioButtonInstanceYSecondValue)
                {
                    RadioButtonInstance.Y = RadioButtonInstanceYFirstValue * (1 - interpolationValue) + RadioButtonInstanceYSecondValue * interpolationValue;
                }
                if (setSliderInstanceWidthFirstValue && setSliderInstanceWidthSecondValue)
                {
                    SliderInstance.Width = SliderInstanceWidthFirstValue * (1 - interpolationValue) + SliderInstanceWidthSecondValue * interpolationValue;
                }
                if (setSliderInstanceYFirstValue && setSliderInstanceYSecondValue)
                {
                    SliderInstance.Y = SliderInstanceYFirstValue * (1 - interpolationValue) + SliderInstanceYSecondValue * interpolationValue;
                }
                if (setSolidCurrentColorCategoryStateFirstValue && setSolidCurrentColorCategoryStateSecondValue)
                {
                    Solid.InterpolateBetween(SolidCurrentColorCategoryStateFirstValue, SolidCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setSolidHeightFirstValue && setSolidHeightSecondValue)
                {
                    Solid.Height = SolidHeightFirstValue * (1 - interpolationValue) + SolidHeightSecondValue * interpolationValue;
                }
                if (setSolidCurrentStyleCategoryStateFirstValue && setSolidCurrentStyleCategoryStateSecondValue)
                {
                    Solid.InterpolateBetween(SolidCurrentStyleCategoryStateFirstValue, SolidCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setSolidWidthFirstValue && setSolidWidthSecondValue)
                {
                    Solid.Width = SolidWidthFirstValue * (1 - interpolationValue) + SolidWidthSecondValue * interpolationValue;
                }
                if (setTabCurrentColorCategoryStateFirstValue && setTabCurrentColorCategoryStateSecondValue)
                {
                    Tab.InterpolateBetween(TabCurrentColorCategoryStateFirstValue, TabCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTabHeightFirstValue && setTabHeightSecondValue)
                {
                    Tab.Height = TabHeightFirstValue * (1 - interpolationValue) + TabHeightSecondValue * interpolationValue;
                }
                if (setTabCurrentStyleCategoryStateFirstValue && setTabCurrentStyleCategoryStateSecondValue)
                {
                    Tab.InterpolateBetween(TabCurrentStyleCategoryStateFirstValue, TabCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTabWidthFirstValue && setTabWidthSecondValue)
                {
                    Tab.Width = TabWidthFirstValue * (1 - interpolationValue) + TabWidthSecondValue * interpolationValue;
                }
                if (setTabYFirstValue && setTabYSecondValue)
                {
                    Tab.Y = TabYFirstValue * (1 - interpolationValue) + TabYSecondValue * interpolationValue;
                }
                if (setTabBorderedCurrentColorCategoryStateFirstValue && setTabBorderedCurrentColorCategoryStateSecondValue)
                {
                    TabBordered.InterpolateBetween(TabBorderedCurrentColorCategoryStateFirstValue, TabBorderedCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTabBorderedHeightFirstValue && setTabBorderedHeightSecondValue)
                {
                    TabBordered.Height = TabBorderedHeightFirstValue * (1 - interpolationValue) + TabBorderedHeightSecondValue * interpolationValue;
                }
                if (setTabBorderedCurrentStyleCategoryStateFirstValue && setTabBorderedCurrentStyleCategoryStateSecondValue)
                {
                    TabBordered.InterpolateBetween(TabBorderedCurrentStyleCategoryStateFirstValue, TabBorderedCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTabBorderedWidthFirstValue && setTabBorderedWidthSecondValue)
                {
                    TabBordered.Width = TabBorderedWidthFirstValue * (1 - interpolationValue) + TabBorderedWidthSecondValue * interpolationValue;
                }
                if (setTabBorderedYFirstValue && setTabBorderedYSecondValue)
                {
                    TabBordered.Y = TabBorderedYFirstValue * (1 - interpolationValue) + TabBorderedYSecondValue * interpolationValue;
                }
                if (setTextAccentCurrentColorCategoryStateFirstValue && setTextAccentCurrentColorCategoryStateSecondValue)
                {
                    TextAccent.InterpolateBetween(TextAccentCurrentColorCategoryStateFirstValue, TextAccentCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextAccentCurrentStyleCategoryStateFirstValue && setTextAccentCurrentStyleCategoryStateSecondValue)
                {
                    TextAccent.InterpolateBetween(TextAccentCurrentStyleCategoryStateFirstValue, TextAccentCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextBlackCurrentColorCategoryStateFirstValue && setTextBlackCurrentColorCategoryStateSecondValue)
                {
                    TextBlack.InterpolateBetween(TextBlackCurrentColorCategoryStateFirstValue, TextBlackCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextBlackCurrentStyleCategoryStateFirstValue && setTextBlackCurrentStyleCategoryStateSecondValue)
                {
                    TextBlack.InterpolateBetween(TextBlackCurrentStyleCategoryStateFirstValue, TextBlackCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextBoxInstanceYFirstValue && setTextBoxInstanceYSecondValue)
                {
                    TextBoxInstance.Y = TextBoxInstanceYFirstValue * (1 - interpolationValue) + TextBoxInstanceYSecondValue * interpolationValue;
                }
                if (setTextDarkGrayCurrentColorCategoryStateFirstValue && setTextDarkGrayCurrentColorCategoryStateSecondValue)
                {
                    TextDarkGray.InterpolateBetween(TextDarkGrayCurrentColorCategoryStateFirstValue, TextDarkGrayCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextDarkGrayCurrentStyleCategoryStateFirstValue && setTextDarkGrayCurrentStyleCategoryStateSecondValue)
                {
                    TextDarkGray.InterpolateBetween(TextDarkGrayCurrentStyleCategoryStateFirstValue, TextDarkGrayCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextEmphasisCurrentColorCategoryStateFirstValue && setTextEmphasisCurrentColorCategoryStateSecondValue)
                {
                    TextEmphasis.InterpolateBetween(TextEmphasisCurrentColorCategoryStateFirstValue, TextEmphasisCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextEmphasisCurrentStyleCategoryStateFirstValue && setTextEmphasisCurrentStyleCategoryStateSecondValue)
                {
                    TextEmphasis.InterpolateBetween(TextEmphasisCurrentStyleCategoryStateFirstValue, TextEmphasisCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextGrayCurrentColorCategoryStateFirstValue && setTextGrayCurrentColorCategoryStateSecondValue)
                {
                    TextGray.InterpolateBetween(TextGrayCurrentColorCategoryStateFirstValue, TextGrayCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextGrayCurrentStyleCategoryStateFirstValue && setTextGrayCurrentStyleCategoryStateSecondValue)
                {
                    TextGray.InterpolateBetween(TextGrayCurrentStyleCategoryStateFirstValue, TextGrayCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH1CurrentColorCategoryStateFirstValue && setTextH1CurrentColorCategoryStateSecondValue)
                {
                    TextH1.InterpolateBetween(TextH1CurrentColorCategoryStateFirstValue, TextH1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH1CurrentStyleCategoryStateFirstValue && setTextH1CurrentStyleCategoryStateSecondValue)
                {
                    TextH1.InterpolateBetween(TextH1CurrentStyleCategoryStateFirstValue, TextH1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH2CurrentColorCategoryStateFirstValue && setTextH2CurrentColorCategoryStateSecondValue)
                {
                    TextH2.InterpolateBetween(TextH2CurrentColorCategoryStateFirstValue, TextH2CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH2CurrentStyleCategoryStateFirstValue && setTextH2CurrentStyleCategoryStateSecondValue)
                {
                    TextH2.InterpolateBetween(TextH2CurrentStyleCategoryStateFirstValue, TextH2CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH3CurrentColorCategoryStateFirstValue && setTextH3CurrentColorCategoryStateSecondValue)
                {
                    TextH3.InterpolateBetween(TextH3CurrentColorCategoryStateFirstValue, TextH3CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextH3CurrentStyleCategoryStateFirstValue && setTextH3CurrentStyleCategoryStateSecondValue)
                {
                    TextH3.InterpolateBetween(TextH3CurrentStyleCategoryStateFirstValue, TextH3CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextLightGrayCurrentColorCategoryStateFirstValue && setTextLightGrayCurrentColorCategoryStateSecondValue)
                {
                    TextLightGray.InterpolateBetween(TextLightGrayCurrentColorCategoryStateFirstValue, TextLightGrayCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextLightGrayCurrentStyleCategoryStateFirstValue && setTextLightGrayCurrentStyleCategoryStateSecondValue)
                {
                    TextLightGray.InterpolateBetween(TextLightGrayCurrentStyleCategoryStateFirstValue, TextLightGrayCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextNormalCurrentColorCategoryStateFirstValue && setTextNormalCurrentColorCategoryStateSecondValue)
                {
                    TextNormal.InterpolateBetween(TextNormalCurrentColorCategoryStateFirstValue, TextNormalCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextNormalCurrentStyleCategoryStateFirstValue && setTextNormalCurrentStyleCategoryStateSecondValue)
                {
                    TextNormal.InterpolateBetween(TextNormalCurrentStyleCategoryStateFirstValue, TextNormalCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryCurrentColorCategoryStateFirstValue && setTextPrimaryCurrentColorCategoryStateSecondValue)
                {
                    TextPrimary.InterpolateBetween(TextPrimaryCurrentColorCategoryStateFirstValue, TextPrimaryCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryCurrentStyleCategoryStateFirstValue && setTextPrimaryCurrentStyleCategoryStateSecondValue)
                {
                    TextPrimary.InterpolateBetween(TextPrimaryCurrentStyleCategoryStateFirstValue, TextPrimaryCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryDarkCurrentColorCategoryStateFirstValue && setTextPrimaryDarkCurrentColorCategoryStateSecondValue)
                {
                    TextPrimaryDark.InterpolateBetween(TextPrimaryDarkCurrentColorCategoryStateFirstValue, TextPrimaryDarkCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryDarkCurrentStyleCategoryStateFirstValue && setTextPrimaryDarkCurrentStyleCategoryStateSecondValue)
                {
                    TextPrimaryDark.InterpolateBetween(TextPrimaryDarkCurrentStyleCategoryStateFirstValue, TextPrimaryDarkCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryLightCurrentColorCategoryStateFirstValue && setTextPrimaryLightCurrentColorCategoryStateSecondValue)
                {
                    TextPrimaryLight.InterpolateBetween(TextPrimaryLightCurrentColorCategoryStateFirstValue, TextPrimaryLightCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextPrimaryLightCurrentStyleCategoryStateFirstValue && setTextPrimaryLightCurrentStyleCategoryStateSecondValue)
                {
                    TextPrimaryLight.InterpolateBetween(TextPrimaryLightCurrentStyleCategoryStateFirstValue, TextPrimaryLightCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextSmallCurrentColorCategoryStateFirstValue && setTextSmallCurrentColorCategoryStateSecondValue)
                {
                    TextSmall.InterpolateBetween(TextSmallCurrentColorCategoryStateFirstValue, TextSmallCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextSmallCurrentStyleCategoryStateFirstValue && setTextSmallCurrentStyleCategoryStateSecondValue)
                {
                    TextSmall.InterpolateBetween(TextSmallCurrentStyleCategoryStateFirstValue, TextSmallCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextStrongCurrentColorCategoryStateFirstValue && setTextStrongCurrentColorCategoryStateSecondValue)
                {
                    TextStrong.InterpolateBetween(TextStrongCurrentColorCategoryStateFirstValue, TextStrongCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextStrongCurrentStyleCategoryStateFirstValue && setTextStrongCurrentStyleCategoryStateSecondValue)
                {
                    TextStrong.InterpolateBetween(TextStrongCurrentStyleCategoryStateFirstValue, TextStrongCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextStyleContainerHeightFirstValue && setTextStyleContainerHeightSecondValue)
                {
                    TextStyleContainer.Height = TextStyleContainerHeightFirstValue * (1 - interpolationValue) + TextStyleContainerHeightSecondValue * interpolationValue;
                }
                if (setTextStyleContainerWidthFirstValue && setTextStyleContainerWidthSecondValue)
                {
                    TextStyleContainer.Width = TextStyleContainerWidthFirstValue * (1 - interpolationValue) + TextStyleContainerWidthSecondValue * interpolationValue;
                }
                if (setTextStyleContainerXFirstValue && setTextStyleContainerXSecondValue)
                {
                    TextStyleContainer.X = TextStyleContainerXFirstValue * (1 - interpolationValue) + TextStyleContainerXSecondValue * interpolationValue;
                }
                if (setTextStyleContainerYFirstValue && setTextStyleContainerYSecondValue)
                {
                    TextStyleContainer.Y = TextStyleContainerYFirstValue * (1 - interpolationValue) + TextStyleContainerYSecondValue * interpolationValue;
                }
                if (setTextSuccessCurrentColorCategoryStateFirstValue && setTextSuccessCurrentColorCategoryStateSecondValue)
                {
                    TextSuccess.InterpolateBetween(TextSuccessCurrentColorCategoryStateFirstValue, TextSuccessCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextSuccessCurrentStyleCategoryStateFirstValue && setTextSuccessCurrentStyleCategoryStateSecondValue)
                {
                    TextSuccess.InterpolateBetween(TextSuccessCurrentStyleCategoryStateFirstValue, TextSuccessCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextTinyCurrentColorCategoryStateFirstValue && setTextTinyCurrentColorCategoryStateSecondValue)
                {
                    TextTiny.InterpolateBetween(TextTinyCurrentColorCategoryStateFirstValue, TextTinyCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextTinyCurrentStyleCategoryStateFirstValue && setTextTinyCurrentStyleCategoryStateSecondValue)
                {
                    TextTiny.InterpolateBetween(TextTinyCurrentStyleCategoryStateFirstValue, TextTinyCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextTitleCurrentColorCategoryStateFirstValue && setTextTitleCurrentColorCategoryStateSecondValue)
                {
                    TextTitle.InterpolateBetween(TextTitleCurrentColorCategoryStateFirstValue, TextTitleCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextTitleCurrentStyleCategoryStateFirstValue && setTextTitleCurrentStyleCategoryStateSecondValue)
                {
                    TextTitle.InterpolateBetween(TextTitleCurrentStyleCategoryStateFirstValue, TextTitleCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWarningCurrentColorCategoryStateFirstValue && setTextWarningCurrentColorCategoryStateSecondValue)
                {
                    TextWarning.InterpolateBetween(TextWarningCurrentColorCategoryStateFirstValue, TextWarningCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWarningCurrentStyleCategoryStateFirstValue && setTextWarningCurrentStyleCategoryStateSecondValue)
                {
                    TextWarning.InterpolateBetween(TextWarningCurrentStyleCategoryStateFirstValue, TextWarningCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWarning1CurrentColorCategoryStateFirstValue && setTextWarning1CurrentColorCategoryStateSecondValue)
                {
                    TextWarning1.InterpolateBetween(TextWarning1CurrentColorCategoryStateFirstValue, TextWarning1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWarning1CurrentStyleCategoryStateFirstValue && setTextWarning1CurrentStyleCategoryStateSecondValue)
                {
                    TextWarning1.InterpolateBetween(TextWarning1CurrentStyleCategoryStateFirstValue, TextWarning1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWhiteCurrentColorCategoryStateFirstValue && setTextWhiteCurrentColorCategoryStateSecondValue)
                {
                    TextWhite.InterpolateBetween(TextWhiteCurrentColorCategoryStateFirstValue, TextWhiteCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTextWhiteCurrentStyleCategoryStateFirstValue && setTextWhiteCurrentStyleCategoryStateSecondValue)
                {
                    TextWhite.InterpolateBetween(TextWhiteCurrentStyleCategoryStateFirstValue, TextWhiteCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setVerticalLinesInstanceWidthFirstValue && setVerticalLinesInstanceWidthSecondValue)
                {
                    VerticalLinesInstance.Width = VerticalLinesInstanceWidthFirstValue * (1 - interpolationValue) + VerticalLinesInstanceWidthSecondValue * interpolationValue;
                }
                if (setVerticalLinesInstanceYFirstValue && setVerticalLinesInstanceYSecondValue)
                {
                    VerticalLinesInstance.Y = VerticalLinesInstanceYFirstValue * (1 - interpolationValue) + VerticalLinesInstanceYSecondValue * interpolationValue;
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.StylesScreenRuntime.VariableState fromState,NewGum.GumRuntimes.StylesScreenRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
                ButtonStandardInstance.StopAnimations();
                ButtonStandardIconInstance.StopAnimations();
                ButtonTabInstance.StopAnimations();
                ButtonIconInstance.StopAnimations();
                ButtonConfirmInstance.StopAnimations();
                ButtonDenyInstance.StopAnimations();
                ButtonCloseInstance.StopAnimations();
                PercentBarPrimary.StopAnimations();
                PercentBarLinesDecor.StopAnimations();
                PercentBarCautionDecor.StopAnimations();
                PercentBarIconPrimary.StopAnimations();
                PercentBarIconLinesDecor.StopAnimations();
                PercentBarIconCautionDecor.StopAnimations();
                LabelInstance.StopAnimations();
                CheckBoxInstance.StopAnimations();
                RadioButtonInstance.StopAnimations();
                ComboBoxInstance.StopAnimations();
                ListBoxInstance.StopAnimations();
                SliderInstance.StopAnimations();
                TextBoxInstance.StopAnimations();
                PasswordBoxInstance.StopAnimations();
                DividerVerticalInstance.StopAnimations();
                DividerHorizontalInstance.StopAnimations();
                IconInstance.StopAnimations();
                CautionLinesInstance.StopAnimations();
                VerticalLinesInstance.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = TextStyleContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Height",
                            Type = "float",
                            Value = TextStyleContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextStyleContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Width",
                            Type = "float",
                            Value = TextStyleContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.X",
                            Type = "float",
                            Value = TextStyleContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Y",
                            Type = "float",
                            Value = TextStyleContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextTitle.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.Parent",
                            Type = "string",
                            Value = TextTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextTitle.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.Text",
                            Type = "string",
                            Value = TextTitle.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.Parent",
                            Type = "string",
                            Value = TextH1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.Text",
                            Type = "string",
                            Value = TextH1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.Parent",
                            Type = "string",
                            Value = TextH2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.Text",
                            Type = "string",
                            Value = TextH2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH3.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.Parent",
                            Type = "string",
                            Value = TextH3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH3.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.Text",
                            Type = "string",
                            Value = TextH3.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextNormal.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.Parent",
                            Type = "string",
                            Value = TextNormal.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextNormal.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.Text",
                            Type = "string",
                            Value = TextNormal.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextStrong.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.Parent",
                            Type = "string",
                            Value = TextStrong.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextStrong.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.Text",
                            Type = "string",
                            Value = TextStrong.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextEmphasis.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.Parent",
                            Type = "string",
                            Value = TextEmphasis.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextEmphasis.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.Text",
                            Type = "string",
                            Value = TextEmphasis.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextSmall.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.Parent",
                            Type = "string",
                            Value = TextSmall.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextSmall.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.Text",
                            Type = "string",
                            Value = TextSmall.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextTiny.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.Parent",
                            Type = "string",
                            Value = TextTiny.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextTiny.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.Text",
                            Type = "string",
                            Value = TextTiny.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Solid.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Height",
                            Type = "float",
                            Value = Solid.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Height Units",
                            Type = "DimensionUnitType",
                            Value = Solid.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Parent",
                            Type = "string",
                            Value = Solid.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Solid.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Width",
                            Type = "float",
                            Value = Solid.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Width Units",
                            Type = "DimensionUnitType",
                            Value = Solid.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Solid.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.X Units",
                            Type = "PositionUnitType",
                            Value = Solid.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Solid.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Y Units",
                            Type = "PositionUnitType",
                            Value = Solid.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Bordered.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Height",
                            Type = "float",
                            Value = Bordered.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Height Units",
                            Type = "DimensionUnitType",
                            Value = Bordered.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Parent",
                            Type = "string",
                            Value = Bordered.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Bordered.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Width",
                            Type = "float",
                            Value = Bordered.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Width Units",
                            Type = "DimensionUnitType",
                            Value = Bordered.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Bordered.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.X Units",
                            Type = "PositionUnitType",
                            Value = Bordered.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y",
                            Type = "float",
                            Value = Bordered.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Bordered.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y Units",
                            Type = "PositionUnitType",
                            Value = Bordered.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = BracketHorizontal.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Height",
                            Type = "float",
                            Value = BracketHorizontal.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Height Units",
                            Type = "DimensionUnitType",
                            Value = BracketHorizontal.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Parent",
                            Type = "string",
                            Value = BracketHorizontal.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = BracketHorizontal.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Width",
                            Type = "float",
                            Value = BracketHorizontal.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Width Units",
                            Type = "DimensionUnitType",
                            Value = BracketHorizontal.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.X Origin",
                            Type = "HorizontalAlignment",
                            Value = BracketHorizontal.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.X Units",
                            Type = "PositionUnitType",
                            Value = BracketHorizontal.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y",
                            Type = "float",
                            Value = BracketHorizontal.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y Origin",
                            Type = "VerticalAlignment",
                            Value = BracketHorizontal.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y Units",
                            Type = "PositionUnitType",
                            Value = BracketHorizontal.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = BracketVertical.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Height",
                            Type = "float",
                            Value = BracketVertical.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Height Units",
                            Type = "DimensionUnitType",
                            Value = BracketVertical.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Parent",
                            Type = "string",
                            Value = BracketVertical.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = BracketVertical.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Width",
                            Type = "float",
                            Value = BracketVertical.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Width Units",
                            Type = "DimensionUnitType",
                            Value = BracketVertical.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.X Origin",
                            Type = "HorizontalAlignment",
                            Value = BracketVertical.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.X Units",
                            Type = "PositionUnitType",
                            Value = BracketVertical.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y",
                            Type = "float",
                            Value = BracketVertical.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y Origin",
                            Type = "VerticalAlignment",
                            Value = BracketVertical.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y Units",
                            Type = "PositionUnitType",
                            Value = BracketVertical.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Tab.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Height",
                            Type = "float",
                            Value = Tab.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Height Units",
                            Type = "DimensionUnitType",
                            Value = Tab.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Parent",
                            Type = "string",
                            Value = Tab.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Tab.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Width",
                            Type = "float",
                            Value = Tab.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Width Units",
                            Type = "DimensionUnitType",
                            Value = Tab.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Tab.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.X Units",
                            Type = "PositionUnitType",
                            Value = Tab.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y",
                            Type = "float",
                            Value = Tab.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Tab.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y Units",
                            Type = "PositionUnitType",
                            Value = Tab.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabBordered.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Height",
                            Type = "float",
                            Value = TabBordered.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabBordered.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Parent",
                            Type = "string",
                            Value = TabBordered.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TabBordered.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Width",
                            Type = "float",
                            Value = TabBordered.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabBordered.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabBordered.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.X Units",
                            Type = "PositionUnitType",
                            Value = TabBordered.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y",
                            Type = "float",
                            Value = TabBordered.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabBordered.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y Units",
                            Type = "PositionUnitType",
                            Value = TabBordered.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Outlined.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Height",
                            Type = "float",
                            Value = Outlined.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Height Units",
                            Type = "DimensionUnitType",
                            Value = Outlined.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Parent",
                            Type = "string",
                            Value = Outlined.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Outlined.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Width",
                            Type = "float",
                            Value = Outlined.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Width Units",
                            Type = "DimensionUnitType",
                            Value = Outlined.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Outlined.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.X Units",
                            Type = "PositionUnitType",
                            Value = Outlined.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y",
                            Type = "float",
                            Value = Outlined.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Outlined.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y Units",
                            Type = "PositionUnitType",
                            Value = Outlined.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = OutlinedHeavy.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Height",
                            Type = "float",
                            Value = OutlinedHeavy.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Height Units",
                            Type = "DimensionUnitType",
                            Value = OutlinedHeavy.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Parent",
                            Type = "string",
                            Value = OutlinedHeavy.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = OutlinedHeavy.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Width",
                            Type = "float",
                            Value = OutlinedHeavy.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Width Units",
                            Type = "DimensionUnitType",
                            Value = OutlinedHeavy.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.X Origin",
                            Type = "HorizontalAlignment",
                            Value = OutlinedHeavy.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.X Units",
                            Type = "PositionUnitType",
                            Value = OutlinedHeavy.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y",
                            Type = "float",
                            Value = OutlinedHeavy.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y Origin",
                            Type = "VerticalAlignment",
                            Value = OutlinedHeavy.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y Units",
                            Type = "PositionUnitType",
                            Value = OutlinedHeavy.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Panel.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Height",
                            Type = "float",
                            Value = Panel.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Height Units",
                            Type = "DimensionUnitType",
                            Value = Panel.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Parent",
                            Type = "string",
                            Value = Panel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Panel.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Width",
                            Type = "float",
                            Value = Panel.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Width Units",
                            Type = "DimensionUnitType",
                            Value = Panel.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Panel.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.X Units",
                            Type = "PositionUnitType",
                            Value = Panel.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y",
                            Type = "float",
                            Value = Panel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Panel.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y Units",
                            Type = "PositionUnitType",
                            Value = Panel.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = NineSliceStyleContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Height",
                            Type = "float",
                            Value = NineSliceStyleContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = NineSliceStyleContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Width",
                            Type = "float",
                            Value = NineSliceStyleContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = NineSliceStyleContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.X",
                            Type = "float",
                            Value = NineSliceStyleContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Y",
                            Type = "float",
                            Value = NineSliceStyleContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ButtonsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Height",
                            Type = "float",
                            Value = ButtonsContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ButtonsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Width",
                            Type = "float",
                            Value = ButtonsContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonsContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.X",
                            Type = "float",
                            Value = ButtonsContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Y",
                            Type = "float",
                            Value = ButtonsContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonStandardInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardInstance.Parent",
                            Type = "string",
                            Value = ButtonStandardInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonStandardIconInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.Parent",
                            Type = "string",
                            Value = ButtonStandardIconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.Y",
                            Type = "float",
                            Value = ButtonStandardIconInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Parent",
                            Type = "string",
                            Value = ButtonTabInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.TabDisplayText",
                            Type = "string",
                            Value = ButtonTabInstance.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonTabInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonTabInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Y",
                            Type = "float",
                            Value = ButtonTabInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ButtonTabInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonIconInstance.Parent",
                            Type = "string",
                            Value = ButtonIconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonIconInstance.Y",
                            Type = "float",
                            Value = ButtonIconInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonConfirmInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonDenyInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Y",
                            Type = "float",
                            Value = ButtonDenyInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Y",
                            Type = "float",
                            Value = ButtonCloseInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ElementsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Height",
                            Type = "float",
                            Value = ElementsContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ElementsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.X",
                            Type = "float",
                            Value = ElementsContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Y",
                            Type = "float",
                            Value = ElementsContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Parent",
                            Type = "string",
                            Value = PercentBarPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Width",
                            Type = "float",
                            Value = PercentBarPrimary.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarLinesDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Parent",
                            Type = "string",
                            Value = PercentBarLinesDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Width",
                            Type = "float",
                            Value = PercentBarLinesDecor.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarLinesDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Y",
                            Type = "float",
                            Value = PercentBarLinesDecor.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarCautionDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Parent",
                            Type = "string",
                            Value = PercentBarCautionDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Width",
                            Type = "float",
                            Value = PercentBarCautionDecor.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarCautionDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Y",
                            Type = "float",
                            Value = PercentBarCautionDecor.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconPrimary.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconPrimary.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconPrimary.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconPrimary.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Parent",
                            Type = "string",
                            Value = PercentBarIconPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Width",
                            Type = "float",
                            Value = PercentBarIconPrimary.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Y",
                            Type = "float",
                            Value = PercentBarIconPrimary.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconLinesDecor.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconLinesDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconLinesDecor.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconLinesDecor.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Parent",
                            Type = "string",
                            Value = PercentBarIconLinesDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Width",
                            Type = "float",
                            Value = PercentBarIconLinesDecor.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconLinesDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Y",
                            Type = "float",
                            Value = PercentBarIconLinesDecor.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconCautionDecor.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconCautionDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconCautionDecor.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconCautionDecor.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Parent",
                            Type = "string",
                            Value = PercentBarIconCautionDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Width",
                            Type = "float",
                            Value = PercentBarIconCautionDecor.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconCautionDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Y",
                            Type = "float",
                            Value = PercentBarIconCautionDecor.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ControlsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Height",
                            Type = "float",
                            Value = ControlsContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ControlsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Width",
                            Type = "float",
                            Value = ControlsContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ControlsContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.X",
                            Type = "float",
                            Value = ControlsContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Y",
                            Type = "float",
                            Value = ControlsContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Parent",
                            Type = "string",
                            Value = CheckBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Width",
                            Type = "float",
                            Value = CheckBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = CheckBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Y",
                            Type = "float",
                            Value = RadioButtonInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Y",
                            Type = "float",
                            Value = ComboBoxInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Height",
                            Type = "float",
                            Value = ListBoxInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Parent",
                            Type = "string",
                            Value = ListBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Width",
                            Type = "float",
                            Value = ListBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ListBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Y",
                            Type = "float",
                            Value = ListBoxInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Parent",
                            Type = "string",
                            Value = SliderInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Width",
                            Type = "float",
                            Value = SliderInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = SliderInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Y",
                            Type = "float",
                            Value = SliderInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Y",
                            Type = "float",
                            Value = TextBoxInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PasswordBoxInstance.Parent",
                            Type = "string",
                            Value = PasswordBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PasswordBoxInstance.Y",
                            Type = "float",
                            Value = PasswordBoxInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Height",
                            Type = "float",
                            Value = DividerVerticalInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Parent",
                            Type = "string",
                            Value = DividerVerticalInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Y",
                            Type = "float",
                            Value = DividerVerticalInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Parent",
                            Type = "string",
                            Value = DividerHorizontalInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Width",
                            Type = "float",
                            Value = DividerHorizontalInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerHorizontalInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Y",
                            Type = "float",
                            Value = DividerHorizontalInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "IconInstance.Parent",
                            Type = "string",
                            Value = IconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.LineColor",
                            Type = "ColorCategory",
                            Value = CautionLinesInstance.LineColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Parent",
                            Type = "string",
                            Value = CautionLinesInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Width",
                            Type = "float",
                            Value = CautionLinesInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = CautionLinesInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Y",
                            Type = "float",
                            Value = CautionLinesInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.LineColor",
                            Type = "ColorCategory",
                            Value = VerticalLinesInstance.LineColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Parent",
                            Type = "string",
                            Value = VerticalLinesInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Width",
                            Type = "float",
                            Value = VerticalLinesInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = VerticalLinesInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Y",
                            Type = "float",
                            Value = VerticalLinesInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ColorContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Height",
                            Type = "float",
                            Value = ColorContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ColorContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.X",
                            Type = "float",
                            Value = ColorContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Y",
                            Type = "float",
                            Value = ColorContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextBlack.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Parent",
                            Type = "string",
                            Value = TextBlack.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextBlack.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Text",
                            Type = "string",
                            Value = TextBlack.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBlack.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextDarkGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Parent",
                            Type = "string",
                            Value = TextDarkGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextDarkGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Text",
                            Type = "string",
                            Value = TextDarkGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextDarkGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Parent",
                            Type = "string",
                            Value = TextGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Text",
                            Type = "string",
                            Value = TextGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextLightGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Parent",
                            Type = "string",
                            Value = TextLightGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextLightGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Text",
                            Type = "string",
                            Value = TextLightGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextLightGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWhite.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Parent",
                            Type = "string",
                            Value = TextWhite.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWhite.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Text",
                            Type = "string",
                            Value = TextWhite.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWhite.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimaryDark.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Parent",
                            Type = "string",
                            Value = TextPrimaryDark.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimaryDark.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Text",
                            Type = "string",
                            Value = TextPrimaryDark.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimaryDark.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimary.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Parent",
                            Type = "string",
                            Value = TextPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimary.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Text",
                            Type = "string",
                            Value = TextPrimary.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimaryLight.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Parent",
                            Type = "string",
                            Value = TextPrimaryLight.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimaryLight.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Text",
                            Type = "string",
                            Value = TextPrimaryLight.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimaryLight.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextAccent.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Parent",
                            Type = "string",
                            Value = TextAccent.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextAccent.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Text",
                            Type = "string",
                            Value = TextAccent.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextAccent.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextSuccess.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Parent",
                            Type = "string",
                            Value = TextSuccess.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextSuccess.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Text",
                            Type = "string",
                            Value = TextSuccess.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextSuccess.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWarning.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Parent",
                            Type = "string",
                            Value = TextWarning.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWarning.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Text",
                            Type = "string",
                            Value = TextWarning.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWarning.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWarning1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Parent",
                            Type = "string",
                            Value = TextWarning1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWarning1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Text",
                            Type = "string",
                            Value = TextWarning1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWarning1.WidthUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = TextStyleContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Height",
                            Type = "float",
                            Value = TextStyleContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = TextStyleContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Width",
                            Type = "float",
                            Value = TextStyleContainer.Width + 85f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.X",
                            Type = "float",
                            Value = TextStyleContainer.X + 57f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStyleContainer.Y",
                            Type = "float",
                            Value = TextStyleContainer.Y + 11f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextTitle.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.Parent",
                            Type = "string",
                            Value = TextTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextTitle.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTitle.Text",
                            Type = "string",
                            Value = TextTitle.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.Parent",
                            Type = "string",
                            Value = TextH1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH1.Text",
                            Type = "string",
                            Value = TextH1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.Parent",
                            Type = "string",
                            Value = TextH2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH2.Text",
                            Type = "string",
                            Value = TextH2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextH3.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.Parent",
                            Type = "string",
                            Value = TextH3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextH3.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextH3.Text",
                            Type = "string",
                            Value = TextH3.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextNormal.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.Parent",
                            Type = "string",
                            Value = TextNormal.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextNormal.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextNormal.Text",
                            Type = "string",
                            Value = TextNormal.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextStrong.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.Parent",
                            Type = "string",
                            Value = TextStrong.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextStrong.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextStrong.Text",
                            Type = "string",
                            Value = TextStrong.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextEmphasis.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.Parent",
                            Type = "string",
                            Value = TextEmphasis.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextEmphasis.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextEmphasis.Text",
                            Type = "string",
                            Value = TextEmphasis.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextSmall.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.Parent",
                            Type = "string",
                            Value = TextSmall.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextSmall.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSmall.Text",
                            Type = "string",
                            Value = TextSmall.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextTiny.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.Parent",
                            Type = "string",
                            Value = TextTiny.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextTiny.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextTiny.Text",
                            Type = "string",
                            Value = TextTiny.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Solid.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Height",
                            Type = "float",
                            Value = Solid.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Height Units",
                            Type = "DimensionUnitType",
                            Value = Solid.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Parent",
                            Type = "string",
                            Value = Solid.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Solid.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Width",
                            Type = "float",
                            Value = Solid.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Width Units",
                            Type = "DimensionUnitType",
                            Value = Solid.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Solid.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.X Units",
                            Type = "PositionUnitType",
                            Value = Solid.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Solid.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Solid.Y Units",
                            Type = "PositionUnitType",
                            Value = Solid.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Bordered.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Height",
                            Type = "float",
                            Value = Bordered.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Height Units",
                            Type = "DimensionUnitType",
                            Value = Bordered.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Parent",
                            Type = "string",
                            Value = Bordered.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Bordered.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Width",
                            Type = "float",
                            Value = Bordered.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Width Units",
                            Type = "DimensionUnitType",
                            Value = Bordered.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Bordered.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.X Units",
                            Type = "PositionUnitType",
                            Value = Bordered.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y",
                            Type = "float",
                            Value = Bordered.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Bordered.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Bordered.Y Units",
                            Type = "PositionUnitType",
                            Value = Bordered.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = BracketHorizontal.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Height",
                            Type = "float",
                            Value = BracketHorizontal.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Height Units",
                            Type = "DimensionUnitType",
                            Value = BracketHorizontal.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Parent",
                            Type = "string",
                            Value = BracketHorizontal.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = BracketHorizontal.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Width",
                            Type = "float",
                            Value = BracketHorizontal.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Width Units",
                            Type = "DimensionUnitType",
                            Value = BracketHorizontal.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.X Origin",
                            Type = "HorizontalAlignment",
                            Value = BracketHorizontal.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.X Units",
                            Type = "PositionUnitType",
                            Value = BracketHorizontal.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y",
                            Type = "float",
                            Value = BracketHorizontal.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y Origin",
                            Type = "VerticalAlignment",
                            Value = BracketHorizontal.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketHorizontal.Y Units",
                            Type = "PositionUnitType",
                            Value = BracketHorizontal.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = BracketVertical.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Height",
                            Type = "float",
                            Value = BracketVertical.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Height Units",
                            Type = "DimensionUnitType",
                            Value = BracketVertical.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Parent",
                            Type = "string",
                            Value = BracketVertical.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = BracketVertical.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Width",
                            Type = "float",
                            Value = BracketVertical.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Width Units",
                            Type = "DimensionUnitType",
                            Value = BracketVertical.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.X Origin",
                            Type = "HorizontalAlignment",
                            Value = BracketVertical.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.X Units",
                            Type = "PositionUnitType",
                            Value = BracketVertical.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y",
                            Type = "float",
                            Value = BracketVertical.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y Origin",
                            Type = "VerticalAlignment",
                            Value = BracketVertical.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "BracketVertical.Y Units",
                            Type = "PositionUnitType",
                            Value = BracketVertical.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Tab.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Height",
                            Type = "float",
                            Value = Tab.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Height Units",
                            Type = "DimensionUnitType",
                            Value = Tab.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Parent",
                            Type = "string",
                            Value = Tab.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Tab.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Width",
                            Type = "float",
                            Value = Tab.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Width Units",
                            Type = "DimensionUnitType",
                            Value = Tab.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Tab.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.X Units",
                            Type = "PositionUnitType",
                            Value = Tab.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y",
                            Type = "float",
                            Value = Tab.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Tab.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Tab.Y Units",
                            Type = "PositionUnitType",
                            Value = Tab.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TabBordered.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Height",
                            Type = "float",
                            Value = TabBordered.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Height Units",
                            Type = "DimensionUnitType",
                            Value = TabBordered.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Parent",
                            Type = "string",
                            Value = TabBordered.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TabBordered.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Width",
                            Type = "float",
                            Value = TabBordered.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Width Units",
                            Type = "DimensionUnitType",
                            Value = TabBordered.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.X Origin",
                            Type = "HorizontalAlignment",
                            Value = TabBordered.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.X Units",
                            Type = "PositionUnitType",
                            Value = TabBordered.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y",
                            Type = "float",
                            Value = TabBordered.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y Origin",
                            Type = "VerticalAlignment",
                            Value = TabBordered.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TabBordered.Y Units",
                            Type = "PositionUnitType",
                            Value = TabBordered.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Outlined.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Height",
                            Type = "float",
                            Value = Outlined.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Height Units",
                            Type = "DimensionUnitType",
                            Value = Outlined.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Parent",
                            Type = "string",
                            Value = Outlined.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Outlined.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Width",
                            Type = "float",
                            Value = Outlined.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Width Units",
                            Type = "DimensionUnitType",
                            Value = Outlined.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Outlined.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.X Units",
                            Type = "PositionUnitType",
                            Value = Outlined.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y",
                            Type = "float",
                            Value = Outlined.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Outlined.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Outlined.Y Units",
                            Type = "PositionUnitType",
                            Value = Outlined.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = OutlinedHeavy.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Height",
                            Type = "float",
                            Value = OutlinedHeavy.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Height Units",
                            Type = "DimensionUnitType",
                            Value = OutlinedHeavy.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Parent",
                            Type = "string",
                            Value = OutlinedHeavy.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = OutlinedHeavy.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Width",
                            Type = "float",
                            Value = OutlinedHeavy.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Width Units",
                            Type = "DimensionUnitType",
                            Value = OutlinedHeavy.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.X Origin",
                            Type = "HorizontalAlignment",
                            Value = OutlinedHeavy.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.X Units",
                            Type = "PositionUnitType",
                            Value = OutlinedHeavy.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y",
                            Type = "float",
                            Value = OutlinedHeavy.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y Origin",
                            Type = "VerticalAlignment",
                            Value = OutlinedHeavy.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "OutlinedHeavy.Y Units",
                            Type = "PositionUnitType",
                            Value = OutlinedHeavy.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Panel.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Height",
                            Type = "float",
                            Value = Panel.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Height Units",
                            Type = "DimensionUnitType",
                            Value = Panel.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Parent",
                            Type = "string",
                            Value = Panel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Panel.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Width",
                            Type = "float",
                            Value = Panel.Width + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Width Units",
                            Type = "DimensionUnitType",
                            Value = Panel.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Panel.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.X Units",
                            Type = "PositionUnitType",
                            Value = Panel.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y",
                            Type = "float",
                            Value = Panel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Panel.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Panel.Y Units",
                            Type = "PositionUnitType",
                            Value = Panel.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = NineSliceStyleContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Height",
                            Type = "float",
                            Value = NineSliceStyleContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = NineSliceStyleContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Width",
                            Type = "float",
                            Value = NineSliceStyleContainer.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = NineSliceStyleContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.X",
                            Type = "float",
                            Value = NineSliceStyleContainer.X + 9f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "NineSliceStyleContainer.Y",
                            Type = "float",
                            Value = NineSliceStyleContainer.Y + 14f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ButtonsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Height",
                            Type = "float",
                            Value = ButtonsContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ButtonsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Width",
                            Type = "float",
                            Value = ButtonsContainer.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonsContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.X",
                            Type = "float",
                            Value = ButtonsContainer.X + 159f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonsContainer.Y",
                            Type = "float",
                            Value = ButtonsContainer.Y + 12f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonStandardInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardInstance.Parent",
                            Type = "string",
                            Value = ButtonStandardInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonStandardIconInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.Parent",
                            Type = "string",
                            Value = ButtonStandardIconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonStandardIconInstance.Y",
                            Type = "float",
                            Value = ButtonStandardIconInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Parent",
                            Type = "string",
                            Value = ButtonTabInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.TabDisplayText",
                            Type = "string",
                            Value = ButtonTabInstance.TabDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonTabInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonTabInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Y",
                            Type = "float",
                            Value = ButtonTabInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonTabInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ButtonTabInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonIconInstance.Parent",
                            Type = "string",
                            Value = ButtonIconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonIconInstance.Y",
                            Type = "float",
                            Value = ButtonIconInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonConfirmInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.ButtonDisplayText",
                            Type = "string",
                            Value = ButtonDenyInstance.ButtonDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Y",
                            Type = "float",
                            Value = ButtonDenyInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Y",
                            Type = "float",
                            Value = ButtonCloseInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ElementsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Height",
                            Type = "float",
                            Value = ElementsContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ElementsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.X",
                            Type = "float",
                            Value = ElementsContainer.X + 310f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ElementsContainer.Y",
                            Type = "float",
                            Value = ElementsContainer.Y + 14f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Parent",
                            Type = "string",
                            Value = PercentBarPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Width",
                            Type = "float",
                            Value = PercentBarPrimary.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarLinesDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Parent",
                            Type = "string",
                            Value = PercentBarLinesDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Width",
                            Type = "float",
                            Value = PercentBarLinesDecor.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarLinesDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarLinesDecor.Y",
                            Type = "float",
                            Value = PercentBarLinesDecor.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarCautionDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Parent",
                            Type = "string",
                            Value = PercentBarCautionDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Width",
                            Type = "float",
                            Value = PercentBarCautionDecor.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarCautionDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarCautionDecor.Y",
                            Type = "float",
                            Value = PercentBarCautionDecor.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconPrimary.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconPrimary.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconPrimary.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconPrimary.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Parent",
                            Type = "string",
                            Value = PercentBarIconPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Width",
                            Type = "float",
                            Value = PercentBarIconPrimary.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconPrimary.Y",
                            Type = "float",
                            Value = PercentBarIconPrimary.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconLinesDecor.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconLinesDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconLinesDecor.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconLinesDecor.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Parent",
                            Type = "string",
                            Value = PercentBarIconLinesDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Width",
                            Type = "float",
                            Value = PercentBarIconLinesDecor.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconLinesDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconLinesDecor.Y",
                            Type = "float",
                            Value = PercentBarIconLinesDecor.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconCautionDecor.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarDecorCategoryState",
                            Type = "BarDecorCategory",
                            Value = PercentBarIconCautionDecor.CurrentBarDecorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarIcon",
                            Type = "IconCategory",
                            Value = PercentBarIconCautionDecor.BarIcon
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.BarIconColor",
                            Type = "ColorCategory",
                            Value = PercentBarIconCautionDecor.BarIconColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Parent",
                            Type = "string",
                            Value = PercentBarIconCautionDecor.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Width",
                            Type = "float",
                            Value = PercentBarIconCautionDecor.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarIconCautionDecor.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarIconCautionDecor.Y",
                            Type = "float",
                            Value = PercentBarIconCautionDecor.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ControlsContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Height",
                            Type = "float",
                            Value = ControlsContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ControlsContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Width",
                            Type = "float",
                            Value = ControlsContainer.Width + 256f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ControlsContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.X",
                            Type = "float",
                            Value = ControlsContainer.X + 482f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlsContainer.Y",
                            Type = "float",
                            Value = ControlsContainer.Y + 12f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Parent",
                            Type = "string",
                            Value = CheckBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Width",
                            Type = "float",
                            Value = CheckBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CheckBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = CheckBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Y",
                            Type = "float",
                            Value = RadioButtonInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Y",
                            Type = "float",
                            Value = ComboBoxInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Height",
                            Type = "float",
                            Value = ListBoxInstance.Height + 96f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Parent",
                            Type = "string",
                            Value = ListBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Width",
                            Type = "float",
                            Value = ListBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ListBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ListBoxInstance.Y",
                            Type = "float",
                            Value = ListBoxInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Parent",
                            Type = "string",
                            Value = SliderInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Width",
                            Type = "float",
                            Value = SliderInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = SliderInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SliderInstance.Y",
                            Type = "float",
                            Value = SliderInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Y",
                            Type = "float",
                            Value = TextBoxInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PasswordBoxInstance.Parent",
                            Type = "string",
                            Value = PasswordBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PasswordBoxInstance.Y",
                            Type = "float",
                            Value = PasswordBoxInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Height",
                            Type = "float",
                            Value = DividerVerticalInstance.Height + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Parent",
                            Type = "string",
                            Value = DividerVerticalInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerVerticalInstance.Y",
                            Type = "float",
                            Value = DividerVerticalInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Parent",
                            Type = "string",
                            Value = DividerHorizontalInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Width",
                            Type = "float",
                            Value = DividerHorizontalInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerHorizontalInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerHorizontalInstance.Y",
                            Type = "float",
                            Value = DividerHorizontalInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "IconInstance.Parent",
                            Type = "string",
                            Value = IconInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.LineColor",
                            Type = "ColorCategory",
                            Value = CautionLinesInstance.LineColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Parent",
                            Type = "string",
                            Value = CautionLinesInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Width",
                            Type = "float",
                            Value = CautionLinesInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = CautionLinesInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "CautionLinesInstance.Y",
                            Type = "float",
                            Value = CautionLinesInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.LineColor",
                            Type = "ColorCategory",
                            Value = VerticalLinesInstance.LineColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Parent",
                            Type = "string",
                            Value = VerticalLinesInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Width",
                            Type = "float",
                            Value = VerticalLinesInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = VerticalLinesInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "VerticalLinesInstance.Y",
                            Type = "float",
                            Value = VerticalLinesInstance.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ColorContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Height",
                            Type = "float",
                            Value = ColorContainer.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = ColorContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.X",
                            Type = "float",
                            Value = ColorContainer.X + 774f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ColorContainer.Y",
                            Type = "float",
                            Value = ColorContainer.Y + 24f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextBlack.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Parent",
                            Type = "string",
                            Value = TextBlack.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextBlack.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Text",
                            Type = "string",
                            Value = TextBlack.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBlack.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBlack.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextDarkGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Parent",
                            Type = "string",
                            Value = TextDarkGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextDarkGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Text",
                            Type = "string",
                            Value = TextDarkGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextDarkGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextDarkGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Parent",
                            Type = "string",
                            Value = TextGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Text",
                            Type = "string",
                            Value = TextGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextLightGray.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Parent",
                            Type = "string",
                            Value = TextLightGray.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextLightGray.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Text",
                            Type = "string",
                            Value = TextLightGray.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextLightGray.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextLightGray.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWhite.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Parent",
                            Type = "string",
                            Value = TextWhite.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWhite.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Text",
                            Type = "string",
                            Value = TextWhite.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWhite.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWhite.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimaryDark.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Parent",
                            Type = "string",
                            Value = TextPrimaryDark.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimaryDark.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Text",
                            Type = "string",
                            Value = TextPrimaryDark.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryDark.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimaryDark.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimary.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Parent",
                            Type = "string",
                            Value = TextPrimary.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimary.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Text",
                            Type = "string",
                            Value = TextPrimary.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimary.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimary.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextPrimaryLight.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Parent",
                            Type = "string",
                            Value = TextPrimaryLight.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextPrimaryLight.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Text",
                            Type = "string",
                            Value = TextPrimaryLight.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextPrimaryLight.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextPrimaryLight.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextAccent.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Parent",
                            Type = "string",
                            Value = TextAccent.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextAccent.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Text",
                            Type = "string",
                            Value = TextAccent.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextAccent.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextAccent.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextSuccess.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Parent",
                            Type = "string",
                            Value = TextSuccess.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextSuccess.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Text",
                            Type = "string",
                            Value = TextSuccess.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextSuccess.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextSuccess.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWarning.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Parent",
                            Type = "string",
                            Value = TextWarning.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWarning.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Text",
                            Type = "string",
                            Value = TextWarning.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWarning.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TextWarning1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Parent",
                            Type = "string",
                            Value = TextWarning1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TextWarning1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Text",
                            Type = "string",
                            Value = TextWarning1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextWarning1.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextWarning1.WidthUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.ContainerRuntime TextStyleContainer { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextTitle { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextH1 { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextH2 { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextH3 { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextNormal { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextStrong { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextEmphasis { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextSmall { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextTiny { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Solid { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Bordered { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime BracketHorizontal { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime BracketVertical { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Tab { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime TabBordered { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Outlined { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime OutlinedHeavy { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Panel { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime NineSliceStyleContainer { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ButtonsContainer { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardRuntime ButtonStandardInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime ButtonStandardIconInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonTabRuntime ButtonTabInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonIconRuntime ButtonIconInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonConfirmRuntime ButtonConfirmInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonDenyRuntime ButtonDenyInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ElementsContainer { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarPrimary { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarLinesDecor { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarCautionDecor { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarIconRuntime PercentBarIconPrimary { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarIconRuntime PercentBarIconLinesDecor { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarIconRuntime PercentBarIconCautionDecor { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ControlsContainer { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime LabelInstance { get; set; }
            public NewGum.GumRuntimes.Controls.CheckBoxRuntime CheckBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ComboBoxRuntime ComboBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ListBoxRuntime ListBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.SliderRuntime SliderInstance { get; set; }
            public NewGum.GumRuntimes.Controls.TextBoxRuntime TextBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.PasswordBoxRuntime PasswordBoxInstance { get; set; }
            public NewGum.GumRuntimes.Elements.DividerVerticalRuntime DividerVerticalInstance { get; set; }
            public NewGum.GumRuntimes.Elements.DividerHorizontalRuntime DividerHorizontalInstance { get; set; }
            public NewGum.GumRuntimes.Elements.IconRuntime IconInstance { get; set; }
            public NewGum.GumRuntimes.Elements.CautionLinesRuntime CautionLinesInstance { get; set; }
            public NewGum.GumRuntimes.Elements.VerticalLinesRuntime VerticalLinesInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ColorContainer { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextBlack { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextDarkGray { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextGray { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextLightGray { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextWhite { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextPrimaryDark { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextPrimary { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextPrimaryLight { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextAccent { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextSuccess { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextWarning { get; set; }
            public NewGum.GumRuntimes.TextRuntime TextWarning1 { get; set; }
            public StylesScreenRuntime () 
            	: this(true, true)
            {
            }
            public StylesScreenRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Screens.First(item => item.Name == "StylesScreen");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                var wasSuppressed = this.IsLayoutSuspended;
                if(!wasSuppressed) this.SuspendLayout();
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                if(!wasSuppressed) this.ResumeLayout();
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                TextStyleContainer = this.GetGraphicalUiElementByName("TextStyleContainer") as NewGum.GumRuntimes.ContainerRuntime;
                TextTitle = this.GetGraphicalUiElementByName("TextTitle") as NewGum.GumRuntimes.TextRuntime;
                TextH1 = this.GetGraphicalUiElementByName("TextH1") as NewGum.GumRuntimes.TextRuntime;
                TextH2 = this.GetGraphicalUiElementByName("TextH2") as NewGum.GumRuntimes.TextRuntime;
                TextH3 = this.GetGraphicalUiElementByName("TextH3") as NewGum.GumRuntimes.TextRuntime;
                TextNormal = this.GetGraphicalUiElementByName("TextNormal") as NewGum.GumRuntimes.TextRuntime;
                TextStrong = this.GetGraphicalUiElementByName("TextStrong") as NewGum.GumRuntimes.TextRuntime;
                TextEmphasis = this.GetGraphicalUiElementByName("TextEmphasis") as NewGum.GumRuntimes.TextRuntime;
                TextSmall = this.GetGraphicalUiElementByName("TextSmall") as NewGum.GumRuntimes.TextRuntime;
                TextTiny = this.GetGraphicalUiElementByName("TextTiny") as NewGum.GumRuntimes.TextRuntime;
                Solid = this.GetGraphicalUiElementByName("Solid") as NewGum.GumRuntimes.NineSliceRuntime;
                Bordered = this.GetGraphicalUiElementByName("Bordered") as NewGum.GumRuntimes.NineSliceRuntime;
                BracketHorizontal = this.GetGraphicalUiElementByName("BracketHorizontal") as NewGum.GumRuntimes.NineSliceRuntime;
                BracketVertical = this.GetGraphicalUiElementByName("BracketVertical") as NewGum.GumRuntimes.NineSliceRuntime;
                Tab = this.GetGraphicalUiElementByName("Tab") as NewGum.GumRuntimes.NineSliceRuntime;
                TabBordered = this.GetGraphicalUiElementByName("TabBordered") as NewGum.GumRuntimes.NineSliceRuntime;
                Outlined = this.GetGraphicalUiElementByName("Outlined") as NewGum.GumRuntimes.NineSliceRuntime;
                OutlinedHeavy = this.GetGraphicalUiElementByName("OutlinedHeavy") as NewGum.GumRuntimes.NineSliceRuntime;
                Panel = this.GetGraphicalUiElementByName("Panel") as NewGum.GumRuntimes.NineSliceRuntime;
                NineSliceStyleContainer = this.GetGraphicalUiElementByName("NineSliceStyleContainer") as NewGum.GumRuntimes.ContainerRuntime;
                ButtonsContainer = this.GetGraphicalUiElementByName("ButtonsContainer") as NewGum.GumRuntimes.ContainerRuntime;
                ButtonStandardInstance = this.GetGraphicalUiElementByName("ButtonStandardInstance") as NewGum.GumRuntimes.Controls.ButtonStandardRuntime;
                ButtonStandardIconInstance = this.GetGraphicalUiElementByName("ButtonStandardIconInstance") as NewGum.GumRuntimes.Controls.ButtonStandardIconRuntime;
                ButtonTabInstance = this.GetGraphicalUiElementByName("ButtonTabInstance") as NewGum.GumRuntimes.Controls.ButtonTabRuntime;
                ButtonIconInstance = this.GetGraphicalUiElementByName("ButtonIconInstance") as NewGum.GumRuntimes.Controls.ButtonIconRuntime;
                ButtonConfirmInstance = this.GetGraphicalUiElementByName("ButtonConfirmInstance") as NewGum.GumRuntimes.Controls.ButtonConfirmRuntime;
                ButtonDenyInstance = this.GetGraphicalUiElementByName("ButtonDenyInstance") as NewGum.GumRuntimes.Controls.ButtonDenyRuntime;
                ButtonCloseInstance = this.GetGraphicalUiElementByName("ButtonCloseInstance") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                ElementsContainer = this.GetGraphicalUiElementByName("ElementsContainer") as NewGum.GumRuntimes.ContainerRuntime;
                PercentBarPrimary = this.GetGraphicalUiElementByName("PercentBarPrimary") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarLinesDecor = this.GetGraphicalUiElementByName("PercentBarLinesDecor") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarCautionDecor = this.GetGraphicalUiElementByName("PercentBarCautionDecor") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarIconPrimary = this.GetGraphicalUiElementByName("PercentBarIconPrimary") as NewGum.GumRuntimes.Elements.PercentBarIconRuntime;
                PercentBarIconLinesDecor = this.GetGraphicalUiElementByName("PercentBarIconLinesDecor") as NewGum.GumRuntimes.Elements.PercentBarIconRuntime;
                PercentBarIconCautionDecor = this.GetGraphicalUiElementByName("PercentBarIconCautionDecor") as NewGum.GumRuntimes.Elements.PercentBarIconRuntime;
                ControlsContainer = this.GetGraphicalUiElementByName("ControlsContainer") as NewGum.GumRuntimes.ContainerRuntime;
                LabelInstance = this.GetGraphicalUiElementByName("LabelInstance") as NewGum.GumRuntimes.Elements.LabelRuntime;
                CheckBoxInstance = this.GetGraphicalUiElementByName("CheckBoxInstance") as NewGum.GumRuntimes.Controls.CheckBoxRuntime;
                RadioButtonInstance = this.GetGraphicalUiElementByName("RadioButtonInstance") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                ComboBoxInstance = this.GetGraphicalUiElementByName("ComboBoxInstance") as NewGum.GumRuntimes.Controls.ComboBoxRuntime;
                ListBoxInstance = this.GetGraphicalUiElementByName("ListBoxInstance") as NewGum.GumRuntimes.Controls.ListBoxRuntime;
                SliderInstance = this.GetGraphicalUiElementByName("SliderInstance") as NewGum.GumRuntimes.Controls.SliderRuntime;
                TextBoxInstance = this.GetGraphicalUiElementByName("TextBoxInstance") as NewGum.GumRuntimes.Controls.TextBoxRuntime;
                PasswordBoxInstance = this.GetGraphicalUiElementByName("PasswordBoxInstance") as NewGum.GumRuntimes.Controls.PasswordBoxRuntime;
                DividerVerticalInstance = this.GetGraphicalUiElementByName("DividerVerticalInstance") as NewGum.GumRuntimes.Elements.DividerVerticalRuntime;
                DividerHorizontalInstance = this.GetGraphicalUiElementByName("DividerHorizontalInstance") as NewGum.GumRuntimes.Elements.DividerHorizontalRuntime;
                IconInstance = this.GetGraphicalUiElementByName("IconInstance") as NewGum.GumRuntimes.Elements.IconRuntime;
                CautionLinesInstance = this.GetGraphicalUiElementByName("CautionLinesInstance") as NewGum.GumRuntimes.Elements.CautionLinesRuntime;
                VerticalLinesInstance = this.GetGraphicalUiElementByName("VerticalLinesInstance") as NewGum.GumRuntimes.Elements.VerticalLinesRuntime;
                ColorContainer = this.GetGraphicalUiElementByName("ColorContainer") as NewGum.GumRuntimes.ContainerRuntime;
                TextBlack = this.GetGraphicalUiElementByName("TextBlack") as NewGum.GumRuntimes.TextRuntime;
                TextDarkGray = this.GetGraphicalUiElementByName("TextDarkGray") as NewGum.GumRuntimes.TextRuntime;
                TextGray = this.GetGraphicalUiElementByName("TextGray") as NewGum.GumRuntimes.TextRuntime;
                TextLightGray = this.GetGraphicalUiElementByName("TextLightGray") as NewGum.GumRuntimes.TextRuntime;
                TextWhite = this.GetGraphicalUiElementByName("TextWhite") as NewGum.GumRuntimes.TextRuntime;
                TextPrimaryDark = this.GetGraphicalUiElementByName("TextPrimaryDark") as NewGum.GumRuntimes.TextRuntime;
                TextPrimary = this.GetGraphicalUiElementByName("TextPrimary") as NewGum.GumRuntimes.TextRuntime;
                TextPrimaryLight = this.GetGraphicalUiElementByName("TextPrimaryLight") as NewGum.GumRuntimes.TextRuntime;
                TextAccent = this.GetGraphicalUiElementByName("TextAccent") as NewGum.GumRuntimes.TextRuntime;
                TextSuccess = this.GetGraphicalUiElementByName("TextSuccess") as NewGum.GumRuntimes.TextRuntime;
                TextWarning = this.GetGraphicalUiElementByName("TextWarning") as NewGum.GumRuntimes.TextRuntime;
                TextWarning1 = this.GetGraphicalUiElementByName("TextWarning1") as NewGum.GumRuntimes.TextRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new NewGum.FormsControls.Screens.StylesScreenForms(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public NewGum.FormsControls.Screens.StylesScreenForms FormsControl {get => (NewGum.FormsControls.Screens.StylesScreenForms) FormsControlAsObject;}
        }
    }
