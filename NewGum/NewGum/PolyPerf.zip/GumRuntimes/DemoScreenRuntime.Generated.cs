    using System.Linq;
    namespace NewGum.GumRuntimes
    {
        public partial class DemoScreenRuntime : Gum.Wireframe.GraphicalUiElement
        {
            #region State Enums
            public enum VariableState
            {
                Default
            }
            #endregion
            #region State Fields
            VariableState mCurrentVariableState;
            #endregion
            #region State Properties
            public VariableState CurrentVariableState
            {
                get
                {
                    return mCurrentVariableState;
                }
                set
                {
                    mCurrentVariableState = value;
                    switch(mCurrentVariableState)
                    {
                        case  VariableState.Default:
                            Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                            MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                            TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                            DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                            ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                            ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                            ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                            ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                            MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                            LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                            TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                            PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                            ContainerInstance.Parent = this.GetGraphicalUiElementByName("Hud");
                            Background.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Background.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            TitleText.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            TitleText1.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText1.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            RadioButtonInstance.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                            RadioButtonInstance1.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                            RadioButtonInstance2.CurrentRadioButtonCategoryState = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                            Background1.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Background1.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            Hud.CurrentColorCategoryState = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                            Hud.CurrentStyleCategoryState = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                            TitleText2.CurrentColorCategoryState = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                            TitleText2.CurrentStyleCategoryState = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                            PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                            PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                            PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                            PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                            PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                            DemoSettingsMenu.Height = 610f;
                            DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            DemoSettingsMenu.Width = 400f;
                            DemoSettingsMenu.X = 40f;
                            DemoSettingsMenu.Y = 35f;
                            MenuTitle.Height = 8f;
                            MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle.Width = 0f;
                            MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuTitle1.Height = 8f;
                            MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle1.Width = 0f;
                            MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            MenuItems.Height = -16f;
                            MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuItems.Width = -16f;
                            MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MenuItems.X = 0f;
                            MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            MenuItems.Y = 0f;
                            MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            TitleText.Text = "Settings";
                            TitleText1.Text = "New Profile";
                            ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DividerInstance.Width = 0f;
                            DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DividerInstance4.Width = 0f;
                            DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ResolutionLabel.LabelText = "Resolution";
                            ResolutionBox.Height = 128f;
                            ResolutionBox.Width = 0f;
                            ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                            FullScreenCheckbox.Y = 4f;
                            DividerInstance1.Width = 0f;
                            DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance1.Y = 8f;
                            MusicLabel.LabelText = "Music Volume";
                            MusicLabel.Y = 8f;
                            MusicSlider.Width = 0f;
                            MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            SoundLabel.LabelText = "Sound Volume";
                            SoundSlider.Width = 0f;
                            SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance2.Width = 0f;
                            DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance2.Y = 8f;
                            ControlLabel.LabelText = "Control Scheme";
                            ControlLabel.Y = 8f;
                            RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                            RadioButtonInstance.Width = 0f;
                            RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance1.RadioDisplayText = "Gamepad";
                            RadioButtonInstance1.Width = 0f;
                            RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance1.Y = 4f;
                            RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                            RadioButtonInstance2.Width = 0f;
                            RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            RadioButtonInstance2.Y = 4f;
                            DividerInstance3.Width = 0f;
                            DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance3.Y = 8f;
                            DifficultyLabel.LabelText = "Difficulty";
                            DifficultyLabel.Y = 8f;
                            Background1.Height = 0f;
                            Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background1.Width = 0f;
                            Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            Background1.X = 0f;
                            Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            Background1.Y = 0f;
                            Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            ComboBoxInstance.Width = 0f;
                            ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonContainer.Height = 32f;
                            ButtonContainer.Width = 0f;
                            ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonContainer.Y = 16f;
                            ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            DemoDialog.Height = 163f;
                            DemoDialog.Width = 349f;
                            DemoDialog.X = 488f;
                            DemoDialog.Y = 42f;
                            MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            MarginContainer.Height = -16f;
                            MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MarginContainer.Width = -16f;
                            MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            MarginContainer.X = 0f;
                            MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            MarginContainer.Y = 0f;
                            MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            LabelInstance.LabelText = "New Profile Name";
                            LabelInstance.Y = 8f;
                            TextBoxInstance.Width = 0f;
                            TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonConfirmInstance1.Y = 16f;
                            Hud.Height = 207f;
                            Hud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Hud.Width = 279f;
                            Hud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                            Hud.X = -331f;
                            Hud.Y = -176f;
                            TitleText2.Text = "HUD Demo";
                            MenuTitle2.Height = 8f;
                            MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                            MenuTitle2.Width = 0f;
                            MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance.Width = 0f;
                            PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance.Y = 8f;
                            PercentBarInstance1.Width = 0f;
                            PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance1.Y = 8f;
                            PercentBarInstance2.Width = 0f;
                            PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance2.Y = 8f;
                            DividerInstance5.Width = 0f;
                            DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                            DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                            ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                            PercentBarInstance3.Width = 0f;
                            PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance3.Y = 8f;
                            PercentBarInstance4.Width = 0f;
                            PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance4.Y = 8f;
                            PercentBarInstance5.Width = 0f;
                            PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            PercentBarInstance5.Y = 8f;
                            ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                            ContainerInstance.Height = -16f;
                            ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ContainerInstance.Width = -16f;
                            ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                            ContainerInstance.X = 0f;
                            ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                            ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            ContainerInstance.Y = 0f;
                            ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                            ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                            break;
                    }
                }
            }
            #endregion
            #region State Interpolation
            public void InterpolateBetween (VariableState firstState, VariableState secondState, float interpolationValue) 
            {
                #if DEBUG
                if (float.IsNaN(interpolationValue))
                {
                    throw new System.Exception("interpolationValue cannot be NaN");
                }
                #endif
                bool setBackgroundCurrentColorCategoryStateFirstValue = false;
                bool setBackgroundCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory BackgroundCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackgroundCurrentStyleCategoryStateFirstValue = false;
                bool setBackgroundCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory BackgroundCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackground1CurrentColorCategoryStateFirstValue = false;
                bool setBackground1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory Background1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory Background1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setBackground1HeightFirstValue = false;
                bool setBackground1HeightSecondValue = false;
                float Background1HeightFirstValue= 0;
                float Background1HeightSecondValue= 0;
                bool setBackground1CurrentStyleCategoryStateFirstValue = false;
                bool setBackground1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory Background1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory Background1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setBackground1WidthFirstValue = false;
                bool setBackground1WidthSecondValue = false;
                float Background1WidthFirstValue= 0;
                float Background1WidthSecondValue= 0;
                bool setBackground1XFirstValue = false;
                bool setBackground1XSecondValue = false;
                float Background1XFirstValue= 0;
                float Background1XSecondValue= 0;
                bool setBackground1YFirstValue = false;
                bool setBackground1YSecondValue = false;
                float Background1YFirstValue= 0;
                float Background1YSecondValue= 0;
                bool setButtonConfirmInstance1YFirstValue = false;
                bool setButtonConfirmInstance1YSecondValue = false;
                float ButtonConfirmInstance1YFirstValue= 0;
                float ButtonConfirmInstance1YSecondValue= 0;
                bool setButtonContainerHeightFirstValue = false;
                bool setButtonContainerHeightSecondValue = false;
                float ButtonContainerHeightFirstValue= 0;
                float ButtonContainerHeightSecondValue= 0;
                bool setButtonContainerWidthFirstValue = false;
                bool setButtonContainerWidthSecondValue = false;
                float ButtonContainerWidthFirstValue= 0;
                float ButtonContainerWidthSecondValue= 0;
                bool setButtonContainerYFirstValue = false;
                bool setButtonContainerYSecondValue = false;
                float ButtonContainerYFirstValue= 0;
                float ButtonContainerYSecondValue= 0;
                bool setComboBoxInstanceWidthFirstValue = false;
                bool setComboBoxInstanceWidthSecondValue = false;
                float ComboBoxInstanceWidthFirstValue= 0;
                float ComboBoxInstanceWidthSecondValue= 0;
                bool setContainerInstanceHeightFirstValue = false;
                bool setContainerInstanceHeightSecondValue = false;
                float ContainerInstanceHeightFirstValue= 0;
                float ContainerInstanceHeightSecondValue= 0;
                bool setContainerInstanceWidthFirstValue = false;
                bool setContainerInstanceWidthSecondValue = false;
                float ContainerInstanceWidthFirstValue= 0;
                float ContainerInstanceWidthSecondValue= 0;
                bool setContainerInstanceXFirstValue = false;
                bool setContainerInstanceXSecondValue = false;
                float ContainerInstanceXFirstValue= 0;
                float ContainerInstanceXSecondValue= 0;
                bool setContainerInstanceYFirstValue = false;
                bool setContainerInstanceYSecondValue = false;
                float ContainerInstanceYFirstValue= 0;
                float ContainerInstanceYSecondValue= 0;
                bool setControlLabelYFirstValue = false;
                bool setControlLabelYSecondValue = false;
                float ControlLabelYFirstValue= 0;
                float ControlLabelYSecondValue= 0;
                bool setDemoDialogHeightFirstValue = false;
                bool setDemoDialogHeightSecondValue = false;
                float DemoDialogHeightFirstValue= 0;
                float DemoDialogHeightSecondValue= 0;
                bool setDemoDialogWidthFirstValue = false;
                bool setDemoDialogWidthSecondValue = false;
                float DemoDialogWidthFirstValue= 0;
                float DemoDialogWidthSecondValue= 0;
                bool setDemoDialogXFirstValue = false;
                bool setDemoDialogXSecondValue = false;
                float DemoDialogXFirstValue= 0;
                float DemoDialogXSecondValue= 0;
                bool setDemoDialogYFirstValue = false;
                bool setDemoDialogYSecondValue = false;
                float DemoDialogYFirstValue= 0;
                float DemoDialogYSecondValue= 0;
                bool setDemoSettingsMenuHeightFirstValue = false;
                bool setDemoSettingsMenuHeightSecondValue = false;
                float DemoSettingsMenuHeightFirstValue= 0;
                float DemoSettingsMenuHeightSecondValue= 0;
                bool setDemoSettingsMenuWidthFirstValue = false;
                bool setDemoSettingsMenuWidthSecondValue = false;
                float DemoSettingsMenuWidthFirstValue= 0;
                float DemoSettingsMenuWidthSecondValue= 0;
                bool setDemoSettingsMenuXFirstValue = false;
                bool setDemoSettingsMenuXSecondValue = false;
                float DemoSettingsMenuXFirstValue= 0;
                float DemoSettingsMenuXSecondValue= 0;
                bool setDemoSettingsMenuYFirstValue = false;
                bool setDemoSettingsMenuYSecondValue = false;
                float DemoSettingsMenuYFirstValue= 0;
                float DemoSettingsMenuYSecondValue= 0;
                bool setDifficultyLabelYFirstValue = false;
                bool setDifficultyLabelYSecondValue = false;
                float DifficultyLabelYFirstValue= 0;
                float DifficultyLabelYSecondValue= 0;
                bool setDividerInstanceWidthFirstValue = false;
                bool setDividerInstanceWidthSecondValue = false;
                float DividerInstanceWidthFirstValue= 0;
                float DividerInstanceWidthSecondValue= 0;
                bool setDividerInstance1WidthFirstValue = false;
                bool setDividerInstance1WidthSecondValue = false;
                float DividerInstance1WidthFirstValue= 0;
                float DividerInstance1WidthSecondValue= 0;
                bool setDividerInstance1YFirstValue = false;
                bool setDividerInstance1YSecondValue = false;
                float DividerInstance1YFirstValue= 0;
                float DividerInstance1YSecondValue= 0;
                bool setDividerInstance2WidthFirstValue = false;
                bool setDividerInstance2WidthSecondValue = false;
                float DividerInstance2WidthFirstValue= 0;
                float DividerInstance2WidthSecondValue= 0;
                bool setDividerInstance2YFirstValue = false;
                bool setDividerInstance2YSecondValue = false;
                float DividerInstance2YFirstValue= 0;
                float DividerInstance2YSecondValue= 0;
                bool setDividerInstance3WidthFirstValue = false;
                bool setDividerInstance3WidthSecondValue = false;
                float DividerInstance3WidthFirstValue= 0;
                float DividerInstance3WidthSecondValue= 0;
                bool setDividerInstance3YFirstValue = false;
                bool setDividerInstance3YSecondValue = false;
                float DividerInstance3YFirstValue= 0;
                float DividerInstance3YSecondValue= 0;
                bool setDividerInstance4WidthFirstValue = false;
                bool setDividerInstance4WidthSecondValue = false;
                float DividerInstance4WidthFirstValue= 0;
                float DividerInstance4WidthSecondValue= 0;
                bool setDividerInstance5WidthFirstValue = false;
                bool setDividerInstance5WidthSecondValue = false;
                float DividerInstance5WidthFirstValue= 0;
                float DividerInstance5WidthSecondValue= 0;
                bool setFullScreenCheckboxYFirstValue = false;
                bool setFullScreenCheckboxYSecondValue = false;
                float FullScreenCheckboxYFirstValue= 0;
                float FullScreenCheckboxYSecondValue= 0;
                bool setHudCurrentColorCategoryStateFirstValue = false;
                bool setHudCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory HudCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.NineSliceRuntime.ColorCategory HudCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Black;
                bool setHudHeightFirstValue = false;
                bool setHudHeightSecondValue = false;
                float HudHeightFirstValue= 0;
                float HudHeightSecondValue= 0;
                bool setHudCurrentStyleCategoryStateFirstValue = false;
                bool setHudCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory HudCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                NewGum.GumRuntimes.NineSliceRuntime.StyleCategory HudCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Solid;
                bool setHudWidthFirstValue = false;
                bool setHudWidthSecondValue = false;
                float HudWidthFirstValue= 0;
                float HudWidthSecondValue= 0;
                bool setHudXFirstValue = false;
                bool setHudXSecondValue = false;
                float HudXFirstValue= 0;
                float HudXSecondValue= 0;
                bool setHudYFirstValue = false;
                bool setHudYSecondValue = false;
                float HudYFirstValue= 0;
                float HudYSecondValue= 0;
                bool setLabelInstanceYFirstValue = false;
                bool setLabelInstanceYSecondValue = false;
                float LabelInstanceYFirstValue= 0;
                float LabelInstanceYSecondValue= 0;
                bool setMarginContainerHeightFirstValue = false;
                bool setMarginContainerHeightSecondValue = false;
                float MarginContainerHeightFirstValue= 0;
                float MarginContainerHeightSecondValue= 0;
                bool setMarginContainerWidthFirstValue = false;
                bool setMarginContainerWidthSecondValue = false;
                float MarginContainerWidthFirstValue= 0;
                float MarginContainerWidthSecondValue= 0;
                bool setMarginContainerXFirstValue = false;
                bool setMarginContainerXSecondValue = false;
                float MarginContainerXFirstValue= 0;
                float MarginContainerXSecondValue= 0;
                bool setMarginContainerYFirstValue = false;
                bool setMarginContainerYSecondValue = false;
                float MarginContainerYFirstValue= 0;
                float MarginContainerYSecondValue= 0;
                bool setMenuItemsHeightFirstValue = false;
                bool setMenuItemsHeightSecondValue = false;
                float MenuItemsHeightFirstValue= 0;
                float MenuItemsHeightSecondValue= 0;
                bool setMenuItemsWidthFirstValue = false;
                bool setMenuItemsWidthSecondValue = false;
                float MenuItemsWidthFirstValue= 0;
                float MenuItemsWidthSecondValue= 0;
                bool setMenuItemsXFirstValue = false;
                bool setMenuItemsXSecondValue = false;
                float MenuItemsXFirstValue= 0;
                float MenuItemsXSecondValue= 0;
                bool setMenuItemsYFirstValue = false;
                bool setMenuItemsYSecondValue = false;
                float MenuItemsYFirstValue= 0;
                float MenuItemsYSecondValue= 0;
                bool setMenuTitleHeightFirstValue = false;
                bool setMenuTitleHeightSecondValue = false;
                float MenuTitleHeightFirstValue= 0;
                float MenuTitleHeightSecondValue= 0;
                bool setMenuTitleWidthFirstValue = false;
                bool setMenuTitleWidthSecondValue = false;
                float MenuTitleWidthFirstValue= 0;
                float MenuTitleWidthSecondValue= 0;
                bool setMenuTitle1HeightFirstValue = false;
                bool setMenuTitle1HeightSecondValue = false;
                float MenuTitle1HeightFirstValue= 0;
                float MenuTitle1HeightSecondValue= 0;
                bool setMenuTitle1WidthFirstValue = false;
                bool setMenuTitle1WidthSecondValue = false;
                float MenuTitle1WidthFirstValue= 0;
                float MenuTitle1WidthSecondValue= 0;
                bool setMenuTitle2HeightFirstValue = false;
                bool setMenuTitle2HeightSecondValue = false;
                float MenuTitle2HeightFirstValue= 0;
                float MenuTitle2HeightSecondValue= 0;
                bool setMenuTitle2WidthFirstValue = false;
                bool setMenuTitle2WidthSecondValue = false;
                float MenuTitle2WidthFirstValue= 0;
                float MenuTitle2WidthSecondValue= 0;
                bool setMusicLabelYFirstValue = false;
                bool setMusicLabelYSecondValue = false;
                float MusicLabelYFirstValue= 0;
                float MusicLabelYSecondValue= 0;
                bool setMusicSliderWidthFirstValue = false;
                bool setMusicSliderWidthSecondValue = false;
                float MusicSliderWidthFirstValue= 0;
                float MusicSliderWidthSecondValue= 0;
                bool setPercentBarInstanceWidthFirstValue = false;
                bool setPercentBarInstanceWidthSecondValue = false;
                float PercentBarInstanceWidthFirstValue= 0;
                float PercentBarInstanceWidthSecondValue= 0;
                bool setPercentBarInstanceYFirstValue = false;
                bool setPercentBarInstanceYSecondValue = false;
                float PercentBarInstanceYFirstValue= 0;
                float PercentBarInstanceYSecondValue= 0;
                bool setPercentBarInstance1WidthFirstValue = false;
                bool setPercentBarInstance1WidthSecondValue = false;
                float PercentBarInstance1WidthFirstValue= 0;
                float PercentBarInstance1WidthSecondValue= 0;
                bool setPercentBarInstance1YFirstValue = false;
                bool setPercentBarInstance1YSecondValue = false;
                float PercentBarInstance1YFirstValue= 0;
                float PercentBarInstance1YSecondValue= 0;
                bool setPercentBarInstance2WidthFirstValue = false;
                bool setPercentBarInstance2WidthSecondValue = false;
                float PercentBarInstance2WidthFirstValue= 0;
                float PercentBarInstance2WidthSecondValue= 0;
                bool setPercentBarInstance2YFirstValue = false;
                bool setPercentBarInstance2YSecondValue = false;
                float PercentBarInstance2YFirstValue= 0;
                float PercentBarInstance2YSecondValue= 0;
                bool setPercentBarInstance3WidthFirstValue = false;
                bool setPercentBarInstance3WidthSecondValue = false;
                float PercentBarInstance3WidthFirstValue= 0;
                float PercentBarInstance3WidthSecondValue= 0;
                bool setPercentBarInstance3YFirstValue = false;
                bool setPercentBarInstance3YSecondValue = false;
                float PercentBarInstance3YFirstValue= 0;
                float PercentBarInstance3YSecondValue= 0;
                bool setPercentBarInstance4WidthFirstValue = false;
                bool setPercentBarInstance4WidthSecondValue = false;
                float PercentBarInstance4WidthFirstValue= 0;
                float PercentBarInstance4WidthSecondValue= 0;
                bool setPercentBarInstance4YFirstValue = false;
                bool setPercentBarInstance4YSecondValue = false;
                float PercentBarInstance4YFirstValue= 0;
                float PercentBarInstance4YSecondValue= 0;
                bool setPercentBarInstance5WidthFirstValue = false;
                bool setPercentBarInstance5WidthSecondValue = false;
                float PercentBarInstance5WidthFirstValue= 0;
                float PercentBarInstance5WidthSecondValue= 0;
                bool setPercentBarInstance5YFirstValue = false;
                bool setPercentBarInstance5YSecondValue = false;
                float PercentBarInstance5YFirstValue= 0;
                float PercentBarInstance5YSecondValue= 0;
                bool setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstanceWidthFirstValue = false;
                bool setRadioButtonInstanceWidthSecondValue = false;
                float RadioButtonInstanceWidthFirstValue= 0;
                float RadioButtonInstanceWidthSecondValue= 0;
                bool setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstance1WidthFirstValue = false;
                bool setRadioButtonInstance1WidthSecondValue = false;
                float RadioButtonInstance1WidthFirstValue= 0;
                float RadioButtonInstance1WidthSecondValue= 0;
                bool setRadioButtonInstance1YFirstValue = false;
                bool setRadioButtonInstance1YSecondValue = false;
                float RadioButtonInstance1YFirstValue= 0;
                float RadioButtonInstance1YSecondValue= 0;
                bool setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = false;
                bool setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = false;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue= NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                bool setRadioButtonInstance2WidthFirstValue = false;
                bool setRadioButtonInstance2WidthSecondValue = false;
                float RadioButtonInstance2WidthFirstValue= 0;
                float RadioButtonInstance2WidthSecondValue= 0;
                bool setRadioButtonInstance2YFirstValue = false;
                bool setRadioButtonInstance2YSecondValue = false;
                float RadioButtonInstance2YFirstValue= 0;
                float RadioButtonInstance2YSecondValue= 0;
                bool setResolutionBoxHeightFirstValue = false;
                bool setResolutionBoxHeightSecondValue = false;
                float ResolutionBoxHeightFirstValue= 0;
                float ResolutionBoxHeightSecondValue= 0;
                bool setResolutionBoxWidthFirstValue = false;
                bool setResolutionBoxWidthSecondValue = false;
                float ResolutionBoxWidthFirstValue= 0;
                float ResolutionBoxWidthSecondValue= 0;
                bool setSoundSliderWidthFirstValue = false;
                bool setSoundSliderWidthSecondValue = false;
                float SoundSliderWidthFirstValue= 0;
                float SoundSliderWidthSecondValue= 0;
                bool setTextBoxInstanceWidthFirstValue = false;
                bool setTextBoxInstanceWidthSecondValue = false;
                float TextBoxInstanceWidthFirstValue= 0;
                float TextBoxInstanceWidthSecondValue= 0;
                bool setTitleTextCurrentColorCategoryStateFirstValue = false;
                bool setTitleTextCurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleTextCurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleTextCurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleTextCurrentStyleCategoryStateFirstValue = false;
                bool setTitleTextCurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleTextCurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleTextCurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTitleText1CurrentColorCategoryStateFirstValue = false;
                bool setTitleText1CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText1CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText1CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleText1CurrentStyleCategoryStateFirstValue = false;
                bool setTitleText1CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText1CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText1CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                bool setTitleText2CurrentColorCategoryStateFirstValue = false;
                bool setTitleText2CurrentColorCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText2CurrentColorCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                NewGum.GumRuntimes.TextRuntime.ColorCategory TitleText2CurrentColorCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.ColorCategory.Black;
                bool setTitleText2CurrentStyleCategoryStateFirstValue = false;
                bool setTitleText2CurrentStyleCategoryStateSecondValue = false;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText2CurrentStyleCategoryStateFirstValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                NewGum.GumRuntimes.TextRuntime.StyleCategory TitleText2CurrentStyleCategoryStateSecondValue= NewGum.GumRuntimes.TextRuntime.StyleCategory.Tiny;
                switch(firstState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateFirstValue = true;
                        BackgroundCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setBackgroundCurrentStyleCategoryStateFirstValue = true;
                        BackgroundCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1CurrentColorCategoryStateFirstValue = true;
                        Background1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackground1HeightFirstValue = true;
                        Background1HeightFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setBackground1CurrentStyleCategoryStateFirstValue = true;
                        Background1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1WidthFirstValue = true;
                        Background1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackground1XFirstValue = true;
                        Background1XFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackground1YFirstValue = true;
                        Background1YFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setButtonConfirmInstance1YFirstValue = true;
                        ButtonConfirmInstance1YFirstValue = 16f;
                        setButtonContainerHeightFirstValue = true;
                        ButtonContainerHeightFirstValue = 32f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setButtonContainerWidthFirstValue = true;
                        ButtonContainerWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setButtonContainerYFirstValue = true;
                        ButtonContainerYFirstValue = 16f;
                        if (interpolationValue < 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setComboBoxInstanceWidthFirstValue = true;
                        ComboBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setContainerInstanceHeightFirstValue = true;
                        ContainerInstanceHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.Parent = this.GetGraphicalUiElementByName("Hud");
                        }
                        setContainerInstanceWidthFirstValue = true;
                        ContainerInstanceWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setContainerInstanceXFirstValue = true;
                        ContainerInstanceXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setContainerInstanceYFirstValue = true;
                        ContainerInstanceYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ControlLabel.LabelText = "Control Scheme";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setControlLabelYFirstValue = true;
                        ControlLabelYFirstValue = 8f;
                        setDemoDialogHeightFirstValue = true;
                        DemoDialogHeightFirstValue = 163f;
                        setDemoDialogWidthFirstValue = true;
                        DemoDialogWidthFirstValue = 349f;
                        setDemoDialogXFirstValue = true;
                        DemoDialogXFirstValue = 488f;
                        setDemoDialogYFirstValue = true;
                        DemoDialogYFirstValue = 42f;
                        setDemoSettingsMenuHeightFirstValue = true;
                        DemoSettingsMenuHeightFirstValue = 610f;
                        if (interpolationValue < 1)
                        {
                            this.DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoSettingsMenuWidthFirstValue = true;
                        DemoSettingsMenuWidthFirstValue = 400f;
                        setDemoSettingsMenuXFirstValue = true;
                        DemoSettingsMenuXFirstValue = 40f;
                        setDemoSettingsMenuYFirstValue = true;
                        DemoSettingsMenuYFirstValue = 35f;
                        if (interpolationValue < 1)
                        {
                            this.DifficultyLabel.LabelText = "Difficulty";
                        }
                        if (interpolationValue < 1)
                        {
                            this.DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDifficultyLabelYFirstValue = true;
                        DifficultyLabelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setDividerInstanceWidthFirstValue = true;
                        DividerInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance1WidthFirstValue = true;
                        DividerInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance1YFirstValue = true;
                        DividerInstance1YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance2WidthFirstValue = true;
                        DividerInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance2YFirstValue = true;
                        DividerInstance2YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance3WidthFirstValue = true;
                        DividerInstance3WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance3YFirstValue = true;
                        DividerInstance3YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setDividerInstance4WidthFirstValue = true;
                        DividerInstance4WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setDividerInstance5WidthFirstValue = true;
                        DividerInstance5WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue < 1)
                        {
                            this.DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue < 1)
                        {
                            this.FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                        }
                        if (interpolationValue < 1)
                        {
                            this.FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setFullScreenCheckboxYFirstValue = true;
                        FullScreenCheckboxYFirstValue = 4f;
                        setHudCurrentColorCategoryStateFirstValue = true;
                        HudCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setHudHeightFirstValue = true;
                        HudHeightFirstValue = 207f;
                        if (interpolationValue < 1)
                        {
                            this.Hud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHudCurrentStyleCategoryStateFirstValue = true;
                        HudCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setHudWidthFirstValue = true;
                        HudWidthFirstValue = 279f;
                        if (interpolationValue < 1)
                        {
                            this.Hud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHudXFirstValue = true;
                        HudXFirstValue = -331f;
                        setHudYFirstValue = true;
                        HudYFirstValue = -176f;
                        if (interpolationValue < 1)
                        {
                            this.LabelInstance.LabelText = "New Profile Name";
                        }
                        if (interpolationValue < 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setLabelInstanceYFirstValue = true;
                        LabelInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMarginContainerHeightFirstValue = true;
                        MarginContainerHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setMarginContainerWidthFirstValue = true;
                        MarginContainerWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMarginContainerXFirstValue = true;
                        MarginContainerXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMarginContainerYFirstValue = true;
                        MarginContainerYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMenuItemsHeightFirstValue = true;
                        MenuItemsHeightFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setMenuItemsWidthFirstValue = true;
                        MenuItemsWidthFirstValue = -16f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuItemsXFirstValue = true;
                        MenuItemsXFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuItemsYFirstValue = true;
                        MenuItemsYFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuTitleHeightFirstValue = true;
                        MenuTitleHeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMenuTitleWidthFirstValue = true;
                        MenuTitleWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle1HeightFirstValue = true;
                        MenuTitle1HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setMenuTitle1WidthFirstValue = true;
                        MenuTitle1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle2HeightFirstValue = true;
                        MenuTitle2HeightFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setMenuTitle2WidthFirstValue = true;
                        MenuTitle2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.MusicLabel.LabelText = "Music Volume";
                        }
                        if (interpolationValue < 1)
                        {
                            this.MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicLabelYFirstValue = true;
                        MusicLabelYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicSliderWidthFirstValue = true;
                        MusicSliderWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstanceWidthFirstValue = true;
                        PercentBarInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstanceYFirstValue = true;
                        PercentBarInstanceYFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance1WidthFirstValue = true;
                        PercentBarInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance1YFirstValue = true;
                        PercentBarInstance1YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance2WidthFirstValue = true;
                        PercentBarInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance2YFirstValue = true;
                        PercentBarInstance2YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance3WidthFirstValue = true;
                        PercentBarInstance3WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance3YFirstValue = true;
                        PercentBarInstance3YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance4WidthFirstValue = true;
                        PercentBarInstance4WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance4YFirstValue = true;
                        PercentBarInstance4YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance5WidthFirstValue = true;
                        PercentBarInstance5WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance5YFirstValue = true;
                        PercentBarInstance5YFirstValue = 8f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                        }
                        setRadioButtonInstanceWidthFirstValue = true;
                        RadioButtonInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.RadioDisplayText = "Gamepad";
                        }
                        setRadioButtonInstance1WidthFirstValue = true;
                        RadioButtonInstance1WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance1YFirstValue = true;
                        RadioButtonInstance1YFirstValue = 4f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = true;
                        RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                        }
                        setRadioButtonInstance2WidthFirstValue = true;
                        RadioButtonInstance2WidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance2YFirstValue = true;
                        RadioButtonInstance2YFirstValue = 4f;
                        setResolutionBoxHeightFirstValue = true;
                        ResolutionBoxHeightFirstValue = 128f;
                        if (interpolationValue < 1)
                        {
                            this.ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setResolutionBoxWidthFirstValue = true;
                        ResolutionBoxWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.ResolutionLabel.LabelText = "Resolution";
                        }
                        if (interpolationValue < 1)
                        {
                            this.ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundLabel.LabelText = "Sound Volume";
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue < 1)
                        {
                            this.SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setSoundSliderWidthFirstValue = true;
                        SoundSliderWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue < 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setTextBoxInstanceWidthFirstValue = true;
                        TextBoxInstanceWidthFirstValue = 0f;
                        if (interpolationValue < 1)
                        {
                            this.TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTitleTextCurrentColorCategoryStateFirstValue = true;
                        TitleTextCurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setTitleTextCurrentStyleCategoryStateFirstValue = true;
                        TitleTextCurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText.Text = "Settings";
                        }
                        setTitleText1CurrentColorCategoryStateFirstValue = true;
                        TitleText1CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setTitleText1CurrentStyleCategoryStateFirstValue = true;
                        TitleText1CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText1.Text = "New Profile";
                        }
                        setTitleText2CurrentColorCategoryStateFirstValue = true;
                        TitleText2CurrentColorCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue < 1)
                        {
                            this.TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setTitleText2CurrentStyleCategoryStateFirstValue = true;
                        TitleText2CurrentStyleCategoryStateFirstValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue < 1)
                        {
                            this.TitleText2.Text = "HUD Demo";
                        }
                        break;
                }
                switch(secondState)
                {
                    case  VariableState.Default:
                        setBackgroundCurrentColorCategoryStateSecondValue = true;
                        BackgroundCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.Background.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setBackgroundCurrentStyleCategoryStateSecondValue = true;
                        BackgroundCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1CurrentColorCategoryStateSecondValue = true;
                        Background1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setBackground1HeightSecondValue = true;
                        Background1HeightSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setBackground1CurrentStyleCategoryStateSecondValue = true;
                        Background1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setBackground1WidthSecondValue = true;
                        Background1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setBackground1XSecondValue = true;
                        Background1XSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setBackground1YSecondValue = true;
                        Background1YSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.Background1.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.Background1.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonCloseInstance2.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Right;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ButtonConfirmInstance1.XUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        setButtonConfirmInstance1YSecondValue = true;
                        ButtonConfirmInstance1YSecondValue = 16f;
                        setButtonContainerHeightSecondValue = true;
                        ButtonContainerHeightSecondValue = 32f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonContainer.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setButtonContainerWidthSecondValue = true;
                        ButtonContainerWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setButtonContainerYSecondValue = true;
                        ButtonContainerYSecondValue = 16f;
                        if (interpolationValue >= 1)
                        {
                            this.ButtonDenyInstance.Parent = this.GetGraphicalUiElementByName("ButtonContainer");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setComboBoxInstanceWidthSecondValue = true;
                        ComboBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ComboBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setContainerInstanceHeightSecondValue = true;
                        ContainerInstanceHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.Parent = this.GetGraphicalUiElementByName("Hud");
                        }
                        setContainerInstanceWidthSecondValue = true;
                        ContainerInstanceWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setContainerInstanceXSecondValue = true;
                        ContainerInstanceXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setContainerInstanceYSecondValue = true;
                        ContainerInstanceYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ContainerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ControlLabel.LabelText = "Control Scheme";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ControlLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setControlLabelYSecondValue = true;
                        ControlLabelYSecondValue = 8f;
                        setDemoDialogHeightSecondValue = true;
                        DemoDialogHeightSecondValue = 163f;
                        setDemoDialogWidthSecondValue = true;
                        DemoDialogWidthSecondValue = 349f;
                        setDemoDialogXSecondValue = true;
                        DemoDialogXSecondValue = 488f;
                        setDemoDialogYSecondValue = true;
                        DemoDialogYSecondValue = 42f;
                        setDemoSettingsMenuHeightSecondValue = true;
                        DemoSettingsMenuHeightSecondValue = 610f;
                        if (interpolationValue >= 1)
                        {
                            this.DemoSettingsMenu.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setDemoSettingsMenuWidthSecondValue = true;
                        DemoSettingsMenuWidthSecondValue = 400f;
                        setDemoSettingsMenuXSecondValue = true;
                        DemoSettingsMenuXSecondValue = 40f;
                        setDemoSettingsMenuYSecondValue = true;
                        DemoSettingsMenuYSecondValue = 35f;
                        if (interpolationValue >= 1)
                        {
                            this.DifficultyLabel.LabelText = "Difficulty";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DifficultyLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDifficultyLabelYSecondValue = true;
                        DifficultyLabelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setDividerInstanceWidthSecondValue = true;
                        DividerInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance1WidthSecondValue = true;
                        DividerInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance1YSecondValue = true;
                        DividerInstance1YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance2WidthSecondValue = true;
                        DividerInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance2YSecondValue = true;
                        DividerInstance2YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance3.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setDividerInstance3WidthSecondValue = true;
                        DividerInstance3WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setDividerInstance3YSecondValue = true;
                        DividerInstance3YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setDividerInstance4WidthSecondValue = true;
                        DividerInstance4WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance4.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setDividerInstance5WidthSecondValue = true;
                        DividerInstance5WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Bottom;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.DividerInstance5.YUnits = Gum.Converters.GeneralUnitType.PixelsFromLarge;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FullScreenCheckbox.CheckboxDisplayText = "Run Fullscreen";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.FullScreenCheckbox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setFullScreenCheckboxYSecondValue = true;
                        FullScreenCheckboxYSecondValue = 4f;
                        setHudCurrentColorCategoryStateSecondValue = true;
                        HudCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Primary;
                        setHudHeightSecondValue = true;
                        HudHeightSecondValue = 207f;
                        if (interpolationValue >= 1)
                        {
                            this.Hud.HeightUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHudCurrentStyleCategoryStateSecondValue = true;
                        HudCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.NineSliceRuntime.StyleCategory.Panel;
                        setHudWidthSecondValue = true;
                        HudWidthSecondValue = 279f;
                        if (interpolationValue >= 1)
                        {
                            this.Hud.WidthUnits = Gum.DataTypes.DimensionUnitType.Absolute;
                        }
                        setHudXSecondValue = true;
                        HudXSecondValue = -331f;
                        setHudYSecondValue = true;
                        HudYSecondValue = -176f;
                        if (interpolationValue >= 1)
                        {
                            this.LabelInstance.LabelText = "New Profile Name";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.LabelInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setLabelInstanceYSecondValue = true;
                        LabelInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMarginContainerHeightSecondValue = true;
                        MarginContainerHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.Parent = this.GetGraphicalUiElementByName("DemoDialog");
                        }
                        setMarginContainerWidthSecondValue = true;
                        MarginContainerWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMarginContainerXSecondValue = true;
                        MarginContainerXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMarginContainerYSecondValue = true;
                        MarginContainerYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MarginContainer.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.ChildrenLayout = Gum.Managers.ChildrenLayout.TopToBottomStack;
                        }
                        setMenuItemsHeightSecondValue = true;
                        MenuItemsHeightSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.Parent = this.GetGraphicalUiElementByName("DemoSettingsMenu");
                        }
                        setMenuItemsWidthSecondValue = true;
                        MenuItemsWidthSecondValue = -16f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuItemsXSecondValue = true;
                        MenuItemsXSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.XOrigin = RenderingLibrary.Graphics.HorizontalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.XUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuItemsYSecondValue = true;
                        MenuItemsYSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.YOrigin = RenderingLibrary.Graphics.VerticalAlignment.Center;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuItems.YUnits = Gum.Converters.GeneralUnitType.PixelsFromMiddle;
                        }
                        setMenuTitleHeightSecondValue = true;
                        MenuTitleHeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMenuTitleWidthSecondValue = true;
                        MenuTitleWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle1HeightSecondValue = true;
                        MenuTitle1HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setMenuTitle1WidthSecondValue = true;
                        MenuTitle1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setMenuTitle2HeightSecondValue = true;
                        MenuTitle2HeightSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.HeightUnits = Gum.DataTypes.DimensionUnitType.RelativeToChildren;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setMenuTitle2WidthSecondValue = true;
                        MenuTitle2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MenuTitle2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MusicLabel.LabelText = "Music Volume";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.MusicLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicLabelYSecondValue = true;
                        MusicLabelYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.MusicSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setMusicSliderWidthSecondValue = true;
                        MusicSliderWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.MusicSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstanceWidthSecondValue = true;
                        PercentBarInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstanceYSecondValue = true;
                        PercentBarInstanceYSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Success;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance1WidthSecondValue = true;
                        PercentBarInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance1YSecondValue = true;
                        PercentBarInstance1YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Warning;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance2WidthSecondValue = true;
                        PercentBarInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance2YSecondValue = true;
                        PercentBarInstance2YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance3WidthSecondValue = true;
                        PercentBarInstance3WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance3.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance3YSecondValue = true;
                        PercentBarInstance3YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Accent;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance4WidthSecondValue = true;
                        PercentBarInstance4WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance4.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance4YSecondValue = true;
                        PercentBarInstance4YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.BarColor = NewGum.GumRuntimes.NineSliceRuntime.ColorCategory.Danger;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.Parent = this.GetGraphicalUiElementByName("ContainerInstance");
                        }
                        setPercentBarInstance5WidthSecondValue = true;
                        PercentBarInstance5WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.PercentBarInstance5.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setPercentBarInstance5YSecondValue = true;
                        PercentBarInstance5YSecondValue = 8f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.RadioDisplayText = "Keyboard & Mouse";
                        }
                        setRadioButtonInstanceWidthSecondValue = true;
                        RadioButtonInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOn;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.RadioDisplayText = "Gamepad";
                        }
                        setRadioButtonInstance1WidthSecondValue = true;
                        RadioButtonInstance1WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance1.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance1YSecondValue = true;
                        RadioButtonInstance1YSecondValue = 4f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = true;
                        RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue = NewGum.GumRuntimes.Controls.RadioButtonRuntime.RadioButtonCategory.EnabledOff;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.RadioDisplayText = "Touchscreen";
                        }
                        setRadioButtonInstance2WidthSecondValue = true;
                        RadioButtonInstance2WidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.RadioButtonInstance2.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setRadioButtonInstance2YSecondValue = true;
                        RadioButtonInstance2YSecondValue = 4f;
                        setResolutionBoxHeightSecondValue = true;
                        ResolutionBoxHeightSecondValue = 128f;
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionBox.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setResolutionBoxWidthSecondValue = true;
                        ResolutionBoxWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionBox.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionLabel.LabelText = "Resolution";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.ResolutionLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundLabel.LabelText = "Sound Volume";
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundLabel.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        if (interpolationValue >= 1)
                        {
                            this.SoundSlider.Parent = this.GetGraphicalUiElementByName("MenuItems");
                        }
                        setSoundSliderWidthSecondValue = true;
                        SoundSliderWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.SoundSlider.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        if (interpolationValue >= 1)
                        {
                            this.TextBoxInstance.Parent = this.GetGraphicalUiElementByName("MarginContainer");
                        }
                        setTextBoxInstanceWidthSecondValue = true;
                        TextBoxInstanceWidthSecondValue = 0f;
                        if (interpolationValue >= 1)
                        {
                            this.TextBoxInstance.WidthUnits = Gum.DataTypes.DimensionUnitType.RelativeToContainer;
                        }
                        setTitleTextCurrentColorCategoryStateSecondValue = true;
                        TitleTextCurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText.Parent = this.GetGraphicalUiElementByName("MenuTitle");
                        }
                        setTitleTextCurrentStyleCategoryStateSecondValue = true;
                        TitleTextCurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText.Text = "Settings";
                        }
                        setTitleText1CurrentColorCategoryStateSecondValue = true;
                        TitleText1CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText1.Parent = this.GetGraphicalUiElementByName("MenuTitle1");
                        }
                        setTitleText1CurrentStyleCategoryStateSecondValue = true;
                        TitleText1CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText1.Text = "New Profile";
                        }
                        setTitleText2CurrentColorCategoryStateSecondValue = true;
                        TitleText2CurrentColorCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.ColorCategory.Primary;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText2.Parent = this.GetGraphicalUiElementByName("MenuTitle2");
                        }
                        setTitleText2CurrentStyleCategoryStateSecondValue = true;
                        TitleText2CurrentStyleCategoryStateSecondValue = NewGum.GumRuntimes.TextRuntime.StyleCategory.Title;
                        if (interpolationValue >= 1)
                        {
                            this.TitleText2.Text = "HUD Demo";
                        }
                        break;
                }
                var wasSuppressed = mIsLayoutSuspended;
                if (wasSuppressed == false)
                {
                    SuspendLayout(true);
                }
                if (setBackgroundCurrentColorCategoryStateFirstValue && setBackgroundCurrentColorCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentColorCategoryStateFirstValue, BackgroundCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackgroundCurrentStyleCategoryStateFirstValue && setBackgroundCurrentStyleCategoryStateSecondValue)
                {
                    Background.InterpolateBetween(BackgroundCurrentStyleCategoryStateFirstValue, BackgroundCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1CurrentColorCategoryStateFirstValue && setBackground1CurrentColorCategoryStateSecondValue)
                {
                    Background1.InterpolateBetween(Background1CurrentColorCategoryStateFirstValue, Background1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1HeightFirstValue && setBackground1HeightSecondValue)
                {
                    Background1.Height = Background1HeightFirstValue * (1 - interpolationValue) + Background1HeightSecondValue * interpolationValue;
                }
                if (setBackground1CurrentStyleCategoryStateFirstValue && setBackground1CurrentStyleCategoryStateSecondValue)
                {
                    Background1.InterpolateBetween(Background1CurrentStyleCategoryStateFirstValue, Background1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setBackground1WidthFirstValue && setBackground1WidthSecondValue)
                {
                    Background1.Width = Background1WidthFirstValue * (1 - interpolationValue) + Background1WidthSecondValue * interpolationValue;
                }
                if (setBackground1XFirstValue && setBackground1XSecondValue)
                {
                    Background1.X = Background1XFirstValue * (1 - interpolationValue) + Background1XSecondValue * interpolationValue;
                }
                if (setBackground1YFirstValue && setBackground1YSecondValue)
                {
                    Background1.Y = Background1YFirstValue * (1 - interpolationValue) + Background1YSecondValue * interpolationValue;
                }
                if (setButtonConfirmInstance1YFirstValue && setButtonConfirmInstance1YSecondValue)
                {
                    ButtonConfirmInstance1.Y = ButtonConfirmInstance1YFirstValue * (1 - interpolationValue) + ButtonConfirmInstance1YSecondValue * interpolationValue;
                }
                if (setButtonContainerHeightFirstValue && setButtonContainerHeightSecondValue)
                {
                    ButtonContainer.Height = ButtonContainerHeightFirstValue * (1 - interpolationValue) + ButtonContainerHeightSecondValue * interpolationValue;
                }
                if (setButtonContainerWidthFirstValue && setButtonContainerWidthSecondValue)
                {
                    ButtonContainer.Width = ButtonContainerWidthFirstValue * (1 - interpolationValue) + ButtonContainerWidthSecondValue * interpolationValue;
                }
                if (setButtonContainerYFirstValue && setButtonContainerYSecondValue)
                {
                    ButtonContainer.Y = ButtonContainerYFirstValue * (1 - interpolationValue) + ButtonContainerYSecondValue * interpolationValue;
                }
                if (setComboBoxInstanceWidthFirstValue && setComboBoxInstanceWidthSecondValue)
                {
                    ComboBoxInstance.Width = ComboBoxInstanceWidthFirstValue * (1 - interpolationValue) + ComboBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setContainerInstanceHeightFirstValue && setContainerInstanceHeightSecondValue)
                {
                    ContainerInstance.Height = ContainerInstanceHeightFirstValue * (1 - interpolationValue) + ContainerInstanceHeightSecondValue * interpolationValue;
                }
                if (setContainerInstanceWidthFirstValue && setContainerInstanceWidthSecondValue)
                {
                    ContainerInstance.Width = ContainerInstanceWidthFirstValue * (1 - interpolationValue) + ContainerInstanceWidthSecondValue * interpolationValue;
                }
                if (setContainerInstanceXFirstValue && setContainerInstanceXSecondValue)
                {
                    ContainerInstance.X = ContainerInstanceXFirstValue * (1 - interpolationValue) + ContainerInstanceXSecondValue * interpolationValue;
                }
                if (setContainerInstanceYFirstValue && setContainerInstanceYSecondValue)
                {
                    ContainerInstance.Y = ContainerInstanceYFirstValue * (1 - interpolationValue) + ContainerInstanceYSecondValue * interpolationValue;
                }
                if (setControlLabelYFirstValue && setControlLabelYSecondValue)
                {
                    ControlLabel.Y = ControlLabelYFirstValue * (1 - interpolationValue) + ControlLabelYSecondValue * interpolationValue;
                }
                if (setDemoDialogHeightFirstValue && setDemoDialogHeightSecondValue)
                {
                    DemoDialog.Height = DemoDialogHeightFirstValue * (1 - interpolationValue) + DemoDialogHeightSecondValue * interpolationValue;
                }
                if (setDemoDialogWidthFirstValue && setDemoDialogWidthSecondValue)
                {
                    DemoDialog.Width = DemoDialogWidthFirstValue * (1 - interpolationValue) + DemoDialogWidthSecondValue * interpolationValue;
                }
                if (setDemoDialogXFirstValue && setDemoDialogXSecondValue)
                {
                    DemoDialog.X = DemoDialogXFirstValue * (1 - interpolationValue) + DemoDialogXSecondValue * interpolationValue;
                }
                if (setDemoDialogYFirstValue && setDemoDialogYSecondValue)
                {
                    DemoDialog.Y = DemoDialogYFirstValue * (1 - interpolationValue) + DemoDialogYSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuHeightFirstValue && setDemoSettingsMenuHeightSecondValue)
                {
                    DemoSettingsMenu.Height = DemoSettingsMenuHeightFirstValue * (1 - interpolationValue) + DemoSettingsMenuHeightSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuWidthFirstValue && setDemoSettingsMenuWidthSecondValue)
                {
                    DemoSettingsMenu.Width = DemoSettingsMenuWidthFirstValue * (1 - interpolationValue) + DemoSettingsMenuWidthSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuXFirstValue && setDemoSettingsMenuXSecondValue)
                {
                    DemoSettingsMenu.X = DemoSettingsMenuXFirstValue * (1 - interpolationValue) + DemoSettingsMenuXSecondValue * interpolationValue;
                }
                if (setDemoSettingsMenuYFirstValue && setDemoSettingsMenuYSecondValue)
                {
                    DemoSettingsMenu.Y = DemoSettingsMenuYFirstValue * (1 - interpolationValue) + DemoSettingsMenuYSecondValue * interpolationValue;
                }
                if (setDifficultyLabelYFirstValue && setDifficultyLabelYSecondValue)
                {
                    DifficultyLabel.Y = DifficultyLabelYFirstValue * (1 - interpolationValue) + DifficultyLabelYSecondValue * interpolationValue;
                }
                if (setDividerInstanceWidthFirstValue && setDividerInstanceWidthSecondValue)
                {
                    DividerInstance.Width = DividerInstanceWidthFirstValue * (1 - interpolationValue) + DividerInstanceWidthSecondValue * interpolationValue;
                }
                if (setDividerInstance1WidthFirstValue && setDividerInstance1WidthSecondValue)
                {
                    DividerInstance1.Width = DividerInstance1WidthFirstValue * (1 - interpolationValue) + DividerInstance1WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance1YFirstValue && setDividerInstance1YSecondValue)
                {
                    DividerInstance1.Y = DividerInstance1YFirstValue * (1 - interpolationValue) + DividerInstance1YSecondValue * interpolationValue;
                }
                if (setDividerInstance2WidthFirstValue && setDividerInstance2WidthSecondValue)
                {
                    DividerInstance2.Width = DividerInstance2WidthFirstValue * (1 - interpolationValue) + DividerInstance2WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance2YFirstValue && setDividerInstance2YSecondValue)
                {
                    DividerInstance2.Y = DividerInstance2YFirstValue * (1 - interpolationValue) + DividerInstance2YSecondValue * interpolationValue;
                }
                if (setDividerInstance3WidthFirstValue && setDividerInstance3WidthSecondValue)
                {
                    DividerInstance3.Width = DividerInstance3WidthFirstValue * (1 - interpolationValue) + DividerInstance3WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance3YFirstValue && setDividerInstance3YSecondValue)
                {
                    DividerInstance3.Y = DividerInstance3YFirstValue * (1 - interpolationValue) + DividerInstance3YSecondValue * interpolationValue;
                }
                if (setDividerInstance4WidthFirstValue && setDividerInstance4WidthSecondValue)
                {
                    DividerInstance4.Width = DividerInstance4WidthFirstValue * (1 - interpolationValue) + DividerInstance4WidthSecondValue * interpolationValue;
                }
                if (setDividerInstance5WidthFirstValue && setDividerInstance5WidthSecondValue)
                {
                    DividerInstance5.Width = DividerInstance5WidthFirstValue * (1 - interpolationValue) + DividerInstance5WidthSecondValue * interpolationValue;
                }
                if (setFullScreenCheckboxYFirstValue && setFullScreenCheckboxYSecondValue)
                {
                    FullScreenCheckbox.Y = FullScreenCheckboxYFirstValue * (1 - interpolationValue) + FullScreenCheckboxYSecondValue * interpolationValue;
                }
                if (setHudCurrentColorCategoryStateFirstValue && setHudCurrentColorCategoryStateSecondValue)
                {
                    Hud.InterpolateBetween(HudCurrentColorCategoryStateFirstValue, HudCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setHudHeightFirstValue && setHudHeightSecondValue)
                {
                    Hud.Height = HudHeightFirstValue * (1 - interpolationValue) + HudHeightSecondValue * interpolationValue;
                }
                if (setHudCurrentStyleCategoryStateFirstValue && setHudCurrentStyleCategoryStateSecondValue)
                {
                    Hud.InterpolateBetween(HudCurrentStyleCategoryStateFirstValue, HudCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setHudWidthFirstValue && setHudWidthSecondValue)
                {
                    Hud.Width = HudWidthFirstValue * (1 - interpolationValue) + HudWidthSecondValue * interpolationValue;
                }
                if (setHudXFirstValue && setHudXSecondValue)
                {
                    Hud.X = HudXFirstValue * (1 - interpolationValue) + HudXSecondValue * interpolationValue;
                }
                if (setHudYFirstValue && setHudYSecondValue)
                {
                    Hud.Y = HudYFirstValue * (1 - interpolationValue) + HudYSecondValue * interpolationValue;
                }
                if (setLabelInstanceYFirstValue && setLabelInstanceYSecondValue)
                {
                    LabelInstance.Y = LabelInstanceYFirstValue * (1 - interpolationValue) + LabelInstanceYSecondValue * interpolationValue;
                }
                if (setMarginContainerHeightFirstValue && setMarginContainerHeightSecondValue)
                {
                    MarginContainer.Height = MarginContainerHeightFirstValue * (1 - interpolationValue) + MarginContainerHeightSecondValue * interpolationValue;
                }
                if (setMarginContainerWidthFirstValue && setMarginContainerWidthSecondValue)
                {
                    MarginContainer.Width = MarginContainerWidthFirstValue * (1 - interpolationValue) + MarginContainerWidthSecondValue * interpolationValue;
                }
                if (setMarginContainerXFirstValue && setMarginContainerXSecondValue)
                {
                    MarginContainer.X = MarginContainerXFirstValue * (1 - interpolationValue) + MarginContainerXSecondValue * interpolationValue;
                }
                if (setMarginContainerYFirstValue && setMarginContainerYSecondValue)
                {
                    MarginContainer.Y = MarginContainerYFirstValue * (1 - interpolationValue) + MarginContainerYSecondValue * interpolationValue;
                }
                if (setMenuItemsHeightFirstValue && setMenuItemsHeightSecondValue)
                {
                    MenuItems.Height = MenuItemsHeightFirstValue * (1 - interpolationValue) + MenuItemsHeightSecondValue * interpolationValue;
                }
                if (setMenuItemsWidthFirstValue && setMenuItemsWidthSecondValue)
                {
                    MenuItems.Width = MenuItemsWidthFirstValue * (1 - interpolationValue) + MenuItemsWidthSecondValue * interpolationValue;
                }
                if (setMenuItemsXFirstValue && setMenuItemsXSecondValue)
                {
                    MenuItems.X = MenuItemsXFirstValue * (1 - interpolationValue) + MenuItemsXSecondValue * interpolationValue;
                }
                if (setMenuItemsYFirstValue && setMenuItemsYSecondValue)
                {
                    MenuItems.Y = MenuItemsYFirstValue * (1 - interpolationValue) + MenuItemsYSecondValue * interpolationValue;
                }
                if (setMenuTitleHeightFirstValue && setMenuTitleHeightSecondValue)
                {
                    MenuTitle.Height = MenuTitleHeightFirstValue * (1 - interpolationValue) + MenuTitleHeightSecondValue * interpolationValue;
                }
                if (setMenuTitleWidthFirstValue && setMenuTitleWidthSecondValue)
                {
                    MenuTitle.Width = MenuTitleWidthFirstValue * (1 - interpolationValue) + MenuTitleWidthSecondValue * interpolationValue;
                }
                if (setMenuTitle1HeightFirstValue && setMenuTitle1HeightSecondValue)
                {
                    MenuTitle1.Height = MenuTitle1HeightFirstValue * (1 - interpolationValue) + MenuTitle1HeightSecondValue * interpolationValue;
                }
                if (setMenuTitle1WidthFirstValue && setMenuTitle1WidthSecondValue)
                {
                    MenuTitle1.Width = MenuTitle1WidthFirstValue * (1 - interpolationValue) + MenuTitle1WidthSecondValue * interpolationValue;
                }
                if (setMenuTitle2HeightFirstValue && setMenuTitle2HeightSecondValue)
                {
                    MenuTitle2.Height = MenuTitle2HeightFirstValue * (1 - interpolationValue) + MenuTitle2HeightSecondValue * interpolationValue;
                }
                if (setMenuTitle2WidthFirstValue && setMenuTitle2WidthSecondValue)
                {
                    MenuTitle2.Width = MenuTitle2WidthFirstValue * (1 - interpolationValue) + MenuTitle2WidthSecondValue * interpolationValue;
                }
                if (setMusicLabelYFirstValue && setMusicLabelYSecondValue)
                {
                    MusicLabel.Y = MusicLabelYFirstValue * (1 - interpolationValue) + MusicLabelYSecondValue * interpolationValue;
                }
                if (setMusicSliderWidthFirstValue && setMusicSliderWidthSecondValue)
                {
                    MusicSlider.Width = MusicSliderWidthFirstValue * (1 - interpolationValue) + MusicSliderWidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstanceWidthFirstValue && setPercentBarInstanceWidthSecondValue)
                {
                    PercentBarInstance.Width = PercentBarInstanceWidthFirstValue * (1 - interpolationValue) + PercentBarInstanceWidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstanceYFirstValue && setPercentBarInstanceYSecondValue)
                {
                    PercentBarInstance.Y = PercentBarInstanceYFirstValue * (1 - interpolationValue) + PercentBarInstanceYSecondValue * interpolationValue;
                }
                if (setPercentBarInstance1WidthFirstValue && setPercentBarInstance1WidthSecondValue)
                {
                    PercentBarInstance1.Width = PercentBarInstance1WidthFirstValue * (1 - interpolationValue) + PercentBarInstance1WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance1YFirstValue && setPercentBarInstance1YSecondValue)
                {
                    PercentBarInstance1.Y = PercentBarInstance1YFirstValue * (1 - interpolationValue) + PercentBarInstance1YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance2WidthFirstValue && setPercentBarInstance2WidthSecondValue)
                {
                    PercentBarInstance2.Width = PercentBarInstance2WidthFirstValue * (1 - interpolationValue) + PercentBarInstance2WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance2YFirstValue && setPercentBarInstance2YSecondValue)
                {
                    PercentBarInstance2.Y = PercentBarInstance2YFirstValue * (1 - interpolationValue) + PercentBarInstance2YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance3WidthFirstValue && setPercentBarInstance3WidthSecondValue)
                {
                    PercentBarInstance3.Width = PercentBarInstance3WidthFirstValue * (1 - interpolationValue) + PercentBarInstance3WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance3YFirstValue && setPercentBarInstance3YSecondValue)
                {
                    PercentBarInstance3.Y = PercentBarInstance3YFirstValue * (1 - interpolationValue) + PercentBarInstance3YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance4WidthFirstValue && setPercentBarInstance4WidthSecondValue)
                {
                    PercentBarInstance4.Width = PercentBarInstance4WidthFirstValue * (1 - interpolationValue) + PercentBarInstance4WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance4YFirstValue && setPercentBarInstance4YSecondValue)
                {
                    PercentBarInstance4.Y = PercentBarInstance4YFirstValue * (1 - interpolationValue) + PercentBarInstance4YSecondValue * interpolationValue;
                }
                if (setPercentBarInstance5WidthFirstValue && setPercentBarInstance5WidthSecondValue)
                {
                    PercentBarInstance5.Width = PercentBarInstance5WidthFirstValue * (1 - interpolationValue) + PercentBarInstance5WidthSecondValue * interpolationValue;
                }
                if (setPercentBarInstance5YFirstValue && setPercentBarInstance5YSecondValue)
                {
                    PercentBarInstance5.Y = PercentBarInstance5YFirstValue * (1 - interpolationValue) + PercentBarInstance5YSecondValue * interpolationValue;
                }
                if (setRadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance.InterpolateBetween(RadioButtonInstanceCurrentRadioButtonCategoryStateFirstValue, RadioButtonInstanceCurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstanceWidthFirstValue && setRadioButtonInstanceWidthSecondValue)
                {
                    RadioButtonInstance.Width = RadioButtonInstanceWidthFirstValue * (1 - interpolationValue) + RadioButtonInstanceWidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance1.InterpolateBetween(RadioButtonInstance1CurrentRadioButtonCategoryStateFirstValue, RadioButtonInstance1CurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstance1WidthFirstValue && setRadioButtonInstance1WidthSecondValue)
                {
                    RadioButtonInstance1.Width = RadioButtonInstance1WidthFirstValue * (1 - interpolationValue) + RadioButtonInstance1WidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance1YFirstValue && setRadioButtonInstance1YSecondValue)
                {
                    RadioButtonInstance1.Y = RadioButtonInstance1YFirstValue * (1 - interpolationValue) + RadioButtonInstance1YSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue && setRadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue)
                {
                    RadioButtonInstance2.InterpolateBetween(RadioButtonInstance2CurrentRadioButtonCategoryStateFirstValue, RadioButtonInstance2CurrentRadioButtonCategoryStateSecondValue, interpolationValue);
                }
                if (setRadioButtonInstance2WidthFirstValue && setRadioButtonInstance2WidthSecondValue)
                {
                    RadioButtonInstance2.Width = RadioButtonInstance2WidthFirstValue * (1 - interpolationValue) + RadioButtonInstance2WidthSecondValue * interpolationValue;
                }
                if (setRadioButtonInstance2YFirstValue && setRadioButtonInstance2YSecondValue)
                {
                    RadioButtonInstance2.Y = RadioButtonInstance2YFirstValue * (1 - interpolationValue) + RadioButtonInstance2YSecondValue * interpolationValue;
                }
                if (setResolutionBoxHeightFirstValue && setResolutionBoxHeightSecondValue)
                {
                    ResolutionBox.Height = ResolutionBoxHeightFirstValue * (1 - interpolationValue) + ResolutionBoxHeightSecondValue * interpolationValue;
                }
                if (setResolutionBoxWidthFirstValue && setResolutionBoxWidthSecondValue)
                {
                    ResolutionBox.Width = ResolutionBoxWidthFirstValue * (1 - interpolationValue) + ResolutionBoxWidthSecondValue * interpolationValue;
                }
                if (setSoundSliderWidthFirstValue && setSoundSliderWidthSecondValue)
                {
                    SoundSlider.Width = SoundSliderWidthFirstValue * (1 - interpolationValue) + SoundSliderWidthSecondValue * interpolationValue;
                }
                if (setTextBoxInstanceWidthFirstValue && setTextBoxInstanceWidthSecondValue)
                {
                    TextBoxInstance.Width = TextBoxInstanceWidthFirstValue * (1 - interpolationValue) + TextBoxInstanceWidthSecondValue * interpolationValue;
                }
                if (setTitleTextCurrentColorCategoryStateFirstValue && setTitleTextCurrentColorCategoryStateSecondValue)
                {
                    TitleText.InterpolateBetween(TitleTextCurrentColorCategoryStateFirstValue, TitleTextCurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleTextCurrentStyleCategoryStateFirstValue && setTitleTextCurrentStyleCategoryStateSecondValue)
                {
                    TitleText.InterpolateBetween(TitleTextCurrentStyleCategoryStateFirstValue, TitleTextCurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText1CurrentColorCategoryStateFirstValue && setTitleText1CurrentColorCategoryStateSecondValue)
                {
                    TitleText1.InterpolateBetween(TitleText1CurrentColorCategoryStateFirstValue, TitleText1CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText1CurrentStyleCategoryStateFirstValue && setTitleText1CurrentStyleCategoryStateSecondValue)
                {
                    TitleText1.InterpolateBetween(TitleText1CurrentStyleCategoryStateFirstValue, TitleText1CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText2CurrentColorCategoryStateFirstValue && setTitleText2CurrentColorCategoryStateSecondValue)
                {
                    TitleText2.InterpolateBetween(TitleText2CurrentColorCategoryStateFirstValue, TitleText2CurrentColorCategoryStateSecondValue, interpolationValue);
                }
                if (setTitleText2CurrentStyleCategoryStateFirstValue && setTitleText2CurrentStyleCategoryStateSecondValue)
                {
                    TitleText2.InterpolateBetween(TitleText2CurrentStyleCategoryStateFirstValue, TitleText2CurrentStyleCategoryStateSecondValue, interpolationValue);
                }
                if (interpolationValue < 1)
                {
                    mCurrentVariableState = firstState;
                }
                else
                {
                    mCurrentVariableState = secondState;
                }
                if (!wasSuppressed)
                {
                    ResumeLayout(true);
                }
            }
            #endregion
            #region State Interpolate To
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (NewGum.GumRuntimes.DemoScreenRuntime.VariableState fromState,NewGum.GumRuntimes.DemoScreenRuntime.VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null) 
            {
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from:0, to:1, duration:(float)secondsToTake, type:interpolationType, easing:easing );
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(fromState, toState, newPosition);
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateTo (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = this.ElementSave.States.First(item => item.Name == toState.ToString());
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            public FlatRedBall.Glue.StateInterpolation.Tweener InterpolateToRelative (VariableState toState, double secondsToTake, FlatRedBall.Glue.StateInterpolation.InterpolationType interpolationType, FlatRedBall.Glue.StateInterpolation.Easing easing, object owner = null ) 
            {
                Gum.DataTypes.Variables.StateSave current = GetCurrentValuesOnState(toState);
                Gum.DataTypes.Variables.StateSave toAsStateSave = AddToCurrentValuesWithState(toState);
                FlatRedBall.Glue.StateInterpolation.Tweener tweener = new FlatRedBall.Glue.StateInterpolation.Tweener(from: 0, to: 1, duration: (float)secondsToTake, type: interpolationType, easing: easing);
                if (owner == null)
                {
                    tweener.Owner = this;
                }
                else
                {
                    tweener.Owner = owner;
                }
                tweener.PositionChanged = newPosition => this.InterpolateBetween(current, toAsStateSave, newPosition);
                tweener.Ended += ()=> this.CurrentVariableState = toState;
                tweener.Start();
                StateInterpolationPlugin.TweenerManager.Self.Add(tweener);
                return tweener;
            }
            #endregion
            #region State Animations
            #endregion
            public override void StopAnimations () 
            {
                base.StopAnimations();
                ButtonCloseInstance.StopAnimations();
                ButtonCloseInstance1.StopAnimations();
                DividerInstance.StopAnimations();
                DividerInstance4.StopAnimations();
                ResolutionLabel.StopAnimations();
                ResolutionBox.StopAnimations();
                FullScreenCheckbox.StopAnimations();
                DividerInstance1.StopAnimations();
                MusicLabel.StopAnimations();
                MusicSlider.StopAnimations();
                SoundLabel.StopAnimations();
                SoundSlider.StopAnimations();
                DividerInstance2.StopAnimations();
                ControlLabel.StopAnimations();
                RadioButtonInstance.StopAnimations();
                RadioButtonInstance1.StopAnimations();
                RadioButtonInstance2.StopAnimations();
                DividerInstance3.StopAnimations();
                DifficultyLabel.StopAnimations();
                ComboBoxInstance.StopAnimations();
                ButtonConfirmInstance.StopAnimations();
                ButtonDenyInstance.StopAnimations();
                LabelInstance.StopAnimations();
                TextBoxInstance.StopAnimations();
                ButtonConfirmInstance1.StopAnimations();
                PercentBarInstance.StopAnimations();
                PercentBarInstance1.StopAnimations();
                PercentBarInstance2.StopAnimations();
                DividerInstance5.StopAnimations();
                ButtonCloseInstance2.StopAnimations();
                PercentBarInstance3.StopAnimations();
                PercentBarInstance4.StopAnimations();
                PercentBarInstance5.StopAnimations();
            }
            public override FlatRedBall.Gum.Animation.GumAnimation GetAnimation (string animationName) 
            {
                return base.GetAnimation(animationName);
            }
            #region Get Current Values on State
            private Gum.DataTypes.Variables.StateSave GetCurrentValuesOnState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height",
                            Type = "float",
                            Value = DemoSettingsMenu.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoSettingsMenu.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Width",
                            Type = "float",
                            Value = DemoSettingsMenu.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.X",
                            Type = "float",
                            Value = DemoSettingsMenu.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Y",
                            Type = "float",
                            Value = DemoSettingsMenu.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Parent",
                            Type = "string",
                            Value = Background.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height",
                            Type = "float",
                            Value = MenuTitle.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Parent",
                            Type = "string",
                            Value = MenuTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width",
                            Type = "float",
                            Value = MenuTitle.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height",
                            Type = "float",
                            Value = MenuTitle1.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Parent",
                            Type = "string",
                            Value = MenuTitle1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width",
                            Type = "float",
                            Value = MenuTitle1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MenuItems.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height",
                            Type = "float",
                            Value = MenuItems.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Parent",
                            Type = "string",
                            Value = MenuItems.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width",
                            Type = "float",
                            Value = MenuItems.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X",
                            Type = "float",
                            Value = MenuItems.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MenuItems.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y",
                            Type = "float",
                            Value = MenuItems.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MenuItems.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Parent",
                            Type = "string",
                            Value = TitleText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Text",
                            Type = "string",
                            Value = TitleText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Parent",
                            Type = "string",
                            Value = TitleText1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Text",
                            Type = "string",
                            Value = TitleText1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Parent",
                            Type = "string",
                            Value = DividerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width",
                            Type = "float",
                            Value = DividerInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Parent",
                            Type = "string",
                            Value = DividerInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width",
                            Type = "float",
                            Value = DividerInstance4.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance4.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance4.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.LabelText",
                            Type = "string",
                            Value = ResolutionLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.Parent",
                            Type = "string",
                            Value = ResolutionLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Height",
                            Type = "float",
                            Value = ResolutionBox.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Parent",
                            Type = "string",
                            Value = ResolutionBox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width",
                            Type = "float",
                            Value = ResolutionBox.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width Units",
                            Type = "DimensionUnitType",
                            Value = ResolutionBox.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.CheckboxDisplayText",
                            Type = "string",
                            Value = FullScreenCheckbox.CheckboxDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Parent",
                            Type = "string",
                            Value = FullScreenCheckbox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Y",
                            Type = "float",
                            Value = FullScreenCheckbox.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Parent",
                            Type = "string",
                            Value = DividerInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width",
                            Type = "float",
                            Value = DividerInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Y",
                            Type = "float",
                            Value = DividerInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.LabelText",
                            Type = "string",
                            Value = MusicLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Parent",
                            Type = "string",
                            Value = MusicLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Y",
                            Type = "float",
                            Value = MusicLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Parent",
                            Type = "string",
                            Value = MusicSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width",
                            Type = "float",
                            Value = MusicSlider.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = MusicSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.LabelText",
                            Type = "string",
                            Value = SoundLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.Parent",
                            Type = "string",
                            Value = SoundLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Parent",
                            Type = "string",
                            Value = SoundSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width",
                            Type = "float",
                            Value = SoundSlider.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = SoundSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Parent",
                            Type = "string",
                            Value = DividerInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width",
                            Type = "float",
                            Value = DividerInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Y",
                            Type = "float",
                            Value = DividerInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.LabelText",
                            Type = "string",
                            Value = ControlLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Parent",
                            Type = "string",
                            Value = ControlLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Y",
                            Type = "float",
                            Value = ControlLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Parent",
                            Type = "string",
                            Value = RadioButtonInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance1.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance1.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width",
                            Type = "float",
                            Value = RadioButtonInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Y",
                            Type = "float",
                            Value = RadioButtonInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Parent",
                            Type = "string",
                            Value = RadioButtonInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance2.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance2.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width",
                            Type = "float",
                            Value = RadioButtonInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Y",
                            Type = "float",
                            Value = RadioButtonInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Parent",
                            Type = "string",
                            Value = DividerInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width",
                            Type = "float",
                            Value = DividerInstance3.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Y",
                            Type = "float",
                            Value = DividerInstance3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.LabelText",
                            Type = "string",
                            Value = DifficultyLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Parent",
                            Type = "string",
                            Value = DifficultyLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Y",
                            Type = "float",
                            Value = DifficultyLabel.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height",
                            Type = "float",
                            Value = Background1.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Parent",
                            Type = "string",
                            Value = Background1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width",
                            Type = "float",
                            Value = Background1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X",
                            Type = "float",
                            Value = Background1.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Units",
                            Type = "PositionUnitType",
                            Value = Background1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y",
                            Type = "float",
                            Value = Background1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background1.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Units",
                            Type = "PositionUnitType",
                            Value = Background1.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Height",
                            Type = "float",
                            Value = ButtonContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Parent",
                            Type = "string",
                            Value = ButtonContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width",
                            Type = "float",
                            Value = ButtonContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Y",
                            Type = "float",
                            Value = ButtonContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Height",
                            Type = "float",
                            Value = DemoDialog.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Width",
                            Type = "float",
                            Value = DemoDialog.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.X",
                            Type = "float",
                            Value = DemoDialog.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Y",
                            Type = "float",
                            Value = DemoDialog.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MarginContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height",
                            Type = "float",
                            Value = MarginContainer.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Parent",
                            Type = "string",
                            Value = MarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width",
                            Type = "float",
                            Value = MarginContainer.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X",
                            Type = "float",
                            Value = MarginContainer.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y",
                            Type = "float",
                            Value = MarginContainer.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.LabelText",
                            Type = "string",
                            Value = LabelInstance.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Y",
                            Type = "float",
                            Value = LabelInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width",
                            Type = "float",
                            Value = TextBoxInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Hud.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Height",
                            Type = "float",
                            Value = Hud.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Height Units",
                            Type = "DimensionUnitType",
                            Value = Hud.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Hud.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Width",
                            Type = "float",
                            Value = Hud.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Width Units",
                            Type = "DimensionUnitType",
                            Value = Hud.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.X",
                            Type = "float",
                            Value = Hud.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Y",
                            Type = "float",
                            Value = Hud.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Parent",
                            Type = "string",
                            Value = TitleText2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Text",
                            Type = "string",
                            Value = TitleText2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height",
                            Type = "float",
                            Value = MenuTitle2.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Parent",
                            Type = "string",
                            Value = MenuTitle2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width",
                            Type = "float",
                            Value = MenuTitle2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Parent",
                            Type = "string",
                            Value = PercentBarInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width",
                            Type = "float",
                            Value = PercentBarInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Y",
                            Type = "float",
                            Value = PercentBarInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Parent",
                            Type = "string",
                            Value = PercentBarInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width",
                            Type = "float",
                            Value = PercentBarInstance1.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Y",
                            Type = "float",
                            Value = PercentBarInstance1.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Parent",
                            Type = "string",
                            Value = PercentBarInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width",
                            Type = "float",
                            Value = PercentBarInstance2.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Y",
                            Type = "float",
                            Value = PercentBarInstance2.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Parent",
                            Type = "string",
                            Value = DividerInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width",
                            Type = "float",
                            Value = DividerInstance5.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance5.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance5.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance2.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance2.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Parent",
                            Type = "string",
                            Value = PercentBarInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width",
                            Type = "float",
                            Value = PercentBarInstance3.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Y",
                            Type = "float",
                            Value = PercentBarInstance3.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance4.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Parent",
                            Type = "string",
                            Value = PercentBarInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width",
                            Type = "float",
                            Value = PercentBarInstance4.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Y",
                            Type = "float",
                            Value = PercentBarInstance4.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance5.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Parent",
                            Type = "string",
                            Value = PercentBarInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width",
                            Type = "float",
                            Value = PercentBarInstance5.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Y",
                            Type = "float",
                            Value = PercentBarInstance5.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ContainerInstance.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height",
                            Type = "float",
                            Value = ContainerInstance.Height
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Parent",
                            Type = "string",
                            Value = ContainerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width",
                            Type = "float",
                            Value = ContainerInstance.Width
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X",
                            Type = "float",
                            Value = ContainerInstance.X
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ContainerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y",
                            Type = "float",
                            Value = ContainerInstance.Y
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ContainerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            private Gum.DataTypes.Variables.StateSave AddToCurrentValuesWithState (VariableState state) 
            {
                Gum.DataTypes.Variables.StateSave newState = new Gum.DataTypes.Variables.StateSave();
                switch(state)
                {
                    case  VariableState.Default:
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height",
                            Type = "float",
                            Value = DemoSettingsMenu.Height + 610f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Height Units",
                            Type = "DimensionUnitType",
                            Value = DemoSettingsMenu.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Width",
                            Type = "float",
                            Value = DemoSettingsMenu.Width + 400f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.X",
                            Type = "float",
                            Value = DemoSettingsMenu.X + 40f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoSettingsMenu.Y",
                            Type = "float",
                            Value = DemoSettingsMenu.Y + 35f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.Parent",
                            Type = "string",
                            Value = Background.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height",
                            Type = "float",
                            Value = MenuTitle.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Parent",
                            Type = "string",
                            Value = MenuTitle.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width",
                            Type = "float",
                            Value = MenuTitle.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height",
                            Type = "float",
                            Value = MenuTitle1.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Parent",
                            Type = "string",
                            Value = MenuTitle1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width",
                            Type = "float",
                            Value = MenuTitle1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle1.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MenuItems.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height",
                            Type = "float",
                            Value = MenuItems.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Parent",
                            Type = "string",
                            Value = MenuItems.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width",
                            Type = "float",
                            Value = MenuItems.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuItems.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X",
                            Type = "float",
                            Value = MenuItems.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MenuItems.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.X Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y",
                            Type = "float",
                            Value = MenuItems.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MenuItems.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuItems.Y Units",
                            Type = "PositionUnitType",
                            Value = MenuItems.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Parent",
                            Type = "string",
                            Value = TitleText.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText.Text",
                            Type = "string",
                            Value = TitleText.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Parent",
                            Type = "string",
                            Value = TitleText1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText1.Text",
                            Type = "string",
                            Value = TitleText1.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Parent",
                            Type = "string",
                            Value = DividerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width",
                            Type = "float",
                            Value = DividerInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Parent",
                            Type = "string",
                            Value = DividerInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width",
                            Type = "float",
                            Value = DividerInstance4.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance4.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance4.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance4.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance4.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.LabelText",
                            Type = "string",
                            Value = ResolutionLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionLabel.Parent",
                            Type = "string",
                            Value = ResolutionLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Height",
                            Type = "float",
                            Value = ResolutionBox.Height + 128f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Parent",
                            Type = "string",
                            Value = ResolutionBox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width",
                            Type = "float",
                            Value = ResolutionBox.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ResolutionBox.Width Units",
                            Type = "DimensionUnitType",
                            Value = ResolutionBox.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.CheckboxDisplayText",
                            Type = "string",
                            Value = FullScreenCheckbox.CheckboxDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Parent",
                            Type = "string",
                            Value = FullScreenCheckbox.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "FullScreenCheckbox.Y",
                            Type = "float",
                            Value = FullScreenCheckbox.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Parent",
                            Type = "string",
                            Value = DividerInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width",
                            Type = "float",
                            Value = DividerInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance1.Y",
                            Type = "float",
                            Value = DividerInstance1.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.LabelText",
                            Type = "string",
                            Value = MusicLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Parent",
                            Type = "string",
                            Value = MusicLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicLabel.Y",
                            Type = "float",
                            Value = MusicLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Parent",
                            Type = "string",
                            Value = MusicSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width",
                            Type = "float",
                            Value = MusicSlider.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MusicSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = MusicSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.LabelText",
                            Type = "string",
                            Value = SoundLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundLabel.Parent",
                            Type = "string",
                            Value = SoundLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Parent",
                            Type = "string",
                            Value = SoundSlider.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width",
                            Type = "float",
                            Value = SoundSlider.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "SoundSlider.Width Units",
                            Type = "DimensionUnitType",
                            Value = SoundSlider.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Parent",
                            Type = "string",
                            Value = DividerInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width",
                            Type = "float",
                            Value = DividerInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance2.Y",
                            Type = "float",
                            Value = DividerInstance2.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.LabelText",
                            Type = "string",
                            Value = ControlLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Parent",
                            Type = "string",
                            Value = ControlLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ControlLabel.Y",
                            Type = "float",
                            Value = ControlLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Parent",
                            Type = "string",
                            Value = RadioButtonInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width",
                            Type = "float",
                            Value = RadioButtonInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Parent",
                            Type = "string",
                            Value = RadioButtonInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance1.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance1.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width",
                            Type = "float",
                            Value = RadioButtonInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance1.Y",
                            Type = "float",
                            Value = RadioButtonInstance1.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Parent",
                            Type = "string",
                            Value = RadioButtonInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioButtonCategoryState",
                            Type = "RadioButtonCategory",
                            Value = RadioButtonInstance2.CurrentRadioButtonCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.RadioDisplayText",
                            Type = "string",
                            Value = RadioButtonInstance2.RadioDisplayText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width",
                            Type = "float",
                            Value = RadioButtonInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = RadioButtonInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "RadioButtonInstance2.Y",
                            Type = "float",
                            Value = RadioButtonInstance2.Y + 4f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Parent",
                            Type = "string",
                            Value = DividerInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width",
                            Type = "float",
                            Value = DividerInstance3.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance3.Y",
                            Type = "float",
                            Value = DividerInstance3.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.LabelText",
                            Type = "string",
                            Value = DifficultyLabel.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Parent",
                            Type = "string",
                            Value = DifficultyLabel.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DifficultyLabel.Y",
                            Type = "float",
                            Value = DifficultyLabel.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Background1.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height",
                            Type = "float",
                            Value = Background1.Height + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Height Units",
                            Type = "DimensionUnitType",
                            Value = Background1.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Parent",
                            Type = "string",
                            Value = Background1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Background1.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width",
                            Type = "float",
                            Value = Background1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Width Units",
                            Type = "DimensionUnitType",
                            Value = Background1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X",
                            Type = "float",
                            Value = Background1.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = Background1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.X Units",
                            Type = "PositionUnitType",
                            Value = Background1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y",
                            Type = "float",
                            Value = Background1.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Origin",
                            Type = "VerticalAlignment",
                            Value = Background1.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Background1.Y Units",
                            Type = "PositionUnitType",
                            Value = Background1.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Parent",
                            Type = "string",
                            Value = ComboBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width",
                            Type = "float",
                            Value = ComboBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ComboBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ComboBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Height",
                            Type = "float",
                            Value = ButtonContainer.Height + 32f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Parent",
                            Type = "string",
                            Value = ButtonContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width",
                            Type = "float",
                            Value = ButtonContainer.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = ButtonContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonContainer.Y",
                            Type = "float",
                            Value = ButtonContainer.Y + 16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonDenyInstance.Parent",
                            Type = "string",
                            Value = ButtonDenyInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Height",
                            Type = "float",
                            Value = DemoDialog.Height + 163f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Width",
                            Type = "float",
                            Value = DemoDialog.Width + 349f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.X",
                            Type = "float",
                            Value = DemoDialog.X + 488f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DemoDialog.Y",
                            Type = "float",
                            Value = DemoDialog.Y + 42f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Children Layout",
                            Type = "ChildrenLayout",
                            Value = MarginContainer.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height",
                            Type = "float",
                            Value = MarginContainer.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Height Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Parent",
                            Type = "string",
                            Value = MarginContainer.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width",
                            Type = "float",
                            Value = MarginContainer.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Width Units",
                            Type = "DimensionUnitType",
                            Value = MarginContainer.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X",
                            Type = "float",
                            Value = MarginContainer.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Origin",
                            Type = "HorizontalAlignment",
                            Value = MarginContainer.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.X Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y",
                            Type = "float",
                            Value = MarginContainer.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Origin",
                            Type = "VerticalAlignment",
                            Value = MarginContainer.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MarginContainer.Y Units",
                            Type = "PositionUnitType",
                            Value = MarginContainer.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.LabelText",
                            Type = "string",
                            Value = LabelInstance.LabelText
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Parent",
                            Type = "string",
                            Value = LabelInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "LabelInstance.Y",
                            Type = "float",
                            Value = LabelInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Parent",
                            Type = "string",
                            Value = TextBoxInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width",
                            Type = "float",
                            Value = TextBoxInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TextBoxInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = TextBoxInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Parent",
                            Type = "string",
                            Value = ButtonConfirmInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonConfirmInstance1.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonConfirmInstance1.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonConfirmInstance1.Y",
                            Type = "float",
                            Value = ButtonConfirmInstance1.Y + 16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = Hud.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Height",
                            Type = "float",
                            Value = Hud.Height + 207f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Height Units",
                            Type = "DimensionUnitType",
                            Value = Hud.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = Hud.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Width",
                            Type = "float",
                            Value = Hud.Width + 279f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Width Units",
                            Type = "DimensionUnitType",
                            Value = Hud.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.X",
                            Type = "float",
                            Value = Hud.X + -331f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "Hud.Y",
                            Type = "float",
                            Value = Hud.Y + -176f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.ColorCategoryState",
                            Type = "ColorCategory",
                            Value = TitleText2.CurrentColorCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Parent",
                            Type = "string",
                            Value = TitleText2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.StyleCategoryState",
                            Type = "StyleCategory",
                            Value = TitleText2.CurrentStyleCategoryState
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "TitleText2.Text",
                            Type = "string",
                            Value = TitleText2.Text
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height",
                            Type = "float",
                            Value = MenuTitle2.Height + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Height Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Parent",
                            Type = "string",
                            Value = MenuTitle2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width",
                            Type = "float",
                            Value = MenuTitle2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "MenuTitle2.Width Units",
                            Type = "DimensionUnitType",
                            Value = MenuTitle2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Parent",
                            Type = "string",
                            Value = PercentBarInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width",
                            Type = "float",
                            Value = PercentBarInstance.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance.Y",
                            Type = "float",
                            Value = PercentBarInstance.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance1.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Parent",
                            Type = "string",
                            Value = PercentBarInstance1.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width",
                            Type = "float",
                            Value = PercentBarInstance1.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance1.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance1.Y",
                            Type = "float",
                            Value = PercentBarInstance1.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance2.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Parent",
                            Type = "string",
                            Value = PercentBarInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width",
                            Type = "float",
                            Value = PercentBarInstance2.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance2.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance2.Y",
                            Type = "float",
                            Value = PercentBarInstance2.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Parent",
                            Type = "string",
                            Value = DividerInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width",
                            Type = "float",
                            Value = DividerInstance5.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = DividerInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Origin",
                            Type = "HorizontalAlignment",
                            Value = DividerInstance5.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.X Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Origin",
                            Type = "VerticalAlignment",
                            Value = DividerInstance5.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "DividerInstance5.Y Units",
                            Type = "PositionUnitType",
                            Value = DividerInstance5.YUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.Parent",
                            Type = "string",
                            Value = ButtonCloseInstance2.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ButtonCloseInstance2.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ButtonCloseInstance2.X Units",
                            Type = "PositionUnitType",
                            Value = ButtonCloseInstance2.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance3.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Parent",
                            Type = "string",
                            Value = PercentBarInstance3.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width",
                            Type = "float",
                            Value = PercentBarInstance3.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance3.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance3.Y",
                            Type = "float",
                            Value = PercentBarInstance3.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance4.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Parent",
                            Type = "string",
                            Value = PercentBarInstance4.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width",
                            Type = "float",
                            Value = PercentBarInstance4.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance4.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance4.Y",
                            Type = "float",
                            Value = PercentBarInstance4.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.BarColor",
                            Type = "ColorCategory",
                            Value = PercentBarInstance5.BarColor
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Parent",
                            Type = "string",
                            Value = PercentBarInstance5.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width",
                            Type = "float",
                            Value = PercentBarInstance5.Width + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Width Units",
                            Type = "DimensionUnitType",
                            Value = PercentBarInstance5.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "PercentBarInstance5.Y",
                            Type = "float",
                            Value = PercentBarInstance5.Y + 8f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Children Layout",
                            Type = "ChildrenLayout",
                            Value = ContainerInstance.ChildrenLayout
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height",
                            Type = "float",
                            Value = ContainerInstance.Height + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Height Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.HeightUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Parent",
                            Type = "string",
                            Value = ContainerInstance.Parent
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width",
                            Type = "float",
                            Value = ContainerInstance.Width + -16f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Width Units",
                            Type = "DimensionUnitType",
                            Value = ContainerInstance.WidthUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X",
                            Type = "float",
                            Value = ContainerInstance.X + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Origin",
                            Type = "HorizontalAlignment",
                            Value = ContainerInstance.XOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.X Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.XUnits
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y",
                            Type = "float",
                            Value = ContainerInstance.Y + 0f
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Origin",
                            Type = "VerticalAlignment",
                            Value = ContainerInstance.YOrigin
                        }
                        );
                        newState.Variables.Add(new Gum.DataTypes.Variables.VariableSave()
                        {
                            SetsValue = true,
                            Name = "ContainerInstance.Y Units",
                            Type = "PositionUnitType",
                            Value = ContainerInstance.YUnits
                        }
                        );
                        break;
                }
                return newState;
            }
            #endregion
            public override void ApplyState (Gum.DataTypes.Variables.StateSave state) 
            {
                bool matches = this.ElementSave.AllStates.Contains(state);
                if (matches)
                {
                    var category = this.ElementSave.Categories.FirstOrDefault(item => item.States.Contains(state));
                    if (category == null)
                    {
                        if (state.Name == "Default") this.mCurrentVariableState = VariableState.Default;
                    }
                }
                base.ApplyState(state);
            }
            private bool tryCreateFormsObject;
            public NewGum.GumRuntimes.ContainerRuntime DemoSettingsMenu { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Background { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle1 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuItems { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText1 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance4 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime ResolutionLabel { get; set; }
            public NewGum.GumRuntimes.Controls.ListBoxRuntime ResolutionBox { get; set; }
            public NewGum.GumRuntimes.Controls.CheckBoxRuntime FullScreenCheckbox { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime MusicLabel { get; set; }
            public NewGum.GumRuntimes.Controls.SliderRuntime MusicSlider { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime SoundLabel { get; set; }
            public NewGum.GumRuntimes.Controls.SliderRuntime SoundSlider { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime ControlLabel { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance1 { get; set; }
            public NewGum.GumRuntimes.Controls.RadioButtonRuntime RadioButtonInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance3 { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime DifficultyLabel { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Background1 { get; set; }
            public NewGum.GumRuntimes.Controls.ComboBoxRuntime ComboBoxInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ButtonContainer { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonConfirmRuntime ButtonConfirmInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonDenyRuntime ButtonDenyInstance { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime DemoDialog { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MarginContainer { get; set; }
            public NewGum.GumRuntimes.Elements.LabelRuntime LabelInstance { get; set; }
            public NewGum.GumRuntimes.Controls.TextBoxRuntime TextBoxInstance { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonConfirmRuntime ButtonConfirmInstance1 { get; set; }
            public NewGum.GumRuntimes.NineSliceRuntime Hud { get; set; }
            public NewGum.GumRuntimes.TextRuntime TitleText2 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime MenuTitle2 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance1 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.DividerRuntime DividerInstance5 { get; set; }
            public NewGum.GumRuntimes.Controls.ButtonCloseRuntime ButtonCloseInstance2 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance3 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarRuntime PercentBarInstance4 { get; set; }
            public NewGum.GumRuntimes.Elements.PercentBarIconRuntime PercentBarInstance5 { get; set; }
            public NewGum.GumRuntimes.ContainerRuntime ContainerInstance { get; set; }
            public DemoScreenRuntime () 
            	: this(true, true)
            {
            }
            public DemoScreenRuntime (bool fullInstantiation = true, bool tryCreateFormsObject = true) 
            {
                this.tryCreateFormsObject = tryCreateFormsObject;
                if (fullInstantiation)
                {
                    Gum.DataTypes.ElementSave elementSave = Gum.Managers.ObjectFinder.Self.GumProjectSave.Screens.First(item => item.Name == "DemoScreen");
                    this.ElementSave = elementSave;
                    string oldDirectory = FlatRedBall.IO.FileManager.RelativeDirectory;
                    FlatRedBall.IO.FileManager.RelativeDirectory = FlatRedBall.IO.FileManager.GetDirectory(Gum.Managers.ObjectFinder.Self.GumProjectSave.FullFileName);
                    GumRuntime.ElementSaveExtensions.SetGraphicalUiElement(elementSave, this, RenderingLibrary.SystemManagers.Default);
                    FlatRedBall.IO.FileManager.RelativeDirectory = oldDirectory;
                }
            }
            public override void SetInitialState () 
            {
                base.SetInitialState();
                this.CurrentVariableState = VariableState.Default;
                CallCustomInitialize();
            }
            public override void CreateChildrenRecursively (Gum.DataTypes.ElementSave elementSave, RenderingLibrary.SystemManagers systemManagers) 
            {
                base.CreateChildrenRecursively(elementSave, systemManagers);
                this.AssignReferences();
            }
            private void AssignReferences () 
            {
                DemoSettingsMenu = this.GetGraphicalUiElementByName("DemoSettingsMenu") as NewGum.GumRuntimes.ContainerRuntime;
                Background = this.GetGraphicalUiElementByName("Background") as NewGum.GumRuntimes.NineSliceRuntime;
                MenuTitle = this.GetGraphicalUiElementByName("MenuTitle") as NewGum.GumRuntimes.ContainerRuntime;
                MenuTitle1 = this.GetGraphicalUiElementByName("MenuTitle1") as NewGum.GumRuntimes.ContainerRuntime;
                MenuItems = this.GetGraphicalUiElementByName("MenuItems") as NewGum.GumRuntimes.ContainerRuntime;
                TitleText = this.GetGraphicalUiElementByName("TitleText") as NewGum.GumRuntimes.TextRuntime;
                TitleText1 = this.GetGraphicalUiElementByName("TitleText1") as NewGum.GumRuntimes.TextRuntime;
                ButtonCloseInstance = this.GetGraphicalUiElementByName("ButtonCloseInstance") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                ButtonCloseInstance1 = this.GetGraphicalUiElementByName("ButtonCloseInstance1") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                DividerInstance = this.GetGraphicalUiElementByName("DividerInstance") as NewGum.GumRuntimes.Elements.DividerRuntime;
                DividerInstance4 = this.GetGraphicalUiElementByName("DividerInstance4") as NewGum.GumRuntimes.Elements.DividerRuntime;
                ResolutionLabel = this.GetGraphicalUiElementByName("ResolutionLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                ResolutionBox = this.GetGraphicalUiElementByName("ResolutionBox") as NewGum.GumRuntimes.Controls.ListBoxRuntime;
                FullScreenCheckbox = this.GetGraphicalUiElementByName("FullScreenCheckbox") as NewGum.GumRuntimes.Controls.CheckBoxRuntime;
                DividerInstance1 = this.GetGraphicalUiElementByName("DividerInstance1") as NewGum.GumRuntimes.Elements.DividerRuntime;
                MusicLabel = this.GetGraphicalUiElementByName("MusicLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                MusicSlider = this.GetGraphicalUiElementByName("MusicSlider") as NewGum.GumRuntimes.Controls.SliderRuntime;
                SoundLabel = this.GetGraphicalUiElementByName("SoundLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                SoundSlider = this.GetGraphicalUiElementByName("SoundSlider") as NewGum.GumRuntimes.Controls.SliderRuntime;
                DividerInstance2 = this.GetGraphicalUiElementByName("DividerInstance2") as NewGum.GumRuntimes.Elements.DividerRuntime;
                ControlLabel = this.GetGraphicalUiElementByName("ControlLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                RadioButtonInstance = this.GetGraphicalUiElementByName("RadioButtonInstance") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                RadioButtonInstance1 = this.GetGraphicalUiElementByName("RadioButtonInstance1") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                RadioButtonInstance2 = this.GetGraphicalUiElementByName("RadioButtonInstance2") as NewGum.GumRuntimes.Controls.RadioButtonRuntime;
                DividerInstance3 = this.GetGraphicalUiElementByName("DividerInstance3") as NewGum.GumRuntimes.Elements.DividerRuntime;
                DifficultyLabel = this.GetGraphicalUiElementByName("DifficultyLabel") as NewGum.GumRuntimes.Elements.LabelRuntime;
                Background1 = this.GetGraphicalUiElementByName("Background1") as NewGum.GumRuntimes.NineSliceRuntime;
                ComboBoxInstance = this.GetGraphicalUiElementByName("ComboBoxInstance") as NewGum.GumRuntimes.Controls.ComboBoxRuntime;
                ButtonContainer = this.GetGraphicalUiElementByName("ButtonContainer") as NewGum.GumRuntimes.ContainerRuntime;
                ButtonConfirmInstance = this.GetGraphicalUiElementByName("ButtonConfirmInstance") as NewGum.GumRuntimes.Controls.ButtonConfirmRuntime;
                ButtonDenyInstance = this.GetGraphicalUiElementByName("ButtonDenyInstance") as NewGum.GumRuntimes.Controls.ButtonDenyRuntime;
                DemoDialog = this.GetGraphicalUiElementByName("DemoDialog") as NewGum.GumRuntimes.ContainerRuntime;
                MarginContainer = this.GetGraphicalUiElementByName("MarginContainer") as NewGum.GumRuntimes.ContainerRuntime;
                LabelInstance = this.GetGraphicalUiElementByName("LabelInstance") as NewGum.GumRuntimes.Elements.LabelRuntime;
                TextBoxInstance = this.GetGraphicalUiElementByName("TextBoxInstance") as NewGum.GumRuntimes.Controls.TextBoxRuntime;
                ButtonConfirmInstance1 = this.GetGraphicalUiElementByName("ButtonConfirmInstance1") as NewGum.GumRuntimes.Controls.ButtonConfirmRuntime;
                Hud = this.GetGraphicalUiElementByName("Hud") as NewGum.GumRuntimes.NineSliceRuntime;
                TitleText2 = this.GetGraphicalUiElementByName("TitleText2") as NewGum.GumRuntimes.TextRuntime;
                MenuTitle2 = this.GetGraphicalUiElementByName("MenuTitle2") as NewGum.GumRuntimes.ContainerRuntime;
                PercentBarInstance = this.GetGraphicalUiElementByName("PercentBarInstance") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance1 = this.GetGraphicalUiElementByName("PercentBarInstance1") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance2 = this.GetGraphicalUiElementByName("PercentBarInstance2") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                DividerInstance5 = this.GetGraphicalUiElementByName("DividerInstance5") as NewGum.GumRuntimes.Elements.DividerRuntime;
                ButtonCloseInstance2 = this.GetGraphicalUiElementByName("ButtonCloseInstance2") as NewGum.GumRuntimes.Controls.ButtonCloseRuntime;
                PercentBarInstance3 = this.GetGraphicalUiElementByName("PercentBarInstance3") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance4 = this.GetGraphicalUiElementByName("PercentBarInstance4") as NewGum.GumRuntimes.Elements.PercentBarRuntime;
                PercentBarInstance5 = this.GetGraphicalUiElementByName("PercentBarInstance5") as NewGum.GumRuntimes.Elements.PercentBarIconRuntime;
                ContainerInstance = this.GetGraphicalUiElementByName("ContainerInstance") as NewGum.GumRuntimes.ContainerRuntime;
                if (tryCreateFormsObject)
                {
                    FormsControlAsObject = new NewGum.FormsControls.Screens.DemoScreenForms(this);
                }
            }
            public override void AddToManagers (RenderingLibrary.SystemManagers managers, RenderingLibrary.Graphics.Layer layer) 
            {
                base.AddToManagers(managers, layer);
            }
            private void CallCustomInitialize () 
            {
                CustomInitialize();
            }
            partial void CustomInitialize();
            public NewGum.FormsControls.Screens.DemoScreenForms FormsControl {get => (NewGum.FormsControls.Screens.DemoScreenForms) FormsControlAsObject;}
        }
    }
