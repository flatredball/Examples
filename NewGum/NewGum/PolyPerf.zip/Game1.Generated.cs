using System.Linq;
namespace NewGum
{
    public partial class Game1
    {
        GlueControl.GlueControlManager glueControlManager;
        partial void GeneratedInitialize () 
        {
            var args = System.Environment.GetCommandLineArgs();
            bool? changeResize = null;
            var resizeArgs = args.FirstOrDefault(item => item.StartsWith("AllowWindowResizing="));
            if (!string.IsNullOrEmpty(resizeArgs))
            {
                var afterEqual = resizeArgs.Split('=')[1];
                changeResize = bool.Parse(afterEqual);
            }
            if (changeResize != null)
            {
                CameraSetup.Data.AllowWindowResizing = changeResize.Value;
            }
            CameraSetup.SetupCamera(FlatRedBall.Camera.Main, graphics);
            glueControlManager = new GlueControl.GlueControlManager(8017);
            glueControlManager.Start();
            this.Exiting += (not, used) => glueControlManager.Kill();
            FlatRedBall.FlatRedBallServices.GraphicsOptions.SizeOrOrientationChanged += (not, used) =>
            {
                if (FlatRedBall.Screens.ScreenManager.IsInEditMode)
                {
                    GlueControl.Editing.CameraLogic.UpdateCameraToZoomLevel(zoomAroundCursorPosition: false);
                }
                GlueControl.Editing.CameraLogic.PushZoomLevelToEditor();
            }
            ;
            FlatRedBall.Screens.ScreenManager.BeforeScreenCustomInitialize += (newScreen) => 
            {
                glueControlManager.ReRunAllGlueToGameCommands();
            }
            ;
            System.Type startScreenType = typeof(NewGum.Screens.PolygonScreen);
            var commandLineArgs = System.Environment.GetCommandLineArgs();
            if (commandLineArgs.Length > 0)
            {
                var thisAssembly = this.GetType().Assembly;
                // see if any of these are screens:
                foreach (var item in commandLineArgs)
                {
                    var type = thisAssembly.GetType(item);
                    if (type != null)
                    {
                        startScreenType = type;
                        break;
                    }
                }
            }
            if (startScreenType != null)
            {
                FlatRedBall.Screens.ScreenManager.Start(startScreenType);
            }
        }
        partial void GeneratedUpdate (Microsoft.Xna.Framework.GameTime gameTime) 
        {
        }
        partial void GeneratedDraw (Microsoft.Xna.Framework.GameTime gameTime) 
        {
        }
    }
}
