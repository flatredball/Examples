using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

using FlatRedBall;
using FlatRedBall.Input;
using FlatRedBall.Instructions;
using FlatRedBall.AI.Pathfinding;
using FlatRedBall.Graphics.Animation;
using FlatRedBall.Gui;
using FlatRedBall.Math;
using FlatRedBall.Math.Geometry;
using FlatRedBall.Localization;
using Microsoft.Xna.Framework;



namespace NewGum.Screens
{
    public partial class PolygonScreen
    {
        Polygon PolygonInstance;

        void CustomInitialize()
        {

            this.PolygonInstance = Polygon.CreateEquilateral(220, 240, 0);
            this.PolygonInstance.Visible = true;
        }

        void CustomActivity(bool firstTimeCalled)
        {
            this.PolygonInstance.Points = PolygonInstance.Points;

        }

        partial void CustomActivityEditMode()
        {
            var before = TimeManager.CurrentSystemTime;
            var isConcave = this.PolygonInstance.IsConcave();
            var after = TimeManager.CurrentSystemTime;

            var milliseconds = (after - before) * 1000;

            FlatRedBall.Debugging.Debugger.Write(milliseconds.ToString("N1") + " ms");
        }

        void CustomDestroy()
        {

            ShapeManager.Remove(this.PolygonInstance);
        }

        static void CustomLoadStaticContent(string contentManagerName)
        {


        }

    }
}
