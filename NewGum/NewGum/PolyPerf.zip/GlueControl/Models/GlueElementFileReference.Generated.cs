#define IncludeSetVariable
#define SupportsEditMode
#define ScreenManagerHasPersistentPolygons
#define SpriteHasTolerateMissingAnimations
#define HasGum
using NewGum;

﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GlueControl.Models
{
    public class GlueElementFileReference
    {
        public string Name { get; set; } // name relative to the project
    }
}
