namespace NewGum
{
    public class FileAliasLogic
    {
        public static void SetFileAliases () 
        {
        }
    }
}
